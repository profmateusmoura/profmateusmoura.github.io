# Duplicatas — Lojas Blue
# Enunciado:
# Defina a política de ignorar id repetido e teste.
#
# Dica:
# Inserir duplicata não cria outro nó.
#
# Conferência:
# Quantidade de nós não aumenta.
#
# Apoio: 25_bst/exemplos/01_rede_aplicada.py
