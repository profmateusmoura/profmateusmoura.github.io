# Remover — Lojas Blue
# Enunciado:
# Implemente remoção de folha, nó com um filho e nó com dois filhos. Preserve a ordenação.
#
# Dica:
# No caso de dois filhos, use sucessor em-ordem.
#
# Conferência:
# Percurso continua crescente após cada remoção.
#
# Apoio: 25_bst/exemplos/01_rede_aplicada.py
