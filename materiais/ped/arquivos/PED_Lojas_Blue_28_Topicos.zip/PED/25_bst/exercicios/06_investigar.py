# Corrigir o ramo da inserção
# Enunciado:
# Uma inserção manda chaves maiores para a esquerda e menores para a direita, mas a busca pressupõe o contrário. Corrija a organização para o contrato da BST.
#
# Dica:
# Inserção e consulta precisam compartilhar o mesmo invariante.
#
# Conferência:
# O percurso em-ordem fica crescente e a busca encontra todas as chaves inseridas.
#
# Apoio: 25_bst/exemplos/01_rede_aplicada.py
