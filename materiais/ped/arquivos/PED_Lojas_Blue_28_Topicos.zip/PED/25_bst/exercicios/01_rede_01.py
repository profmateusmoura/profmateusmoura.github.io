# Inserir e buscar — Lojas Blue
# Enunciado:
# Implemente busca em BST de ids de produtos.
#
# Dica:
# Compare com a raiz e escolha só um lado.
#
# Conferência:
# Primeiro, último e ausente são tratados.
#
# Apoio: 25_bst/exemplos/01_rede_aplicada.py
