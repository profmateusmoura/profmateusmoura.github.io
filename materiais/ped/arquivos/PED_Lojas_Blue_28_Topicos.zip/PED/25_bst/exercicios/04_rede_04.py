# Degeneração — Lojas Blue
# Enunciado:
# Compare altura com inserção 1,2,3,4,5 e com 3,1,5,2,4.
#
# Dica:
# Mesmas chaves podem produzir formas diferentes.
#
# Conferência:
# Primeira altura cinco; segunda altura três.
#
# Apoio: 25_bst/exemplos/01_rede_aplicada.py
