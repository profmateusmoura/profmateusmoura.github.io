# Prever formas diferentes
# Enunciado:
# Compare a altura em nós após inserir 1,2,3,4,5 e após inserir 3,1,5,2,4 em uma BST.
#
# Dica:
# A ordem de inserção muda a forma, não o conjunto de chaves.
#
# Conferência:
# Alturas cinco e três, com o mesmo percurso em-ordem.
#
# Apoio: 25_bst/exemplos/01_rede_aplicada.py
