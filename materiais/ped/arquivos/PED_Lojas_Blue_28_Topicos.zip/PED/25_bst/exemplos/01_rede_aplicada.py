# Catálogo em árvore binária de busca — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Ids ordenados: [1, 2, 3'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def inserir(no, chave):
    """Insira chave inteira em BST, ignorando duplicata; retorne a raiz."""
    if no is None:
        return {"chave": chave, "esquerda": None, "direita": None}
    if chave < no["chave"]:
        no["esquerda"] = inserir(no["esquerda"], chave)
    elif chave > no["chave"]:
        no["direita"] = inserir(no["direita"], chave)
    return no

def em_ordem(no):
    """Retorne chaves de uma BST em ordem crescente."""
    if no is None:
        return []
    return em_ordem(no["esquerda"]) + [no["chave"]] + em_ordem(no["direita"])

raiz = None
for produto in dados["produtos"]:
    raiz = inserir(raiz, produto["id"])
print("Ids ordenados:", em_ordem(raiz))
# Inserir ids já crescentes cria uma árvore degenerada; não promete O(log n).
