# Gravar um relatório de texto — cenário didático Lojas Blue
# Objetivo: Introduzir o recurso com um recorte da rede.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Produto 4: estoque crítico'
# Sem entrada interativa.

from pathlib import Path

# A pasta de saída fica na pasta do terminal e é separada da fonte de dados.
destino = Path.cwd() / "saidas" / "relatorio_rede.txt"
destino.parent.mkdir(exist_ok=True)
with destino.open("w", encoding="utf-8") as arquivo:
    arquivo.write("Unidade 1: Sete Lagoas Centro\n")
    arquivo.write("Produto 4: estoque crítico\n")
# with fecha o arquivo ao sair do bloco, inclusive quando há erro.
with destino.open(encoding="utf-8") as arquivo:
    print(arquivo.read(), end="")
