# Aplicação: Gravar um relatório de texto — cenário didático Lojas Blue
# Objetivo: Combinar o recurso com conceitos já estudados.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Lida: Belo Horizonte Centro'
# Sem entrada interativa.

from pathlib import Path

destino = Path.cwd() / "saidas" / "nomes_rede.txt"
destino.parent.mkdir(exist_ok=True)
nomes = ["Sete Lagoas Centro", "Belo Horizonte Centro"]
with destino.open("w", encoding="utf-8") as arquivo:
    for nome in nomes:
        arquivo.write(nome + "\n")
with destino.open(encoding="utf-8") as arquivo:
    for linha in arquivo:
        print("Lida:", linha.strip())
# Este arquivo é texto linha a linha, ainda não um documento JSON.
