# Arquivo ausente e leitura bem-sucedida
# Execução: python 08_arquivos_texto/exemplos/03_falhas_de_leitura.py
# Confira na saída: 'Arquivo não encontrado: arquivo_ausente_exemplo.txt'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

from pathlib import Path

destino = Path.cwd() / "saidas" / "unidades_exemplo.txt"
destino.parent.mkdir(exist_ok=True)
destino.write_text("Sete Lagoas Centro\n", encoding="utf-8")
# A abertura é uma operação que pode falhar; a ausência é tratada na borda
# do programa, onde podemos decidir como informar ao usuário.
for caminho in (destino, destino.with_name("arquivo_ausente_exemplo.txt")):
    try:
        texto = caminho.read_text(encoding="utf-8")
    except FileNotFoundError:
        print("Arquivo não encontrado:", caminho.name)
    else:
        print("Conteúdo:", texto.strip())
# O bloco else só apresenta conteúdo se a leitura realmente foi concluída.
