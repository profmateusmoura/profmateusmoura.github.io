# Preservar fonte — Lojas Blue
# Enunciado:
# Leia nomes do arquivo anterior e grave cópia com rótulo Unidade: em outro arquivo.
#
# Dica:
# Origem e destino devem ser diferentes.
#
# Conferência:
# Fonte intacta e cópia com dois rótulos.
#
# Apoio: 08_arquivos_texto/exemplos/01_fundamento.py, 08_arquivos_texto/exemplos/02_aplicacao.py
