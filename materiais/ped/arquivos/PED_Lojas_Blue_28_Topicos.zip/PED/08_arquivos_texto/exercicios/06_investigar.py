# Corrigir uma contagem de linhas
# Enunciado:
# Um programa usa len(arquivo.read()) como quantidade de unidades de um arquivo com um nome por linha. Explique o que está contando e corrija para contar linhas não vazias.
#
# Dica:
# Tamanho do texto e quantidade de registros são medidas diferentes.
#
# Conferência:
# Dois nomes em duas linhas produzem contagem dois.
#
# Apoio: 08_arquivos_texto/exemplos/01_fundamento.py, 08_arquivos_texto/exemplos/02_aplicacao.py
