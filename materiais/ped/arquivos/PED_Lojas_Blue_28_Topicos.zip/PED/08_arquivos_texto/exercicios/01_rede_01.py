# Gravar nomes — Lojas Blue
# Enunciado:
# Grave Sete Lagoas Centro e Belo Horizonte Centro, um nome por linha, em saidas/unidades.txt.
#
# Dica:
# Crie a pasta e use UTF-8 com with.
#
# Conferência:
# Duas linhas no arquivo.
#
# Apoio: 08_arquivos_texto/exemplos/01_fundamento.py, 08_arquivos_texto/exemplos/02_aplicacao.py
