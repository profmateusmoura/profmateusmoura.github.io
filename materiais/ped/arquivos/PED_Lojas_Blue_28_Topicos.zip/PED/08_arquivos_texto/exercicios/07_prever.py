# Prever a borda de leitura
# Enunciado:
# Compare arquivo existente vazio com caminho inexistente. Preveja se a leitura devolve texto ou levanta uma falha.
#
# Dica:
# Uma fonte vazia pode ser lida com sucesso.
#
# Conferência:
# O arquivo vazio devolve texto vazio; o caminho inexistente levanta FileNotFoundError.
#
# Apoio: 08_arquivos_texto/exemplos/03_falhas_de_leitura.py
