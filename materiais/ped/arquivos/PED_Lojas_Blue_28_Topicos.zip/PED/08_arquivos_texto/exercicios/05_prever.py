# Prever os modos de escrita
# Enunciado:
# Um arquivo contém duas linhas. Preveja o que acontece ao abri-lo em modo w e escrever uma linha nova. Compare com o modo a.
#
# Dica:
# O modo é escolhido ao abrir o arquivo.
#
# Conferência:
# w substitui as linhas; a acrescenta a nova linha ao final.
#
# Apoio: 08_arquivos_texto/exemplos/01_fundamento.py, 08_arquivos_texto/exemplos/02_aplicacao.py
