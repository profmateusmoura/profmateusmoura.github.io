# Completar leitura com informação de falha
# Enunciado:
# Crie um programa que recebe caminho, tenta ler UTF-8 e distingue arquivo ausente de arquivo lido vazio. Retorne o texto só em leitura bem-sucedida.
#
# Dica:
# Trate a falha de abertura antes de interpretar o conteúdo.
#
# Conferência:
# As duas situações produzem mensagens diferentes.
#
# Apoio: 08_arquivos_texto/exemplos/03_falhas_de_leitura.py
