# Arquivo vazio — Lojas Blue
# Enunciado:
# Crie arquivo de texto vazio e leia sem falhar. Mostre zero linhas.
#
# Dica:
# Um percurso de arquivo vazio não executa o corpo.
#
# Conferência:
# Contagem zero.
#
# Apoio: 08_arquivos_texto/exemplos/01_fundamento.py, 08_arquivos_texto/exemplos/02_aplicacao.py
