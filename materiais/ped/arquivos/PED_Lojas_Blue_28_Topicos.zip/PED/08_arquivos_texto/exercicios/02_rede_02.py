# Reler relatório — Lojas Blue
# Enunciado:
# Leia o arquivo anterior e conte linhas não vazias.
#
# Dica:
# Não conte a quebra final como outro registro.
#
# Conferência:
# Contagem dois.
#
# Apoio: 08_arquivos_texto/exemplos/01_fundamento.py, 08_arquivos_texto/exemplos/02_aplicacao.py
