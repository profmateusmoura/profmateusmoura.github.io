# Rodadas de aprofundamento — PED

O percurso essencial é 01–22, projeto 27 e comparação 28. Os tópicos 23–25 são aprofundamento; 26 é desafio avançado.
As novas comparações podem ser revisitadas depois dos respectivos fundamentos, sem exigir o ramo de árvores.
Em 02 e 04, confira deslocamento da lista e diferença entre ausência e valor zero.
Em 07, estude enumerate, zip, compreensão e o efeito de um argumento padrão mutável.
Em 08 e 09, diferencie falha de arquivo, erro de sintaxe e formato da estrutura lida.
Em 11 e 13, compare estados de recursão e contagens de trabalho. Em 14 e 15, confira o contrato do resultado de busca.
Em 28, compare buscas, algoritmos de ordenação e índices na mesma entrada, incluindo os custos de preparação.

## Exemplos e atividades acrescentados

### Por que uma remoção pode pular um elemento

- [Exemplo completo](02_listas/exemplos/03_remover_durante_percurso.py)

### Campo ausente é diferente de preço zero

- [Exemplo completo](04_dicionarios/exemplos/03_ausencia_e_valor_zero.py)

### Índice acompanhado do valor e percursos paralelos

- [Exemplo completo](07_funcoes_com_colecoes/exemplos/03_enumerate_zip.py)

### A mesma seleção com laço e compreensão

- [Exemplo completo](07_funcoes_com_colecoes/exemplos/04_laco_e_compreensao.py)

### Quando um argumento padrão guarda estado entre chamadas

- [Exemplo completo](07_funcoes_com_colecoes/exemplos/05_padrao_mutavel.py)

### Arquivo ausente e leitura bem-sucedida

- [Exemplo completo](08_arquivos_texto/exemplos/03_falhas_de_leitura.py)

### Texto JSON e estruturas em memória

- [Exemplo completo](09_json_arquivo_e_memoria/exemplos/03_documento_texto_memoria.py)

### JSON válido nem sempre tem o formato esperado

- [Exemplo completo](09_json_arquivo_e_memoria/exemplos/04_sintaxe_e_formato_raiz.py)

### Duas maneiras de somar os mesmos saldos

- [Exemplo completo](11_recursao/exemplos/02_iteracao_e_recursao.py)

### Comparar contagens, sem depender do relógio

- [Exemplo completo](13_complexidade_basica/exemplos/02_crescimento_de_percursos.py)

### Primeiro resultado ou todas as correspondências

- [Exemplo completo](14_busca_linear/exemplos/02_primeiro_e_todos.py)

### O índice pertence à lista em que foi encontrado

- [Exemplo completo](15_busca_binaria/exemplos/02_indice_e_lista_ordenada.py)

### Busca linear e binária na mesma entrada

- [Exemplo completo](28_comparar_buscas_ordenacoes_e_indices/exemplos/01_buscas.py)

### Mesma ordem final, trabalho diferente

- [Exemplo completo](28_comparar_buscas_ordenacoes_e_indices/exemplos/02_ordenacoes.py)

### Lista e índice respondem à mesma identidade

- [Exemplo completo](28_comparar_buscas_ordenacoes_e_indices/exemplos/03_indices.py)

## Exercícios da rodada

- [02 — Prever a posição deslocada](02_listas/exercicios/07_prever.py)
- [02 — Corrigir a seleção de saldo](02_listas/exercicios/08_investigar.py)
- [04 — Prever existência e valor](04_dicionarios/exercicios/07_prever.py)
- [04 — Corrigir um teste de ausência](04_dicionarios/exercicios/08_investigar.py)
- [07 — Prever o término de zip](07_funcoes_com_colecoes/exercicios/07_prever.py)
- [07 — Completar uma conferência de correspondência](07_funcoes_com_colecoes/exercicios/08_investigar.py)
- [07 — Comparar duas seleções](07_funcoes_com_colecoes/exercicios/09_prever.py)
- [07 — Completar uma transformação](07_funcoes_com_colecoes/exercicios/10_investigar.py)
- [07 — Prever o objeto padrão](07_funcoes_com_colecoes/exercicios/11_prever.py)
- [07 — Corrigir o padrão de uma função](07_funcoes_com_colecoes/exercicios/12_investigar.py)
- [08 — Prever a borda de leitura](08_arquivos_texto/exercicios/07_prever.py)
- [08 — Completar leitura com informação de falha](08_arquivos_texto/exercicios/08_investigar.py)
- [09 — Prever os tipos após a leitura](09_json_arquivo_e_memoria/exercicios/07_prever.py)
- [09 — Comparar load e loads](09_json_arquivo_e_memoria/exercicios/08_investigar.py)
- [09 — Prever duas validações diferentes](09_json_arquivo_e_memoria/exercicios/09_prever.py)
- [09 — Completar uma borda de leitura](09_json_arquivo_e_memoria/exercicios/10_investigar.py)
- [11 — Rastrear os retornos pendentes](11_recursao/exercicios/07_prever.py)
- [11 — Comparar o controle de término](11_recursao/exercicios/08_investigar.py)
- [13 — Prever crescimento em outra escala](13_complexidade_basica/exercicios/07_prever.py)
- [13 — Comparar duas contagens](13_complexidade_basica/exercicios/08_investigar.py)
- [14 — Prever encerramentos diferentes](14_busca_linear/exercicios/07_prever.py)
- [14 — Completar consultas com contratos distintos](14_busca_linear/exercicios/08_investigar.py)
- [15 — Prever o uso de um índice](15_busca_binaria/exercicios/07_prever.py)
- [15 — Corrigir a recuperação do registro](15_busca_binaria/exercicios/08_investigar.py)
- [28 — Prever o melhor caso](28_comparar_buscas_ordenacoes_e_indices/exercicios/01_prever.py)
- [28 — Comparar incluindo preparação](28_comparar_buscas_ordenacoes_e_indices/exercicios/02_comparar.py)
- [28 — Comparar um contrato comum](28_comparar_buscas_ordenacoes_e_indices/exercicios/03_prever.py)
- [28 — Completar a observação de trabalho](28_comparar_buscas_ordenacoes_e_indices/exercicios/04_comparar.py)
- [28 — Prever uma alteração compartilhada](28_comparar_buscas_ordenacoes_e_indices/exercicios/05_prever.py)
- [28 — Comparar consulta e manutenção](28_comparar_buscas_ordenacoes_e_indices/exercicios/06_comparar.py)
