# Prever o bucket
# Enunciado:
# Em tabela de cinco buckets com índice id % 5, determine os buckets dos ids 1, 6 e 11 e explique por que são três produtos distintos.
#
# Dica:
# Colisão de índice não é igualdade de identidade.
#
# Conferência:
# Os três ficam no bucket um.
#
# Apoio: 20_colisoes/exemplos/01_rede_aplicada.py
