# Atualizar id — Lojas Blue
# Enunciado:
# Insira novamente id 1 com preço simulado diferente, substituindo só o registro desse id.
#
# Dica:
# Colisão não é identidade duplicada.
#
# Conferência:
# Id 6 permanece e o bucket não duplica id 1.
#
# Apoio: 20_colisoes/exemplos/01_rede_aplicada.py
