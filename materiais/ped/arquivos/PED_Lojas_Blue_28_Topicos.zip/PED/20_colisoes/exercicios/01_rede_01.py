# Colisão intencional — Lojas Blue
# Enunciado:
# Use ids 1 e 6 em tabela de tamanho 5 com função módulo.
#
# Dica:
# Mesmo índice exige guardar ambos no bucket.
#
# Conferência:
# Ambos são encontrados.
#
# Apoio: 20_colisoes/exemplos/01_rede_aplicada.py
