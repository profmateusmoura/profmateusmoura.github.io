# Corrigir o compartilhamento de buckets
# Enunciado:
# Uma tabela é criada com [[]] * 5. Mostre o efeito de inserir um produto e corrija a criação dos buckets.
#
# Dica:
# Cada posição precisa receber uma lista diferente.
#
# Conferência:
# Incluir no bucket um não altera os outros quatro.
#
# Apoio: 20_colisoes/exemplos/01_rede_aplicada.py
