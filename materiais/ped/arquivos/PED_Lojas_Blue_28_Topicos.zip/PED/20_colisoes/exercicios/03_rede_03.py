# Remover do bucket — Lojas Blue
# Enunciado:
# Implemente remoção por id sem apagar registros que colidiram.
#
# Dica:
# Procure a posição exata dentro do bucket.
#
# Conferência:
# Remover 1 preserva 6.
#
# Apoio: 20_colisoes/exemplos/01_rede_aplicada.py
