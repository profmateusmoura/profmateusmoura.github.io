# Fator de carga — Lojas Blue
# Enunciado:
# Insira os 20 produtos em 5 buckets e calcule registros divididos por buckets.
#
# Dica:
# O número de buckets não é a quantidade de registros.
#
# Conferência:
# Fator de carga 4.
#
# Apoio: 20_colisoes/exemplos/01_rede_aplicada.py
