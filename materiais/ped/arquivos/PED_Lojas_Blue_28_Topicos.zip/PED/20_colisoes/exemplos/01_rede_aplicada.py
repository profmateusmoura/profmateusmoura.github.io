# Buckets com encadeamento separado — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Ausente: None'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def inserir(tabela, produto):
    """Inclua produto por id; substitua id existente no mesmo bucket."""
    bucket = tabela[produto["id"] % len(tabela)]
    for i in range(len(bucket)):
        existente = bucket[i]
        if existente["id"] == produto["id"]:
            bucket[i] = produto
            return
    bucket.append(produto)

def buscar(tabela, produto_id):
    """Retorne produto encontrado no bucket ou None."""
    bucket = tabela[produto_id % len(tabela)]
    for produto in bucket:
        if produto["id"] == produto_id:
            return produto
    return None

# Cada bucket é uma lista independente; evite [[]] * 5.
tabela = []
for indice in range(5):
    tabela.append([])
for produto in dados["produtos"]:
    inserir(tabela, produto)
print("Produto 4:", buscar(tabela, 4)["nome"])
print("Ausente:", buscar(tabela, 999))
# Colisões não autorizam sobrescrever produtos com ids diferentes.
