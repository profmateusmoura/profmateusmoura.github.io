# Índice por identidade composta — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Saldo na unidade 2: 32'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

indice = {}
for estoque in dados["estoques"]:
    chave = (estoque["unidade_id"], estoque["produto_id"])
    indice[chave] = estoque
print("Saldo na unidade 1:", indice[(1, 1)]["quantidade"])
print("Saldo na unidade 2:", indice[(2, 1)]["quantidade"])
# dict usa hashing internamente. Busca média O(1) não implica pior caso O(1).
# O índice ocupa memória adicional e deve acompanhar mudanças nas identidades.
