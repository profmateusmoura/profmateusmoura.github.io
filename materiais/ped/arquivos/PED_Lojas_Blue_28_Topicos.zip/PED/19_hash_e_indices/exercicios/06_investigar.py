# Corrigir a detecção de duplicata
# Enunciado:
# Construa índice de estoque que relate duplicata antes de sobrescrever o registro anterior.
#
# Dica:
# Verifique presença da chave na etapa de inclusão.
#
# Conferência:
# Duas posições diferentes coexistem; duas identidades iguais geram um conflito.
#
# Apoio: 19_hash_e_indices/exemplos/01_rede_aplicada.py
