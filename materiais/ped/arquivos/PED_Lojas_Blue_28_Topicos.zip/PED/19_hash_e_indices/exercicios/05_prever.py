# Prever uma sobrescrita no índice
# Enunciado:
# Uma base em memória contém duas posições com a mesma chave composta e saldos diferentes. Preveja o efeito de atribuir ambas diretamente ao mesmo dicionário de índice.
#
# Dica:
# Uma chave do dicionário só tem um valor associado por vez.
#
# Conferência:
# A segunda atribuição substitui a primeira.
#
# Apoio: 19_hash_e_indices/exemplos/01_rede_aplicada.py
