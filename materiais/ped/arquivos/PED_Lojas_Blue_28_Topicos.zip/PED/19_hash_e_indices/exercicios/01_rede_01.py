# Índice de produtos — Lojas Blue
# Enunciado:
# Construa dicionário por id e consulte 4 e 999.
#
# Dica:
# get pode representar ausência com None.
#
# Conferência:
# Produto 4 encontrado; 999 ausente.
#
# Apoio: 19_hash_e_indices/exemplos/01_rede_aplicada.py
