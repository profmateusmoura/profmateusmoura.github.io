# Duplicata simulada — Lojas Blue
# Enunciado:
# Em uma cópia, duplique uma identidade com outro saldo e detecte conflito antes de sobrescrever.
#
# Dica:
# Consulte a presença da chave antes de incluir.
#
# Conferência:
# Um conflito é relatado; a fonte permanece intacta.
#
# Apoio: 19_hash_e_indices/exemplos/01_rede_aplicada.py
