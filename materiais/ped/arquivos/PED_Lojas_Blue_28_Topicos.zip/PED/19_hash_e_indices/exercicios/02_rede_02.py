# Índice de estoques — Lojas Blue
# Enunciado:
# Indexe pelo par (unidade_id,produto_id).
#
# Dica:
# Produto sozinho não é chave suficiente.
#
# Conferência:
# Dezoito posições no índice.
#
# Apoio: 19_hash_e_indices/exemplos/01_rede_aplicada.py
