# Mudança de identidade — Lojas Blue
# Enunciado:
# Explique e implemente remoção da chave antiga e inclusão da nova ao mudar unidade_id em uma posição simulada.
#
# Dica:
# Atualizar só o registro deixa índice incoerente.
#
# Conferência:
# A chave antiga não encontra o registro; a nova encontra.
#
# Apoio: 19_hash_e_indices/exemplos/01_rede_aplicada.py
