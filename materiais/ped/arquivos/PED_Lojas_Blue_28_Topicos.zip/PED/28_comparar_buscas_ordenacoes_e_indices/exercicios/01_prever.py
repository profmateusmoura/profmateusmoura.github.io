# Prever o melhor caso
# Enunciado:
# Na lista de ids de um a vinte, compare inspeções para alvo um e para alvo ausente. Explique por que a busca binária não vence toda consulta isolada.
#
# Dica:
# Conte os elementos efetivamente inspecionados.
#
# Conferência:
# Alvo um usa uma inspeção linear; ausência usa vinte lineares e cinco binárias.
#
# Apoio: 28_comparar_buscas_ordenacoes_e_indices/exemplos/01_buscas.py
