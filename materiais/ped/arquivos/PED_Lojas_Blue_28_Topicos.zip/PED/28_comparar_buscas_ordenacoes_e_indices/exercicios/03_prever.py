# Comparar um contrato comum
# Enunciado:
# Use vazio, um produto, preços crescentes, decrescentes e empatados nos três algoritmos. Confira a mesma ordem por (preco,id).
#
# Dica:
# A comparação só faz sentido com o mesmo critério.
#
# Conferência:
# Todos preservam os registros e devolvem a mesma sequência de ids.
#
# Apoio: 28_comparar_buscas_ordenacoes_e_indices/exemplos/02_ordenacoes.py
