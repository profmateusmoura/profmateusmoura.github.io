# Comparar consulta e manutenção
# Enunciado:
# Explique o que deve ser atualizado quando muda apenas quantidade e quando muda unidade_id de uma posição indexada. Implemente os dois casos em uma cópia.
#
# Dica:
# Um campo de identidade também determina a chave do índice.
#
# Conferência:
# Mudar saldo preserva a chave; mudar identidade exige remover a chave antiga e incluir a nova.
#
# Apoio: 28_comparar_buscas_ordenacoes_e_indices/exemplos/03_indices.py
