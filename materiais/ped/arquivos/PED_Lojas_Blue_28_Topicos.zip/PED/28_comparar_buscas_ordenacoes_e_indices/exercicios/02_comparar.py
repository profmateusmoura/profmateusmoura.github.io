# Comparar incluindo preparação
# Enunciado:
# Faça três cenários: uma consulta, cem consultas e uma consulta depois de cada inclusão. Discuta o custo de manter a ordem exigida pela busca binária.
#
# Dica:
# Inclua a organização da entrada na decisão.
#
# Conferência:
# A análise considera consultas e atualizações, e não somente a função buscar.
#
# Apoio: 28_comparar_buscas_ordenacoes_e_indices/exemplos/01_buscas.py
