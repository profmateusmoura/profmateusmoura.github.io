# Completar a observação de trabalho
# Enunciado:
# Acrescente contadores de trocas a Bubble e Selection e de deslocamentos a Insertion. Explique o que cada contador mede.
#
# Dica:
# Uma comparação não é necessariamente seguida de mudança de posição.
#
# Conferência:
# Em entrada ordenada, Insertion não desloca registros.
#
# Apoio: 28_comparar_buscas_ordenacoes_e_indices/exemplos/02_ordenacoes.py
