# Prever uma alteração compartilhada
# Enunciado:
# Construa índice cujos valores são os registros originais da lista. Altere um saldo pelo registro obtido no índice e confira pela lista.
#
# Dica:
# O índice não cria cópias dos registros por si só.
#
# Conferência:
# A mudança aparece nos dois acessos.
#
# Apoio: 28_comparar_buscas_ordenacoes_e_indices/exemplos/03_indices.py
