# Busca linear e binária na mesma entrada
# Execução: python 28_comparar_buscas_ordenacoes_e_indices/exemplos/01_buscas.py
# Confira na saída: 'Alvo 999 linear: (-1, 20) binária: (-1, 5)'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

def linear(ids, alvo):
    """Retorne (índice ou -1, inspeções), sem exigir ordem."""
    inspecoes = 0
    for i, valor in enumerate(ids):
        inspecoes += 1
        if valor == alvo:
            return i, inspecoes
    return -1, inspecoes

def binaria(ids, alvo):
    """Retorne (índice ou -1, inspeções); ids está crescente sem repetição."""
    inicio = 0
    fim = len(ids) - 1
    inspecoes = 0
    while inicio <= fim:
        meio = (inicio + fim) // 2
        inspecoes += 1
        if ids[meio] == alvo:
            return meio, inspecoes
        if ids[meio] < alvo:
            inicio = meio + 1
        else:
            fim = meio - 1
    return -1, inspecoes

# Recorte de ids organizado previamente: o custo dessa preparação não está
# no contador da busca. As duas funções recebem exatamente a mesma lista.
ids = list(range(1, 21))
for alvo in (1, 20, 999):
    print("Alvo", alvo, "linear:", linear(ids, alvo), "binária:", binaria(ids, alvo))
# Encontrar o primeiro registro pode custar menos na busca linear. A vantagem
# de reduzir intervalos descreve crescimento e pior caso, não todas as consultas.
