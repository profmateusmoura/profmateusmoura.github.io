# Lista e índice respondem à mesma identidade
# Execução: python -m 28_comparar_buscas_ordenacoes_e_indices.exemplos.03_indices
# Confira na saída: 'Unidade 2 lista: 32 índice: 32'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

from dados.acesso import carregar_dados

def buscar_na_lista(estoques, unidade_id, produto_id):
    """Retorne registro ou None após conferir as duas partes da identidade."""
    for estoque in estoques:
        if estoque["unidade_id"] == unidade_id and estoque["produto_id"] == produto_id:
            return estoque
    return None

dados = carregar_dados()
indice = {}
for estoque in dados["estoques"]:
    indice[(estoque["unidade_id"], estoque["produto_id"])] = estoque
for unidade_id in (1, 2):
    pela_lista = buscar_na_lista(dados["estoques"], unidade_id, 1)
    pelo_indice = indice.get((unidade_id, 1))
    print("Unidade", unidade_id, "lista:", pela_lista["quantidade"], "índice:", pelo_indice["quantidade"])
# O índice exige construção e memória adicional. Seus valores aqui são os
# mesmos registros da lista, então mudar saldo é observado pelos dois acessos.
