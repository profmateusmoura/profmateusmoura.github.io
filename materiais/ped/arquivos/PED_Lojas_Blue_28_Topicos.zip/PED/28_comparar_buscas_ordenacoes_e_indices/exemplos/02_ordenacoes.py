# Mesma ordem final, trabalho diferente
# Execução: python 28_comparar_buscas_ordenacoes_e_indices/exemplos/02_ordenacoes.py
# Confira na saída: 'selection ids: [20, 1, 4] comparações: 3'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

def chave(produto):
    """Retorne o critério compartilhado pelos três algoritmos."""
    return produto["preco"], produto["id"]

def bubble(produtos):
    """Retorne cópia ordenada e número de comparações de chaves adjacentes."""
    resultado = produtos.copy()
    comparacoes = 0
    for fim in range(len(resultado) - 1, 0, -1):
        mudou = False
        for i in range(fim):
            comparacoes += 1
            if chave(resultado[i]) > chave(resultado[i + 1]):
                resultado[i], resultado[i + 1] = resultado[i + 1], resultado[i]
                mudou = True
        if not mudou:
            break
    return resultado, comparacoes

def selection(produtos):
    """Retorne cópia ordenada e quantidade de comparações na seleção."""
    resultado = produtos.copy()
    comparacoes = 0
    for inicio in range(len(resultado) - 1):
        menor = inicio
        for candidato in range(inicio + 1, len(resultado)):
            comparacoes += 1
            if chave(resultado[candidato]) < chave(resultado[menor]):
                menor = candidato
        resultado[inicio], resultado[menor] = resultado[menor], resultado[inicio]
    return resultado, comparacoes

def insertion(produtos):
    """Retorne cópia ordenada e quantidade de comparações entre chaves."""
    resultado = produtos.copy()
    comparacoes = 0
    for i in range(1, len(resultado)):
        atual = resultado[i]  # Preserve o objeto antes de deslocar o prefixo.
        j = i - 1
        while j >= 0:
            comparacoes += 1
            if chave(resultado[j]) <= chave(atual):
                break
            resultado[j + 1] = resultado[j]
            j -= 1
        resultado[j + 1] = atual
    return resultado, comparacoes

# Uma entrada já organizada evidencia a parada antecipada de Bubble e a
# seleção que continua procurando o menor de cada trecho, mesmo sem trocar.
produtos = [{"id": 20, "preco": 7.9}, {"id": 1, "preco": 24.9}, {"id": 4, "preco": 129.9}]
for algoritmo in (bubble, selection, insertion):
    ordenados, comparacoes = algoritmo(produtos)
    print(algoritmo.__name__, "ids:", [p["id"] for p in ordenados], "comparações:", comparacoes)
# Todas usam (preço,id) e preservam a entrada. Contar comparações não inclui
# toda operação executada: deslocamentos e trocas são outras medidas possíveis.
