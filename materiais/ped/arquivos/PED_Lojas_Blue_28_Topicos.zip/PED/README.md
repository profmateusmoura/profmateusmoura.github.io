# PED — Programação 1: Lojas Blue

Trilha contextualizada com **52 exemplos executáveis e 192 exercícios sem solução**, em 28 tópicos.
Pré-requisito: ALP completo; nenhuma classe é exigida.

Leia [CONTEXTO_LOJAS_BLUE.md](CONTEXTO_LOJAS_BLUE.md) e siga [ORDEM_DE_ESTUDO.md](ORDEM_DE_ESTUDO.md).
Use Python 3.10 ou superior e UTF-8. Só há dependências da biblioteca padrão; não precisa instalar o projeto ou usar pip.
Cada arquivo é independente. Execute um exemplo por vez em um terminal:

```text
python 01_strings/exemplos/01_fundamento.py
```

No Windows, `py -3` pode substituir `python`. Os exemplos não pedem entrada interativa.
Atividades contêm somente comentários, com enunciado, dica, conferência e referência de apoio.
As funções e classes dos exemplos possuem docstrings.
Todos os tópicos usam `exemplos/` e `exercicios/`.

## Base de dados e saídas

`dados/lojas_blue.json` preserva os registros da fotografia fornecida em PRI; o arquivo foi renomeado para acompanhar a marca Lojas Blue.
A leitura localiza a base a partir do arquivo de acesso ou do próprio exemplo. Quando o cabeçalho indicar python -m, execute esse comando na raiz do curso para disponibilizar os módulos de apoio.
Relatórios e simulações gravados vão para `saidas/` na pasta em que o terminal foi aberto.
Exemplos de gravação substituem apenas seus arquivos de saída nomeados; a base fornecida é de leitura.
Recortes escritos no código não dependem de arquivo e trazem os dados necessários para a atividade.
Valores novos são simulações isoladas, não sincronizações com outros cursos.

## Método

1. Leia os conceitos e o contrato do tópico.
2. Preveja, execute e modifique o exemplo de forma controlada.
3. Resolva as atividades do tópico em ordem, consultando o índice completo. As últimas combinam padrões já conhecidos.
4. Confira caso comum, fronteira e ausência/falha quando aplicável.
5. Explique o estado inicial, a mudança e o resultado antes de avançar.

Todo preço em PED conserva o formato da fotografia; POO usa centavos inteiros no domínio.
Nenhum exercício precisa supor itens de pedido que não existem na fonte.

## Relação com PRI

PRI foi consultado como inspiração de domínio, esquema e aplicações; seu conteúdo permanece preservado.
Esta trilha foi escrita separadamente: acrescenta strings e conjuntos, coloca coleções antes de arquivos/JSON,
explicita recursão antes de árvores e mantém implementações procedurais.
Os algoritmos de busca, ordenação e colisões ficam visíveis nos exemplos, sem bibliotecas que escondam a implementação.
A parte de árvores introduz os conceitos e oferece AVL como desafio avançado.
Esta edição não é uma cópia integral dos 27 diretórios de PRI nem impõe o cronograma de 15 encontros de lá.

## Módulo de acesso aos dados

Depois do tópico 09 de PED, estude o [exemplo complementar](exemplo_acesso_dados.py)
e a [documentação do módulo dados](dados/README.md). `dados/acesso.py` centraliza leitura,
consultas comuns e gravação de cópias. Os exemplos da sequência continuam disponíveis.

## Progressão e prática

Siga o [problema evolutivo de reposição](PROBLEMA_EVOLUTIVO.md), com os mesmos dados e resultados de referência nas três disciplinas. Use o [índice de atividades por tipo](ATIVIDADES_POR_TIPO.md) para alternar implementação, previsão, investigação e comparação.

O [percurso essencial e seus desafios](PERCURSO_ESSENCIAL.md) orienta a entrada em listas encadeadas, árvores e AVL e explica o uso gradual do módulo de acesso. O dicionário de campos e relacionamentos está em [dados/README.md](dados/README.md).

Consulte [APROFUNDAMENTO_E_COMPARACOES.md](APROFUNDAMENTO_E_COMPARACOES.md) para as novas explicações, comparações e exercícios.

## Licenças

Copyright (c) 2026 Mateus Moura (@profmateusmoura).

Este repositório aplica uma licença ao código e outra ao conteúdo didático,
conforme o escopo abaixo. Cada licença se aplica ao respectivo material;
não se trata de uma escolha entre duas licenças para o mesmo conteúdo.

| Material | Licença |
|---|---|
| Exemplos executáveis em `.py`, incluindo seus comentários e docstrings | MIT |
| Módulos auxiliares em `.py` e seus comentários e docstrings | MIT |
| Enunciados, dicas e casos de conferência em `exercicios/*.py`, que contêm apenas comentários | CC BY 4.0 |
| Guias, explicações e demais documentos didáticos em `.md` | CC BY 4.0 |
| Base de dados fictícia (`dados/lojas_blue.json`) | CC BY 4.0 |

O texto integral da **MIT** está em [LICENSE](LICENSE). Ao redistribuir o código,
preserve o aviso de direitos autorais e o aviso de permissão dessa licença.

O texto integral da **Creative Commons Atribuição 4.0 Internacional (CC BY 4.0)**
está em [LICENSE-CONTENT](LICENSE-CONTENT). Ao compartilhar o material didático,
atribua crédito, indique a licença, preserve as informações exigidas por ela e
informe as alterações realizadas. Consulte também o
[resumo em português](https://creativecommons.org/licenses/by/4.0/deed.pt-br).

As duas licenças permitem uso comercial. Para citar o material didático, identifique
“PED — Mateus Moura (@profmateusmoura)”, inclua o endereço do repositório de origem e a referência
à CC BY 4.0; se adaptar o conteúdo, descreva as alterações.

Materiais de terceiros identificados com licença própria conservam seus respectivos
avisos e condições. Os textos integrais das licenças são reproduzidos sem alterações
em seus termos; esta seção delimita sua aplicação ao material do repositório.
