# Relacionar produto, unidade e estoque — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Posições críticas: 7'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

produtos = {}
for produto in dados["produtos"]:
    produtos[produto["id"]] = produto
unidades = {}
for unidade in dados["unidades"]:
    unidades[unidade["id"]] = unidade
criticos = 0
for estoque in dados["estoques"]:
    if estoque["quantidade"] < estoque["minimo"]:
        criticos += 1
        # São relações por id, não por posição na lista.
        nome = produtos[estoque["produto_id"]]["nome"]
        unidade = unidades[estoque["unidade_id"]]["nome"]
        print(unidade, "->", nome)
print("Posições críticas:", criticos)
