# Corrigir uma referência
# Enunciado:
# Uma consulta usa produtos[produto_id] supondo que id seja posição na lista. Reescreva a resolução para funcionar se os produtos forem reordenados.
#
# Dica:
# Identidade precisa ser consultada, e não usada como índice de sequência.
#
# Conferência:
# Reordenar o catálogo não muda o nome obtido para id 4.
#
# Apoio: 10_relacionamentos_e_consistencia/exemplos/01_rede_aplicada.py
