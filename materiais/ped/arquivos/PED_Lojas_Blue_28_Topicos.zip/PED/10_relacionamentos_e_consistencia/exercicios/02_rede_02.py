# Validar referências — Lojas Blue
# Enunciado:
# Verifique se todas as posições apontam para produto e unidade existentes.
#
# Dica:
# Separe ids válidos e relações.
#
# Conferência:
# Nenhuma referência ausente na base original.
#
# Apoio: 10_relacionamentos_e_consistencia/exemplos/01_rede_aplicada.py
