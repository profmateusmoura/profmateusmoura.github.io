# Prever a chave de uma posição
# Enunciado:
# Compare um índice de estoques só por produto_id com outro pelo par unidade_id/produto_id. Use produto 1 nas unidades 1 e 2 e explique a perda possível.
#
# Dica:
# O mesmo produto pertence a mais de uma unidade.
#
# Conferência:
# As duas posições precisam manter os saldos 18 e 32.
#
# Apoio: 10_relacionamentos_e_consistencia/exemplos/01_rede_aplicada.py
