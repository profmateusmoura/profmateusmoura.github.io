# Erro simulado — Lojas Blue
# Enunciado:
# Em cópia de memória, inclua uma posição com produto_id 999 e relate a inconsistência sem interromper as demais verificações.
#
# Dica:
# A base original fica intacta.
#
# Conferência:
# Um erro de produto inexistente.
#
# Apoio: 10_relacionamentos_e_consistencia/exemplos/01_rede_aplicada.py
