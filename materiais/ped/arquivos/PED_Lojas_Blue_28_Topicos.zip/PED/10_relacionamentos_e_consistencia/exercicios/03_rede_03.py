# Identidade completa — Lojas Blue
# Enunciado:
# Consulte produto 1 nas unidades 1 e 2.
#
# Dica:
# A chave inclui unidade e produto.
#
# Conferência:
# Saldos 18 e 32, respectivamente.
#
# Apoio: 10_relacionamentos_e_consistencia/exemplos/01_rede_aplicada.py
