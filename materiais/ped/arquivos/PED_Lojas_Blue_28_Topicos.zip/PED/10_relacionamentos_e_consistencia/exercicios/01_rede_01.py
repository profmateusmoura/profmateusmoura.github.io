# Resolver nomes — Lojas Blue
# Enunciado:
# Liste unidade e nome de produto para cada posição crítica.
#
# Dica:
# Crie índices por id; não trate id como posição.
#
# Conferência:
# Sete linhas.
#
# Apoio: 10_relacionamentos_e_consistencia/exemplos/01_rede_aplicada.py
