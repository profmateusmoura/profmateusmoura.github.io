# Prever os deslocamentos
# Enunciado:
# Em preços [10, 30, 20], preveja o que Insertion desloca ao inserir 20 no prefixo organizado.
#
# Dica:
# Preserve o item atual antes de sobrescrever posições.
#
# Conferência:
# O 30 desloca uma posição e 20 entra entre 10 e 30.
#
# Apoio: 18_insertion_sort/exemplos/01_rede_aplicada.py
