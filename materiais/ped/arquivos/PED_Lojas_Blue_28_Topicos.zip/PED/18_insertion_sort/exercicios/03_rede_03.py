# Fronteira inicial — Lojas Blue
# Enunciado:
# Teste lista com dois registros invertidos.
#
# Dica:
# Verifique j >= 0 antes de acessar.
#
# Conferência:
# Nenhum acesso indevido ao fim da lista por índice negativo.
#
# Apoio: 18_insertion_sort/exemplos/01_rede_aplicada.py
