# Quase organizado — Lojas Blue
# Enunciado:
# Compare deslocamentos de lista ordenada e de lista com dois últimos trocados.
#
# Dica:
# Conte deslocamentos, não apenas voltas externas.
#
# Conferência:
# A lista ordenada não desloca registros.
#
# Apoio: 18_insertion_sort/exemplos/01_rede_aplicada.py
