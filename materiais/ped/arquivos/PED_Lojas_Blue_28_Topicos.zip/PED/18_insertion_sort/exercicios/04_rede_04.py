# Comparar algoritmos — Lojas Blue
# Enunciado:
# Rode Bubble, Selection e Insertion no mesmo recorte e confira igualdade dos ids resultantes.
#
# Dica:
# Use o mesmo desempate.
#
# Conferência:
# Todas as saídas têm os mesmos ids na mesma ordem.
#
# Apoio: 18_insertion_sort/exemplos/01_rede_aplicada.py
