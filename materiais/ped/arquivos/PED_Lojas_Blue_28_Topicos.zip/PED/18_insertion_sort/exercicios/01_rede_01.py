# Insertion por preço — Lojas Blue
# Enunciado:
# Ordene cópia de produtos com deslocamento do prefixo organizado, por (preco,id).
#
# Dica:
# Preserve o registro atual antes de deslocar.
#
# Conferência:
# Primeiro produto 20.
#
# Apoio: 18_insertion_sort/exemplos/01_rede_aplicada.py
