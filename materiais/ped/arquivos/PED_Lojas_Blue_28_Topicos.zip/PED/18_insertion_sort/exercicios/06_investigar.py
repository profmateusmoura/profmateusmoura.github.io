# Corrigir a fronteira do índice
# Enunciado:
# Uma versão acessa resultado[j] antes de conferir j >= 0. Reorganize a condição e teste dois produtos em ordem inversa.
#
# Dica:
# Em Python, índice negativo também acessa um elemento válido.
#
# Conferência:
# O algoritmo termina com os dois registros ordenados sem usar o fim da lista como parte do prefixo.
#
# Apoio: 18_insertion_sort/exemplos/01_rede_aplicada.py
