# Inserir no prefixo organizado — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Mais barato: Sabonete em Barra'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def insertion(produtos):
    """Retorne cópia ordenada por (preco, id), deslocando chaves maiores."""
    resultado = produtos.copy()
    for i in range(1, len(resultado)):
        # Guarde o registro atual antes dos deslocamentos, para não perdê-lo ao sobrescrever
        # sua posição.
        atual = resultado[i]
        chave = (atual["preco"], atual["id"])
        j = i - 1
        # O teste do limite vem primeiro. Só com índice válido é possível comparar o registro
        # do prefixo.
        while j >= 0 and (resultado[j]["preco"], resultado[j]["id"]) > chave:
            # O elemento maior é deslocado para abrir uma posição; ainda falta inserir o
            # registro que foi preservado.
            resultado[j + 1] = resultado[j]
            j -= 1
        # A posição livre recebe o registro atual, mantendo o prefixo organizado após a
        # passagem.
        resultado[j + 1] = atual
    return resultado

ordenados = insertion(dados["produtos"])
print("Mais barato:", ordenados[0]["nome"])
# O teste j >= 0 vem antes do acesso, para não usar índice negativo por engano.
