# TAD estoque com funções — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Saldo: 15'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def criar_estoque(saldo):
    """Crie estado para saldo inteiro não negativo, ou recuse com ValueError."""
    if not isinstance(saldo, int) or isinstance(saldo, bool) or saldo < 0:
        raise ValueError("Saldo inválido")
    return {"saldo": saldo}

def retirar(estoque, quantidade):
    """Retire inteiro positivo disponível; retorne bool sem mudar em falha."""
    if not isinstance(quantidade, int) or isinstance(quantidade, bool):
        return False
    if quantidade <= 0 or quantidade > estoque["saldo"]:
        return False
    estoque["saldo"] -= quantidade
    return True

estado = criar_estoque(dados["estoques"][0]["quantidade"])
print("Retirada aceita:", retirar(estado, 3))
print("Retirada excessiva:", retirar(estado, 99))
print("Saldo:", estado["saldo"])
# O comportamento é um contrato, mesmo sem classe; clientes usam as funções.
