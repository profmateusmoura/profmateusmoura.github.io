# Corrigir o contrato
# Enunciado:
# Uma função de retirada subtrai antes de testar o saldo. Reescreva para validar formato, positividade e disponibilidade antes de atualizar.
#
# Dica:
# Todos os caminhos de recusa precisam preservar o estado.
#
# Conferência:
# Quantidade 0, True e 19 não alteram saldo 18.
#
# Apoio: 12_tads_procedurais/exemplos/01_rede_aplicada.py
