# Reposição — Lojas Blue
# Enunciado:
# Acrescente receber para entrada inteira positiva; falha preserva saldo.
#
# Dica:
# Valide antes de alterar.
#
# Conferência:
# Saldo 4 receber 4: saldo 8; receber zero: falha.
#
# Apoio: 12_tads_procedurais/exemplos/01_rede_aplicada.py
