# Contrato de retirada — Lojas Blue
# Enunciado:
# Implemente criar e retirar para saldo inteiro não negativo e retirada inteira positiva disponível. Retirada inválida retorna False e preserva estado.
#
# Dica:
# Use funções como interface do TAD.
#
# Conferência:
# 18 retirar 3: saldo 15; retirar 99: preserva 15.
#
# Apoio: 12_tads_procedurais/exemplos/01_rede_aplicada.py
