# Prever uma sequência do TAD
# Enunciado:
# Comece com saldo 18. Preveja retorno e estado após retirar 3, retirar 99 e retirar 15, usando o contrato procedural do tópico.
#
# Dica:
# Uma falha retorna False e preserva o saldo.
#
# Conferência:
# Estados 15, 15 e 0; retornos True, False e True.
#
# Apoio: 12_tads_procedurais/exemplos/01_rede_aplicada.py
