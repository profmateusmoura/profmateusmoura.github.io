# Comparar representações — Lojas Blue
# Enunciado:
# Reimplemente o estado com outra organização interna e preserve os nomes e contratos das operações.
#
# Dica:
# O cliente deveria depender das operações, não das chaves internas.
#
# Conferência:
# A mesma sequência de operações produz os mesmos saldos.
#
# Apoio: 12_tads_procedurais/exemplos/01_rede_aplicada.py
