# Consulta — Lojas Blue
# Enunciado:
# Acrescente consultar que retorna saldo sem alterar o estado.
#
# Dica:
# Documente o retorno escalar.
#
# Conferência:
# Duas consultas seguidas retornam o mesmo valor.
#
# Apoio: 12_tads_procedurais/exemplos/01_rede_aplicada.py
