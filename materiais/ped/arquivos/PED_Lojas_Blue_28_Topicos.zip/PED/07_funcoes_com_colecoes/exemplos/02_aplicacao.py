# Aplicação: Filtrar sem alterar o catálogo — cenário didático Lojas Blue
# Objetivo: Combinar o recurso com conceitos já estudados.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Concluídos: 89.70'
# Sem entrada interativa.

def total_por_status(pedidos, status):
    """Some os totais dos pedidos com o status exato; vazio retorna zero."""
    total = 0.0
    for pedido in pedidos:
        if pedido["status"] == status:
            total += pedido["total"]
    return total

recorte = [{"status": "CONCLUIDO", "total": 89.7}, {"status": "PENDENTE", "total": 129.9}]
print(f"Concluídos: {total_por_status(recorte, 'CONCLUIDO'):.2f}")

def chave_total(pedido):
    """Retorne a chave numérica usada pelo ordenador pronto do Python."""
    return pedido["total"]

# key recebe uma função: o ordenador a chama para comparar cada registro.
# Aqui usamos uma ferramenta pronta; algoritmos explícitos vêm em 16–18.
ordenados = sorted(recorte, key=chave_total)
print("Menor total no recorte:", ordenados[0]["total"])
