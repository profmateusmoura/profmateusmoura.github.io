# Índice acompanhado do valor e percursos paralelos
# Execução: python 07_funcoes_com_colecoes/exemplos/03_enumerate_zip.py
# Confira na saída: "Pares com tamanhos diferentes: [('A', 10)]"
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

nomes = ["Shampoo", "Perfume", "Sabonete"]
precos = [24.9, 129.9, 7.9]
# enumerate entrega pares de índice e valor; start muda só a numeração exibida.
for ordem, nome in enumerate(nomes, start=1):
    print("Etiqueta", ordem, nome)
# zip entrega um par por posição correspondente. Aqui sabemos que as listas
# descrevem o mesmo recorte, na mesma ordem e com a mesma quantidade.
for nome, preco in zip(nomes, precos):
    print(f"{nome}: {preco:.2f}")
# Sem strict, zip encerra quando termina a menor entrada.
pares = list(zip(["A", "B"], [10]))
print("Pares com tamanhos diferentes:", pares)
# Essa regra exige conferir os comprimentos quando toda correspondência importa.
