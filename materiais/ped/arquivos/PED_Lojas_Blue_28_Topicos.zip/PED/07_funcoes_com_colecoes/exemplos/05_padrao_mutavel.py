# Quando um argumento padrão guarda estado entre chamadas
# Execução: python 07_funcoes_com_colecoes/exemplos/05_padrao_mutavel.py
# Confira na saída: "Nova lista, chamada 2: ['Perfume']"
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

def registrar_com_padrao_compartilhado(nome, nomes=[]):
    """Contraexemplo intencional: acumule na mesma lista padrão entre chamadas."""
    nomes.append(nome)
    return nomes

def registrar_com_nova_lista(nome, nomes=None):
    """Use nova lista quando o chamador não fornecer uma coleção."""
    # O padrão é None; o teste abaixo acontece a cada chamada. A lista nova
    # é construída aqui, somente quando não foi fornecida pelo chamador.
    if nomes is None:
        nomes = []
    nomes.append(nome)
    return nomes

print("Compartilhada, chamada 1:", registrar_com_padrao_compartilhado("Shampoo"))
print("Compartilhada, chamada 2:", registrar_com_padrao_compartilhado("Perfume"))
print("Nova lista, chamada 1:", registrar_com_nova_lista("Shampoo"))
print("Nova lista, chamada 2:", registrar_com_nova_lista("Perfume"))
