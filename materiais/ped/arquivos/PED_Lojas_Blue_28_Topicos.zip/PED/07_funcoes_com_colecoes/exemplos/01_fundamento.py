# Filtrar sem alterar o catálogo — cenário didático Lojas Blue
# Objetivo: Introduzir o recurso com um recorte da rede.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Saldo original: 4'
# Sem entrada interativa.

def abaixo_do_minimo(estoques):
    """Retorne nova lista com cópias dos registros críticos recebidos."""
    resultado = []
    for estoque in estoques:
        if estoque["quantidade"] < estoque["minimo"]:
            resultado.append(estoque.copy())
    return resultado

originais = [{"quantidade": 4, "minimo": 8}, {"quantidade": 10, "minimo": 10}]
selecionados = abaixo_do_minimo(originais)
selecionados[0]["quantidade"] = 0
print("Saldo original:", originais[0]["quantidade"])
# copy é rasa, suficiente neste registro que só contém inteiros.
