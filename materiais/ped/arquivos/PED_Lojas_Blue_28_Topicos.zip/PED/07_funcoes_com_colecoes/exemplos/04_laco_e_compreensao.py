# A mesma seleção com laço e compreensão
# Execução: python 07_funcoes_com_colecoes/exemplos/04_laco_e_compreensao.py
# Confira na saída: 'Faltas: [6, 4]'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

saldos = [18, 4, 25, 6]
por_laco = []
for saldo in saldos:
    if saldo < 10:
        por_laco.append(saldo)
# A compreensão tem expressão produzida, percurso e condição opcional.
# Ela cria outra lista; a lista de origem não é alterada.
por_compreensao = [saldo for saldo in saldos if saldo < 10]
print("Com laço:", por_laco)
print("Com compreensão:", por_compreensao)
# Também é possível transformar valores enquanto se percorre a origem.
faltas = [10 - saldo for saldo in saldos if saldo < 10]
print("Faltas:", faltas)
# Prefira o laço quando houver muitas decisões ou efeitos, para explicitar etapas.
