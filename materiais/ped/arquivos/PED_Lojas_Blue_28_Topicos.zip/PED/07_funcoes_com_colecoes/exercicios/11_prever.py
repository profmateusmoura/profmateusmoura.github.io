# Prever o objeto padrão
# Enunciado:
# Preveja o conteúdo acumulado depois de três chamadas sem segundo argumento na versão de padrão lista. Explique quando a lista padrão foi criada.
#
# Dica:
# O valor padrão é preparado na definição da função.
#
# Conferência:
# As três chamadas usam a mesma lista padrão.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/05_padrao_mutavel.py
