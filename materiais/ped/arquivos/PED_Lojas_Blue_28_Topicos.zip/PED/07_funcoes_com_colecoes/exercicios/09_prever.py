# Comparar duas seleções
# Enunciado:
# Reescreva uma compreensão de saldos críticos como laço e confirme igualdade das duas saídas para vazio, todos críticos e nenhum crítico.
#
# Dica:
# A condição precisa ser a mesma nas duas versões.
#
# Conferência:
# Os resultados coincidem sem alterar os saldos de entrada.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/04_laco_e_compreensao.py
