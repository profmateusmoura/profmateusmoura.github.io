# Completar uma transformação
# Enunciado:
# A partir de registros de produto, produza uma lista de nomes com preço até trinta usando laço e compreensão. Compare as soluções.
#
# Dica:
# A expressão produz o nome; a condição usa o preço do mesmo registro.
#
# Conferência:
# O shampoo de 24.90 participa; o perfume de 129.90 não participa.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/04_laco_e_compreensao.py
