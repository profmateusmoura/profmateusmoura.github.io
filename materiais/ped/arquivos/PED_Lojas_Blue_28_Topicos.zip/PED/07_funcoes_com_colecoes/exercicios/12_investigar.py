# Corrigir o padrão de uma função
# Enunciado:
# Implemente registrar(nome, nomes=None) para criar lista nova quando omitida e atualizar a lista recebida quando fornecida. Documente esse efeito.
#
# Dica:
# Omitir uma coleção e receber uma coleção têm contratos diferentes.
#
# Conferência:
# Chamadas sem lista são independentes; chamada com lista fornecida acrescenta nela.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/05_padrao_mutavel.py
