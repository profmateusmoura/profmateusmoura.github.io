# Retornar nomes — Lojas Blue
# Enunciado:
# Receba lista de produtos e devolva nova lista com seus nomes, preservando a ordem e sem imprimir.
#
# Dica:
# Separe transformação de apresentação.
#
# Conferência:
# Lista vazia retorna vazia; lista de dois produtos retorna dois nomes.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/01_fundamento.py, 07_funcoes_com_colecoes/exemplos/02_aplicacao.py
