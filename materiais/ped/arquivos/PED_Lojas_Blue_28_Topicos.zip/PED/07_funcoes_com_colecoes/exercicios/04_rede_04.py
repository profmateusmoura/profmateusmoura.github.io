# Resumo por UF — Lojas Blue
# Enunciado:
# Receba lista de unidades e devolva dicionário de UF para quantidade, sem imprimir.
#
# Dica:
# Comece grupos desconhecidos em zero.
#
# Conferência:
# Duas unidades MG e uma SP: MG 2, SP 1.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/01_fundamento.py, 07_funcoes_com_colecoes/exemplos/02_aplicacao.py
