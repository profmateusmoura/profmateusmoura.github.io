# Prever o término de zip
# Enunciado:
# Preveja quantos pares são produzidos com três nomes e dois preços. Explique qual registro ficaria sem correspondência.
#
# Dica:
# O percurso termina na menor entrada.
#
# Conferência:
# Dois pares; o terceiro nome não participa.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/03_enumerate_zip.py
