# Prever o retorno selecionado
# Enunciado:
# Uma função retorna uma nova lista dos registros críticos, mas inclui nela os próprios registros originais. Preveja o efeito de alterar um registro selecionado.
#
# Dica:
# Nova lista não significa novos registros.
#
# Conferência:
# A alteração aparece no registro da origem.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/01_fundamento.py, 07_funcoes_com_colecoes/exemplos/02_aplicacao.py
