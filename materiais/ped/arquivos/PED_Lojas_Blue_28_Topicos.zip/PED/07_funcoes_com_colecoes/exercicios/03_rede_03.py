# Total de pedidos — Lojas Blue
# Enunciado:
# Receba lista de pedidos e status e some somente os totais correspondentes.
#
# Dica:
# O vazio deve ter resultado zero.
#
# Conferência:
# Recorte concluído 89.7 e pendente 129.9: concluídos 89.70.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/01_fundamento.py, 07_funcoes_com_colecoes/exemplos/02_aplicacao.py
