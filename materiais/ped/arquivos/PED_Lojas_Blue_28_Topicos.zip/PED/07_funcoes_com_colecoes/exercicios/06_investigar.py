# Completar uma transformação
# Enunciado:
# Implemente nomes_dos_produtos(produtos), retornando nova lista com nomes na ordem de entrada. A função deve funcionar com entrada vazia e não imprimir.
#
# Dica:
# Cada registro contribui com um texto.
#
# Conferência:
# Dois produtos produzem dois nomes; vazio produz lista vazia.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/01_fundamento.py, 07_funcoes_com_colecoes/exemplos/02_aplicacao.py
