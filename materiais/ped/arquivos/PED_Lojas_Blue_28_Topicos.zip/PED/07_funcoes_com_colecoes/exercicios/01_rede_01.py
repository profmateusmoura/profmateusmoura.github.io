# Função de filtragem — Lojas Blue
# Enunciado:
# Receba lista de posições e retorne cópias das críticas sem modificar a entrada.
#
# Dica:
# Teste se alterações no resultado afetam a origem.
#
# Conferência:
# Lista vazia retorna vazia; saldo igual ao mínimo fica de fora.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/01_fundamento.py, 07_funcoes_com_colecoes/exemplos/02_aplicacao.py
