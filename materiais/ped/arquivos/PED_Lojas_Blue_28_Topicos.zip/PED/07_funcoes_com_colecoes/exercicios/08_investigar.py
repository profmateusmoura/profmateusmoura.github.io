# Completar uma conferência de correspondência
# Enunciado:
# Receba listas de nomes e preços e recuse comprimentos diferentes antes de produzir pares. Use enumerate para numerar as etiquetas.
#
# Dica:
# Confira quantidade antes de combinar posições.
#
# Conferência:
# Três nomes e dois preços devem gerar recusa, e não relatório incompleto.
#
# Apoio: 07_funcoes_com_colecoes/exemplos/03_enumerate_zip.py
