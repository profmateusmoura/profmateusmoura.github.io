# Vários registros de estoque — cenário didático Lojas Blue
# Objetivo: Introduzir o recurso com um recorte da rede.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Críticos no recorte: 1'
# Sem entrada interativa.

estoques = [
    {"unidade_id": 1, "produto_id": 1, "quantidade": 18, "minimo": 10},
    {"unidade_id": 1, "produto_id": 4, "quantidade": 4, "minimo": 8},
]
criticos = []
for estoque in estoques:
    if estoque["quantidade"] < estoque["minimo"]:
        criticos.append(estoque)
print("Críticos no recorte:", len(criticos))
print("Produto com falta:", criticos[0]["produto_id"])
