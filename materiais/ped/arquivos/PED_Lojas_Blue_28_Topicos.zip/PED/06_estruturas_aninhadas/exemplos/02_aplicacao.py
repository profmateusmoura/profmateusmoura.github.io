# Aplicação: Vários registros de estoque — cenário didático Lojas Blue
# Objetivo: Combinar o recurso com conceitos já estudados.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'MG tem 2 unidades no recorte'
# Sem entrada interativa.

rede = {"MG": ["Sete Lagoas Centro", "Contagem Eldorado"], "SP": ["São Paulo Centro"]}
for uf, nomes in rede.items():
    print(uf, "tem", len(nomes), "unidades no recorte")
# Um dicionário pode conter listas; o percurso respeita esses dois níveis.
