# Prever a cópia externa
# Enunciado:
# Considere estoques = [{"quantidade": 4}] e simulacao = estoques.copy(). Preveja o saldo original depois de simulacao[0]["quantidade"] = 0.
#
# Dica:
# A nova lista ainda referencia o mesmo dicionário.
#
# Conferência:
# O original também passa a mostrar zero.
#
# Apoio: 06_estruturas_aninhadas/exemplos/01_fundamento.py, 06_estruturas_aninhadas/exemplos/02_aplicacao.py
