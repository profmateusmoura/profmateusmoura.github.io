# Agrupar por UF — Lojas Blue
# Enunciado:
# Use registros de Sete Lagoas Centro em MG e São Paulo Centro em SP. Construa dicionário de UF para lista de nomes.
#
# Dica:
# Crie a lista do grupo quando necessário.
#
# Conferência:
# MG e SP ficam com um nome cada.
#
# Apoio: 06_estruturas_aninhadas/exemplos/01_fundamento.py, 06_estruturas_aninhadas/exemplos/02_aplicacao.py
