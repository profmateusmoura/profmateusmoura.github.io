# Corrigir o isolamento
# Enunciado:
# Refaça a simulação anterior copiando cada registro, para permitir alterar quantidade e minimo sem afetar a origem.
#
# Dica:
# Cada registro deste exercício tem apenas valores escalares.
#
# Conferência:
# A simulação muda e o saldo original permanece quatro.
#
# Apoio: 06_estruturas_aninhadas/exemplos/01_fundamento.py, 06_estruturas_aninhadas/exemplos/02_aplicacao.py
