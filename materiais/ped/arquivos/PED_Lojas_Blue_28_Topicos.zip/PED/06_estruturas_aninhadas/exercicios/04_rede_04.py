# Cópia de registros — Lojas Blue
# Enunciado:
# Copie a lista anterior e também cada registro antes de simular mudanças. Explique a diferença para copiar só a lista externa.
#
# Dica:
# As referências internas também podem ser compartilhadas.
#
# Conferência:
# Uma mudança na simulação não deve atingir o original.
#
# Apoio: 06_estruturas_aninhadas/exemplos/01_fundamento.py, 06_estruturas_aninhadas/exemplos/02_aplicacao.py
