# Atualização localizada — Lojas Blue
# Enunciado:
# Nas duas posições do primeiro exercício, altere apenas o saldo do produto 4 para 8.
#
# Dica:
# Verifique as duas partes da identidade da posição.
#
# Conferência:
# Produto 1 continua com 18; nenhum crítico após a mudança.
#
# Apoio: 06_estruturas_aninhadas/exemplos/01_fundamento.py, 06_estruturas_aninhadas/exemplos/02_aplicacao.py
