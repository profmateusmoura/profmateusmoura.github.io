# Lista de posições — Lojas Blue
# Enunciado:
# Monte dois registros: unidade 1/produto 1/saldo 18/mínimo 10 e unidade 1/produto 4/saldo 4/mínimo 8. Exiba só os críticos.
#
# Dica:
# Há uma lista de registros com campos nomeados.
#
# Conferência:
# Só produto 4.
#
# Apoio: 06_estruturas_aninhadas/exemplos/01_fundamento.py, 06_estruturas_aninhadas/exemplos/02_aplicacao.py
