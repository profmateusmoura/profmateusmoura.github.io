# Verificação desta edição

Este curso possui 28 tópicos, 52 exemplos de tópico e 192 exercícios.
As duas rodadas acrescentaram 74 exemplos; todos foram executados durante a revisão.
A primeira rodada incluiu 123 conferências de contratos e dados; a segunda acrescentou 137 conferências.
Todos os exercícios dos três cursos foram conferidos como comentários, sem soluções executáveis.
A sintaxe foi conferida com a gramática de Python 3.10; as execuções usaram Python 3.14.7.
Foram conferidos links locais e a separação dos recursos de ALP por etapa.
A segunda rodada conferiu casos vazios, busca ausente, ordenação com desempate, argumentos mutáveis,
fábricas, identidade, igualdade, hash, campos imutáveis e transições de pedido.
A base JSON original foi preservada. Os pacotes ZIP foram conferidos arquivo por arquivo.

## Conferência final

Foram executados todos os 121 exemplos de tópico de PED e POO.
Foram conferidas 520 docstrings de classes e funções nos três cursos e
505 referências de apoio dos exercícios. Os guias principais passaram a
listar todos os exemplos e exercícios, incluindo os complementos. As quantidades do mapa de ALP
foram atualizadas; o guia de POO apresenta os capítulos no percurso recomendado.
