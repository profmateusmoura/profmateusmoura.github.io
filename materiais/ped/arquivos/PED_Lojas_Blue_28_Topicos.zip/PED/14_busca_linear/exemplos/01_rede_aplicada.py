# Buscar por id com percurso explícito — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Encontrado: Perfume Floral 100 ml'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def buscar(produtos, alvo):
    """Retorne o registro do id alvo, ou None se não existir."""
    for produto in produtos:
        if produto["id"] == alvo:
            return produto
    return None

encontrado = buscar(dados["produtos"], 4)
if encontrado is not None:
    print("Encontrado:", encontrado["nome"])
print("Ausente:", buscar(dados["produtos"], 999))
# Retornamos uma referência ao registro; alterar esse objeto muda a lista em memória.
