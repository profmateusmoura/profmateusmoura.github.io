# Primeiro resultado ou todas as correspondências
# Execução: python 14_busca_linear/exemplos/02_primeiro_e_todos.py
# Confira na saída: 'Todos: [1, 2]'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

def primeiro_da_categoria(produtos, categoria_id):
    """Retorne o primeiro registro da categoria ou None."""
    for produto in produtos:
        if produto["categoria_id"] == categoria_id:
            return produto  # Encerra a função assim que encontra um registro.
    return None

def todos_da_categoria(produtos, categoria_id):
    """Retorne lista das correspondências, preservando a ordem de entrada."""
    encontrados = []
    for produto in produtos:
        if produto["categoria_id"] == categoria_id:
            encontrados.append(produto)
    return encontrados  # Só termina depois de examinar todos os candidatos.

recorte = [{"id": 1, "categoria_id": 1}, {"id": 4, "categoria_id": 2}, {"id": 2, "categoria_id": 1}]
print("Primeiro:", primeiro_da_categoria(recorte, 1)["id"])
print("Todos:", [p["id"] for p in todos_da_categoria(recorte, 1)])
print("Ausentes:", primeiro_da_categoria(recorte, 99), todos_da_categoria(recorte, 99))
