# Várias correspondências — Lojas Blue
# Enunciado:
# Retorne todos os produtos da categoria 1.
#
# Dica:
# Uma busca de vários resultados não encerra na primeira ocorrência.
#
# Conferência:
# Todo resultado tem categoria_id 1.
#
# Apoio: 14_busca_linear/exemplos/01_rede_aplicada.py
