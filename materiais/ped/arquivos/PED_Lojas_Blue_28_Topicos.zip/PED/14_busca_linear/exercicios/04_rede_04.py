# Busca composta — Lojas Blue
# Enunciado:
# Busque posição de estoque pelo par unidade/produto.
#
# Dica:
# Compare os dois campos.
#
# Conferência:
# (1,1) saldo 18; (2,1) saldo 32; (99,1) ausente.
#
# Apoio: 14_busca_linear/exemplos/01_rede_aplicada.py
