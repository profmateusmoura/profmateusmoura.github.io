# Corrigir a ausência antecipada
# Enunciado:
# Uma função retorna None dentro do laço assim que o primeiro produto não coincide com o alvo. Corrija a posição desse retorno.
#
# Dica:
# Só é possível concluir ausência após esgotar os candidatos.
#
# Conferência:
# Buscar id 4 encontra o perfume mesmo que o primeiro registro seja id 1.
#
# Apoio: 14_busca_linear/exemplos/01_rede_aplicada.py
