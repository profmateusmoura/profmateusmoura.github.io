# Prever a busca linear
# Enunciado:
# No catálogo da base, conte as inspeções até encontrar ids 1 e 20 e até concluir ausência de id 999.
#
# Dica:
# A busca de primeiro resultado encerra ao encontrar a identidade.
#
# Conferência:
# Uma, vinte e vinte inspeções.
#
# Apoio: 14_busca_linear/exemplos/01_rede_aplicada.py
