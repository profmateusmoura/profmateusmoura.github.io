# Primeiro e último — Lojas Blue
# Enunciado:
# Teste busca nos ids 1, 20 e 999.
#
# Dica:
# Ausência deve terminar após percorrer a lista.
#
# Conferência:
# Os dois primeiros existem; 999 não.
#
# Apoio: 14_busca_linear/exemplos/01_rede_aplicada.py
