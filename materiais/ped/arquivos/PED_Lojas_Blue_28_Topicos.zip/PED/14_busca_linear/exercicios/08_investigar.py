# Completar consultas com contratos distintos
# Enunciado:
# Implemente primeiro produto até preço limite e todos os produtos até o mesmo limite. Documente os retornos de ausência.
#
# Dica:
# A semelhança da condição não significa que o término seja igual.
#
# Conferência:
# Ausência resulta em None na primeira e lista vazia na segunda.
#
# Apoio: 14_busca_linear/exemplos/02_primeiro_e_todos.py
