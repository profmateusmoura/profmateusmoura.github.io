# Buscar produto — Lojas Blue
# Enunciado:
# Implemente busca linear por id com retorno None na ausência.
#
# Dica:
# Não use índice pronto.
#
# Conferência:
# Produto 4 é Perfume Floral 100 ml.
#
# Apoio: 14_busca_linear/exemplos/01_rede_aplicada.py
