# Prever encerramentos diferentes
# Enunciado:
# No recorte do exemplo, conte quantos registros cada função inspeciona para categoria um. Repita para categoria ausente.
#
# Dica:
# return dentro do laço encerra a função de primeiro resultado.
#
# Conferência:
# Para categoria um, primeiro inspeciona um registro e todos inspeciona três.
#
# Apoio: 14_busca_linear/exemplos/02_primeiro_e_todos.py
