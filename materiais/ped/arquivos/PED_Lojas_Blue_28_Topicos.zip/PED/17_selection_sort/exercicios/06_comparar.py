# Comparar critérios de desempate
# Enunciado:
# Ordene registros com mesmo preço e ids 3, 1 e 2. Compare critério só por preço com critério por (preco,id).
#
# Dica:
# O segundo contrato determina uma ordem entre preços iguais.
#
# Conferência:
# Pelo critério composto, ids 1,2,3; pelo preço isolado, não prometa o mesmo desempate.
#
# Apoio: 17_selection_sort/exemplos/01_rede_aplicada.py
