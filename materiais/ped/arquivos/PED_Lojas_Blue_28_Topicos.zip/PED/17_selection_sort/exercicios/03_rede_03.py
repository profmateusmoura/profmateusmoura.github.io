# Ordem inversa — Lojas Blue
# Enunciado:
# Faça versão decrescente por preço, com empate por id crescente.
#
# Dica:
# Não basta inverter toda a tupla se só o preço muda de direção.
#
# Conferência:
# Preço maior primeiro; empate mantém id crescente.
#
# Apoio: 17_selection_sort/exemplos/01_rede_aplicada.py
