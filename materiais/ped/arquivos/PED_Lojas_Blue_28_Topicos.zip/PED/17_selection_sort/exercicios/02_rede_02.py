# Contar comparações — Lojas Blue
# Enunciado:
# Conte comparações para n registros sem otimizações que mudem o algoritmo.
#
# Dica:
# A quantidade de candidatos diminui a cada passagem.
#
# Conferência:
# Para n=4, seis comparações.
#
# Apoio: 17_selection_sort/exemplos/01_rede_aplicada.py
