# Selection por preço — Lojas Blue
# Enunciado:
# Ordene produtos com seleção explícita do menor restante por (preco, id).
#
# Dica:
# Fixe um elemento por passagem externa.
#
# Conferência:
# Mesmo resultado de Bubble no mesmo contrato.
#
# Apoio: 17_selection_sort/exemplos/01_rede_aplicada.py
