# Casos pequenos — Lojas Blue
# Enunciado:
# Teste vazio, unitário e preços todos iguais.
#
# Dica:
# Uma lista sem pares não exige troca.
#
# Conferência:
# Resultado preserva todos os registros.
#
# Apoio: 17_selection_sort/exemplos/01_rede_aplicada.py
