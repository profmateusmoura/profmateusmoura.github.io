# Prever a seleção do menor
# Enunciado:
# Para preços [30, 10, 20], identifique o menor do trecho inteiro e a primeira troca de Selection. Depois mostre o trecho que ainda falta ordenar.
#
# Dica:
# Cada passagem externa fixa um elemento.
#
# Conferência:
# Depois da primeira troca: [10,30,20]; faltam as duas últimas posições.
#
# Apoio: 17_selection_sort/exemplos/01_rede_aplicada.py
