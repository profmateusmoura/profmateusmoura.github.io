# Selecionar o menor restante — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Mais barato: Sabonete em Barra'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def selection(produtos):
    """Retorne cópia ordenada por (preco, id), com seleção explícita do menor."""
    resultado = produtos.copy()
    for inicio in range(len(resultado) - 1):
        # O candidato inicial é uma posição real do trecho ainda não organizado.
        menor = inicio
        # Todos os candidatos restantes são comparados antes de fixar a posição inicio.
        for candidato in range(inicio + 1, len(resultado)):
            a = resultado[candidato]
            b = resultado[menor]
            if (a["preco"], a["id"]) < (b["preco"], b["id"]):
                menor = candidato
        # Só depois da procura o menor candidato é colocado na posição definitiva da passagem.
        resultado[inicio], resultado[menor] = resultado[menor], resultado[inicio]
    return resultado

ordenados = selection(dados["produtos"])
print("Mais barato:", ordenados[0]["nome"])
# Cada volta fixa a menor chave do trecho ainda não organizado.
