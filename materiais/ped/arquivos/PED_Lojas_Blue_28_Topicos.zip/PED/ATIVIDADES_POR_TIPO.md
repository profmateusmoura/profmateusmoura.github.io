# Atividades por tipo — PED

Use previsões, implementação, investigação e comparação para conferir o mesmo conteúdo por caminhos diferentes.

| Tópico | Atividade | Tipo | Percurso |
|---|---|---|---|
| 01 | [Padronizar comando — Lojas Blue](01_strings/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 01 | [Localizar palavra — Lojas Blue](01_strings/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 01 | [Extrair prefixo — Lojas Blue](01_strings/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 01 | [Contar letras — Lojas Blue](01_strings/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 01 | [Prever a normalização](01_strings/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 01 | [Corrigir a comparação textual](01_strings/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 02 | [Catálogo pequeno — Lojas Blue](02_listas/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 02 | [Inserção e remoção — Lojas Blue](02_listas/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 02 | [Simular saldos — Lojas Blue](02_listas/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 02 | [Filtrar saldos — Lojas Blue](02_listas/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 02 | [Prever o compartilhamento](02_listas/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 02 | [Corrigir a simulação](02_listas/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 02 | [Prever a posição deslocada](02_listas/exercicios/07_prever.py) | Prever e rastrear | Essencial |
| 02 | [Corrigir a seleção de saldo](02_listas/exercicios/08_investigar.py) | Investigar e corrigir | Essencial |
| 03 | [Identidade composta — Lojas Blue](03_tuplas/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 03 | [Registro fixo — Lojas Blue](03_tuplas/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 03 | [Retorno de extremos — Lojas Blue](03_tuplas/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 03 | [Tupla unitária — Lojas Blue](03_tuplas/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 03 | [Prever o desempacotamento](03_tuplas/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 03 | [Completar um retorno](03_tuplas/exercicios/06_investigar.py) | Completar e verificar | Essencial |
| 04 | [Produto nomeado — Lojas Blue](04_dicionarios/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 04 | [Campo opcional — Lojas Blue](04_dicionarios/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 04 | [Atualizar simulação — Lojas Blue](04_dicionarios/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 04 | [Estoque por regra — Lojas Blue](04_dicionarios/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 04 | [Prever acesso e padrão](04_dicionarios/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 04 | [Corrigir uma atualização](04_dicionarios/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 04 | [Prever existência e valor](04_dicionarios/exercicios/07_prever.py) | Prever e rastrear | Essencial |
| 04 | [Corrigir um teste de ausência](04_dicionarios/exercicios/08_investigar.py) | Investigar e corrigir | Essencial |
| 05 | [UFs distintas — Lojas Blue](05_conjuntos/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 05 | [Interseção de lojas — Lojas Blue](05_conjuntos/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 05 | [Diferença — Lojas Blue](05_conjuntos/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 05 | [Cobertura — Lojas Blue](05_conjuntos/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 05 | [Prever operações de conjuntos](05_conjuntos/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 05 | [Comparar lista e conjunto](05_conjuntos/exercicios/06_comparar.py) | Comparar e explicar | Essencial |
| 06 | [Lista de posições — Lojas Blue](06_estruturas_aninhadas/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 06 | [Agrupar por UF — Lojas Blue](06_estruturas_aninhadas/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 06 | [Atualização localizada — Lojas Blue](06_estruturas_aninhadas/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 06 | [Cópia de registros — Lojas Blue](06_estruturas_aninhadas/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 06 | [Prever a cópia externa](06_estruturas_aninhadas/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 06 | [Corrigir o isolamento](06_estruturas_aninhadas/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 07 | [Função de filtragem — Lojas Blue](07_funcoes_com_colecoes/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 07 | [Retornar nomes — Lojas Blue](07_funcoes_com_colecoes/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 07 | [Total de pedidos — Lojas Blue](07_funcoes_com_colecoes/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 07 | [Resumo por UF — Lojas Blue](07_funcoes_com_colecoes/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 07 | [Prever o retorno selecionado](07_funcoes_com_colecoes/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 07 | [Completar uma transformação](07_funcoes_com_colecoes/exercicios/06_investigar.py) | Completar e verificar | Essencial |
| 07 | [Prever o término de zip](07_funcoes_com_colecoes/exercicios/07_prever.py) | Prever e rastrear | Essencial |
| 07 | [Completar uma conferência de correspondência](07_funcoes_com_colecoes/exercicios/08_investigar.py) | Completar e verificar | Essencial |
| 07 | [Comparar duas seleções](07_funcoes_com_colecoes/exercicios/09_prever.py) | Comparar e explicar | Essencial |
| 07 | [Completar uma transformação](07_funcoes_com_colecoes/exercicios/10_investigar.py) | Completar e verificar | Essencial |
| 07 | [Prever o objeto padrão](07_funcoes_com_colecoes/exercicios/11_prever.py) | Prever e rastrear | Essencial |
| 07 | [Corrigir o padrão de uma função](07_funcoes_com_colecoes/exercicios/12_investigar.py) | Investigar e corrigir | Essencial |
| 08 | [Gravar nomes — Lojas Blue](08_arquivos_texto/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 08 | [Reler relatório — Lojas Blue](08_arquivos_texto/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 08 | [Arquivo vazio — Lojas Blue](08_arquivos_texto/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 08 | [Preservar fonte — Lojas Blue](08_arquivos_texto/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 08 | [Prever os modos de escrita](08_arquivos_texto/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 08 | [Corrigir uma contagem de linhas](08_arquivos_texto/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 08 | [Prever a borda de leitura](08_arquivos_texto/exercicios/07_prever.py) | Prever e rastrear | Essencial |
| 08 | [Completar leitura com informação de falha](08_arquivos_texto/exercicios/08_investigar.py) | Completar e verificar | Essencial |
| 09 | [Inventário do JSON — Lojas Blue](09_json_arquivo_e_memoria/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 09 | [Memória e disco — Lojas Blue](09_json_arquivo_e_memoria/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 09 | [Cópia persistente — Lojas Blue](09_json_arquivo_e_memoria/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 09 | [Consulta sem alteração — Lojas Blue](09_json_arquivo_e_memoria/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 09 | [Prever memória e persistência](09_json_arquivo_e_memoria/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 09 | [Completar uma consulta reutilizável](09_json_arquivo_e_memoria/exercicios/06_investigar.py) | Completar e verificar | Essencial |
| 09 | [Prever os tipos após a leitura](09_json_arquivo_e_memoria/exercicios/07_prever.py) | Prever e rastrear | Essencial |
| 09 | [Comparar load e loads](09_json_arquivo_e_memoria/exercicios/08_investigar.py) | Comparar e explicar | Essencial |
| 09 | [Prever duas validações diferentes](09_json_arquivo_e_memoria/exercicios/09_prever.py) | Prever e rastrear | Essencial |
| 09 | [Completar uma borda de leitura](09_json_arquivo_e_memoria/exercicios/10_investigar.py) | Completar e verificar | Essencial |
| 10 | [Resolver nomes — Lojas Blue](10_relacionamentos_e_consistencia/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 10 | [Validar referências — Lojas Blue](10_relacionamentos_e_consistencia/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 10 | [Identidade completa — Lojas Blue](10_relacionamentos_e_consistencia/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 10 | [Erro simulado — Lojas Blue](10_relacionamentos_e_consistencia/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 10 | [Prever a chave de uma posição](10_relacionamentos_e_consistencia/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 10 | [Corrigir uma referência](10_relacionamentos_e_consistencia/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 11 | [Soma recursiva — Lojas Blue](11_recursao/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 11 | [Contagem recursiva — Lojas Blue](11_recursao/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 11 | [Busca recursiva — Lojas Blue](11_recursao/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 11 | [Limite da técnica — Lojas Blue](11_recursao/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 11 | [Prever chamadas recursivas](11_recursao/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 11 | [Corrigir a redução do problema](11_recursao/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 11 | [Rastrear os retornos pendentes](11_recursao/exercicios/07_prever.py) | Prever e rastrear | Essencial |
| 11 | [Comparar o controle de término](11_recursao/exercicios/08_investigar.py) | Comparar e explicar | Essencial |
| 12 | [Contrato de retirada — Lojas Blue](12_tads_procedurais/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 12 | [Reposição — Lojas Blue](12_tads_procedurais/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 12 | [Consulta — Lojas Blue](12_tads_procedurais/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 12 | [Comparar representações — Lojas Blue](12_tads_procedurais/exercicios/04_rede_04.py) | Comparar e explicar | Essencial |
| 12 | [Prever uma sequência do TAD](12_tads_procedurais/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 12 | [Corrigir o contrato](12_tads_procedurais/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 13 | [Contar percurso — Lojas Blue](13_complexidade_basica/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 13 | [Escalar entrada — Lojas Blue](13_complexidade_basica/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 13 | [Laços aninhados — Lojas Blue](13_complexidade_basica/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 13 | [Custo de índice — Lojas Blue](13_complexidade_basica/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 13 | [Prever crescimento](13_complexidade_basica/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 13 | [Comparar custos completos](13_complexidade_basica/exercicios/06_comparar.py) | Comparar e explicar | Essencial |
| 13 | [Prever crescimento em outra escala](13_complexidade_basica/exercicios/07_prever.py) | Prever e rastrear | Essencial |
| 13 | [Comparar duas contagens](13_complexidade_basica/exercicios/08_investigar.py) | Comparar e explicar | Essencial |
| 14 | [Buscar produto — Lojas Blue](14_busca_linear/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 14 | [Primeiro e último — Lojas Blue](14_busca_linear/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 14 | [Várias correspondências — Lojas Blue](14_busca_linear/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 14 | [Busca composta — Lojas Blue](14_busca_linear/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 14 | [Prever a busca linear](14_busca_linear/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 14 | [Corrigir a ausência antecipada](14_busca_linear/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 14 | [Prever encerramentos diferentes](14_busca_linear/exercicios/07_prever.py) | Prever e rastrear | Essencial |
| 14 | [Completar consultas com contratos distintos](14_busca_linear/exercicios/08_investigar.py) | Completar e verificar | Essencial |
| 15 | [Busca binária básica — Lojas Blue](15_busca_binaria/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 15 | [Vazio e unitário — Lojas Blue](15_busca_binaria/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 15 | [Pré-condição de ordem — Lojas Blue](15_busca_binaria/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 15 | [Produto por posição — Lojas Blue](15_busca_binaria/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 15 | [Prever o intervalo restante](15_busca_binaria/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 15 | [Corrigir o avanço dos limites](15_busca_binaria/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 15 | [Prever o uso de um índice](15_busca_binaria/exercicios/07_prever.py) | Prever e rastrear | Essencial |
| 15 | [Corrigir a recuperação do registro](15_busca_binaria/exercicios/08_investigar.py) | Investigar e corrigir | Essencial |
| 16 | [Bubble por preço — Lojas Blue](16_bubble_sort/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 16 | [Otimização — Lojas Blue](16_bubble_sort/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 16 | [Empates artificiais — Lojas Blue](16_bubble_sort/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 16 | [Preservação — Lojas Blue](16_bubble_sort/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 16 | [Prever uma passagem Bubble](16_bubble_sort/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 16 | [Corrigir a flag de troca](16_bubble_sort/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 17 | [Selection por preço — Lojas Blue](17_selection_sort/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 17 | [Contar comparações — Lojas Blue](17_selection_sort/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 17 | [Ordem inversa — Lojas Blue](17_selection_sort/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 17 | [Casos pequenos — Lojas Blue](17_selection_sort/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 17 | [Prever a seleção do menor](17_selection_sort/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 17 | [Comparar critérios de desempate](17_selection_sort/exercicios/06_comparar.py) | Comparar e explicar | Essencial |
| 18 | [Insertion por preço — Lojas Blue](18_insertion_sort/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 18 | [Quase organizado — Lojas Blue](18_insertion_sort/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 18 | [Fronteira inicial — Lojas Blue](18_insertion_sort/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 18 | [Comparar algoritmos — Lojas Blue](18_insertion_sort/exercicios/04_rede_04.py) | Comparar e explicar | Essencial |
| 18 | [Prever os deslocamentos](18_insertion_sort/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 18 | [Corrigir a fronteira do índice](18_insertion_sort/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 19 | [Índice de produtos — Lojas Blue](19_hash_e_indices/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 19 | [Índice de estoques — Lojas Blue](19_hash_e_indices/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 19 | [Duplicata simulada — Lojas Blue](19_hash_e_indices/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 19 | [Mudança de identidade — Lojas Blue](19_hash_e_indices/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 19 | [Prever uma sobrescrita no índice](19_hash_e_indices/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 19 | [Corrigir a detecção de duplicata](19_hash_e_indices/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 20 | [Colisão intencional — Lojas Blue](20_colisoes/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 20 | [Atualizar id — Lojas Blue](20_colisoes/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 20 | [Remover do bucket — Lojas Blue](20_colisoes/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 20 | [Fator de carga — Lojas Blue](20_colisoes/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 20 | [Prever o bucket](20_colisoes/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 20 | [Corrigir o compartilhamento de buckets](20_colisoes/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 21 | [Histórico do pedido — Lojas Blue](21_pilhas/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 21 | [Desfazer simulado — Lojas Blue](21_pilhas/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 21 | [Pilha vazia — Lojas Blue](21_pilhas/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 21 | [Isolar pedidos — Lojas Blue](21_pilhas/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 21 | [Prever o topo do histórico](21_pilhas/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 21 | [Comparar ordem e armazenamento](21_pilhas/exercicios/06_comparar.py) | Comparar e explicar | Essencial |
| 22 | [Fila de reposições — Lojas Blue](22_filas/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 22 | [Fila vazia — Lojas Blue](22_filas/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 22 | [Nova chegada — Lojas Blue](22_filas/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 22 | [Comparar prioridade — Lojas Blue](22_filas/exercicios/04_rede_04.py) | Comparar e explicar | Essencial |
| 22 | [Prever duas políticas de atendimento](22_filas/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 22 | [Corrigir atendimento vazio](22_filas/exercicios/06_investigar.py) | Investigar e corrigir | Essencial |
| 23 | [Inserção inicial — Lojas Blue](23_listas_encadeadas/exercicios/01_rede_01.py) | Implementar e modificar | Aprofundamento |
| 23 | [Inserção final — Lojas Blue](23_listas_encadeadas/exercicios/02_rede_02.py) | Implementar e modificar | Aprofundamento |
| 23 | [Remoção — Lojas Blue](23_listas_encadeadas/exercicios/03_rede_03.py) | Implementar e modificar | Aprofundamento |
| 23 | [Contagem — Lojas Blue](23_listas_encadeadas/exercicios/04_rede_04.py) | Implementar e modificar | Aprofundamento |
| 23 | [Prever a cabeça da lista](23_listas_encadeadas/exercicios/05_prever.py) | Prever e rastrear | Aprofundamento |
| 23 | [Corrigir remoção da cabeça](23_listas_encadeadas/exercicios/06_investigar.py) | Investigar e corrigir | Aprofundamento |
| 24 | [Contar árvore — Lojas Blue](24_arvores_binarias/exercicios/01_rede_01.py) | Implementar e modificar | Aprofundamento |
| 24 | [Altura — Lojas Blue](24_arvores_binarias/exercicios/02_rede_02.py) | Implementar e modificar | Aprofundamento |
| 24 | [Percursos — Lojas Blue](24_arvores_binarias/exercicios/03_rede_03.py) | Implementar e modificar | Aprofundamento |
| 24 | [Não presumir BST — Lojas Blue](24_arvores_binarias/exercicios/04_rede_04.py) | Implementar e modificar | Aprofundamento |
| 24 | [Prever os percursos](24_arvores_binarias/exercicios/05_prever.py) | Prever e rastrear | Aprofundamento |
| 24 | [Corrigir o caso vazio](24_arvores_binarias/exercicios/06_investigar.py) | Investigar e corrigir | Aprofundamento |
| 25 | [Inserir e buscar — Lojas Blue](25_bst/exercicios/01_rede_01.py) | Implementar e modificar | Aprofundamento |
| 25 | [Duplicatas — Lojas Blue](25_bst/exercicios/02_rede_02.py) | Implementar e modificar | Aprofundamento |
| 25 | [Remover — Lojas Blue](25_bst/exercicios/03_rede_03.py) | Implementar e modificar | Aprofundamento |
| 25 | [Degeneração — Lojas Blue](25_bst/exercicios/04_rede_04.py) | Implementar e modificar | Aprofundamento |
| 25 | [Prever formas diferentes](25_bst/exercicios/05_prever.py) | Prever e rastrear | Aprofundamento |
| 25 | [Corrigir o ramo da inserção](25_bst/exercicios/06_investigar.py) | Investigar e corrigir | Aprofundamento |
| 26 | [Rotação RR — Lojas Blue](26_balanceamento_e_rotacoes/exercicios/01_rede_01.py) | Implementar e modificar | Desafio avançado |
| 26 | [Rotação LL — Lojas Blue](26_balanceamento_e_rotacoes/exercicios/02_rede_02.py) | Implementar e modificar | Desafio avançado |
| 26 | [Casos LR e RL — Lojas Blue](26_balanceamento_e_rotacoes/exercicios/03_rede_03.py) | Implementar e modificar | Desafio avançado |
| 26 | [Extensão AVL — Lojas Blue](26_balanceamento_e_rotacoes/exercicios/04_rede_04.py) | Implementar e modificar | Desafio avançado |
| 26 | [Prever uma rotação](26_balanceamento_e_rotacoes/exercicios/05_prever.py) | Prever e rastrear | Desafio avançado |
| 26 | [Corrigir a subárvore intermediária](26_balanceamento_e_rotacoes/exercicios/06_investigar.py) | Investigar e corrigir | Desafio avançado |
| 27 | [Relatório integrado — Lojas Blue](27_integracao_reposicoes/exercicios/01_rede_01.py) | Implementar e modificar | Essencial |
| 27 | [Fila planejada — Lojas Blue](27_integracao_reposicoes/exercicios/02_rede_02.py) | Implementar e modificar | Essencial |
| 27 | [Persistir cópia — Lojas Blue](27_integracao_reposicoes/exercicios/03_rede_03.py) | Implementar e modificar | Essencial |
| 27 | [Projeto de consulta — Lojas Blue](27_integracao_reposicoes/exercicios/04_rede_04.py) | Implementar e modificar | Essencial |
| 27 | [Prever o recorte integrado](27_integracao_reposicoes/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 27 | [Comparar fonte e simulação](27_integracao_reposicoes/exercicios/06_comparar.py) | Comparar e explicar | Essencial |
| 28 | [Prever o melhor caso](28_comparar_buscas_ordenacoes_e_indices/exercicios/01_prever.py) | Prever e rastrear | Essencial |
| 28 | [Comparar incluindo preparação](28_comparar_buscas_ordenacoes_e_indices/exercicios/02_comparar.py) | Comparar e explicar | Essencial |
| 28 | [Comparar um contrato comum](28_comparar_buscas_ordenacoes_e_indices/exercicios/03_prever.py) | Comparar e explicar | Essencial |
| 28 | [Completar a observação de trabalho](28_comparar_buscas_ordenacoes_e_indices/exercicios/04_comparar.py) | Completar e verificar | Essencial |
| 28 | [Prever uma alteração compartilhada](28_comparar_buscas_ordenacoes_e_indices/exercicios/05_prever.py) | Prever e rastrear | Essencial |
| 28 | [Comparar consulta e manutenção](28_comparar_buscas_ordenacoes_e_indices/exercicios/06_comparar.py) | Comparar e explicar | Essencial |
