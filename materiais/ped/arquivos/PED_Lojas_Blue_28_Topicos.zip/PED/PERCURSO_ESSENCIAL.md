# Percurso essencial e desafios — PED

## Como escolher o percurso

O percurso essencial vai dos tópicos 01 a 22, passa pelo projeto 27 e consolida as comparações em 28.
Listas encadeadas e árvores, nos tópicos 23 a 25, formam um aprofundamento.
O tópico 26 é desafio avançado de balanceamento e AVL. O projeto essencial pode ser concluído antes desse ramo.
Para entrar em árvores, conclua recursão, em 11; para entrar em BST, conclua árvores binárias, em 24.

Em cada tópico essencial, priorize exercícios 01 e 02, acrescente a previsão 05 e confira os critérios de autonomia.
Use 03, 04 e 06 para consolidar, comparar ou investigar dificuldades. No projeto 27, conclua a aplicação integrada.
Um exercício só está resolvido quando você consegue explicar o resultado e verificar um caso diferente do exemplo.

## Mapa

| Tópico | Percurso | Foco |
|---|---|---|
| [01_strings](01_strings/exemplos/01_fundamento.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [02_listas](02_listas/exemplos/01_fundamento.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [03_tuplas](03_tuplas/exemplos/01_fundamento.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [04_dicionarios](04_dicionarios/exemplos/01_fundamento.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [05_conjuntos](05_conjuntos/exemplos/01_fundamento.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [06_estruturas_aninhadas](06_estruturas_aninhadas/exemplos/01_fundamento.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [07_funcoes_com_colecoes](07_funcoes_com_colecoes/exemplos/01_fundamento.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [08_arquivos_texto](08_arquivos_texto/exemplos/01_fundamento.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [09_json_arquivo_e_memoria](09_json_arquivo_e_memoria/exemplos/01_fundamento.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [10_relacionamentos_e_consistencia](10_relacionamentos_e_consistencia/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [11_recursao](11_recursao/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [12_tads_procedurais](12_tads_procedurais/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [13_complexidade_basica](13_complexidade_basica/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [14_busca_linear](14_busca_linear/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [15_busca_binaria](15_busca_binaria/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [16_bubble_sort](16_bubble_sort/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [17_selection_sort](17_selection_sort/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [18_insertion_sort](18_insertion_sort/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [19_hash_e_indices](19_hash_e_indices/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [20_colisoes](20_colisoes/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [21_pilhas](21_pilhas/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [22_filas](22_filas/exemplos/01_rede_aplicada.py) | Essencial | Conceitos, aplicação e conferência do tópico. |
| [23_listas_encadeadas](23_listas_encadeadas/exemplos/01_rede_aplicada.py) | Aprofundamento | Referências, cabeça e operações de nós. |
| [24_arvores_binarias](24_arvores_binarias/exemplos/01_rede_aplicada.py) | Aprofundamento | Ramificação, altura e percursos. |
| [25_bst](25_bst/exemplos/01_rede_aplicada.py) | Aprofundamento | Invariante de busca e efeito da ordem de inserção. |
| [26_balanceamento_e_rotacoes](26_balanceamento_e_rotacoes/exemplos/01_rede_aplicada.py) | Desafio avançado | Rotações RR, LL, LR e RL; inserção AVL como extensão. |
| [27_integracao_reposicoes](27_integracao_reposicoes/exemplos/01_rede_aplicada.py) | Essencial | Catálogo, índices, reposição e conferência integrada. |

## Apoio de dados e algoritmos

Estude a leitura direta do JSON no tópico 09; em seguida, use o módulo `dados.acesso` para repetir carregamentos e consultas de aplicação.
Nos tópicos 14 e 15, carregue com o módulo se desejar e implemente a busca pedida no próprio exercício.
`buscar_produto` e `consultar_estoque` já realizam consultas e não substituem a implementação que o exercício de algoritmo solicita.
Nos tópicos 16 a 18, escreva as trocas, seleções e deslocamentos; use sorted como conferência externa depois da tentativa.
Na aplicação integrada, escolha uma operação pronta ou uma implementação estudada de acordo com o objetivo e documente a escolha.

Consulte [ATIVIDADES_POR_TIPO.md](ATIVIDADES_POR_TIPO.md) para selecionar previsão, implementação, comparação e investigação.
O [problema evolutivo](PROBLEMA_EVOLUTIVO.md) liga este projeto às soluções de ALP e POO.

## Comparação final

O tópico [28 — comparar buscas, ordenações e índices](28_comparar_buscas_ordenacoes_e_indices/exemplos/01_buscas.py) é parte do percurso essencial. Ele usa os fundamentos de 01–22 e pode ser estudado sem listas encadeadas ou árvores.
