"""Acesso à base Lojas Blue: leitura, consultas e gravação de cópias.

O módulo fornece listas e dicionários. Regras de estoque, preços e pedidos
continuam nas funções ou objetos do programa que o utiliza.
"""
from pathlib import Path
import json

CAMINHO_DADOS = Path(__file__).resolve().with_name("lojas_blue.json")


def carregar_dados(caminho=None):
    """Leia o JSON e retorne um novo dicionário a cada chamada.

    Sem caminho, use a base ao lado deste módulo, independentemente da
    pasta do terminal. Caminhos relativos informados usam a pasta do terminal.
    Propague FileNotFoundError e JSONDecodeError; raiz diferente de objeto
    JSON gera ValueError. O arquivo deve seguir o esquema da base da disciplina.
    """
    arquivo = CAMINHO_DADOS if caminho is None else Path(caminho)
    with arquivo.open(encoding="utf-8") as entrada:
        dados = json.load(entrada)
    if not isinstance(dados, dict):
        raise ValueError("A raiz da base deve ser um objeto JSON.")
    return dados


def listar_produtos(dados):
    """Retorne a lista de produtos da base já carregada.

    A lista e os registros são os mesmos de dados: uma alteração modifica
    esta fotografia em memória. A função não lê nem grava arquivos.
    """
    return dados["produtos"]


def buscar_produto(dados, produto_id):
    """Retorne o registro do produto pelo id ou None se estiver ausente.

    O registro encontrado pertence à base em memória, sem cópia automática.
    """
    for produto in listar_produtos(dados):
        if produto["id"] == produto_id:
            return produto
    return None


def consultar_estoque(dados, unidade_id, produto_id):
    """Retorne a posição identificada pelos dois ids, ou None.

    O mesmo produto em outra unidade representa outra posição de estoque.
    A consulta retorna o registro compartilhado e não altera saldos.
    """
    for estoque in dados["estoques"]:
        if estoque["unidade_id"] == unidade_id and estoque["produto_id"] == produto_id:
            return estoque
    return None


def salvar_copia(dados, destino):
    """Grave dados como JSON UTF-8 em destino e retorne o Path resolvido.

    Crie a pasta do destino se necessário. Um destino já existente será
    substituído. Recuse o caminho da base fornecida para preservar a fonte.
    Falhas de gravação são propagadas ao chamador.
    """
    destino = Path(destino).resolve()
    if destino == CAMINHO_DADOS.resolve():
        raise ValueError("Escolha outro destino para salvar a cópia.")
    # Serialize antes de abrir o destino: erro de conversão não apaga sua cópia.
    texto = json.dumps(dados, ensure_ascii=False, indent=2)
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_text(texto + "\n", encoding="utf-8")
    return destino
