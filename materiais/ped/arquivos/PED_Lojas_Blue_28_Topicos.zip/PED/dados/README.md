# Acesso aos dados da rede

`acesso.py` centraliza o caminho e a leitura da base, além de consultas recorrentes.
Use-o depois de estudar a leitura direta de JSON em PED. O código de cada algoritmo
de busca ou ordenação continua sendo desenvolvido nos respectivos tópicos.

## Funções

| Função | Resultado |
|---|---|
| `carregar_dados()` | Base como dicionário, com uma nova leitura a cada chamada. |
| `listar_produtos(dados)` | Lista de produtos da base já carregada. |
| `buscar_produto(dados, produto_id)` | Registro encontrado ou `None`. |
| `consultar_estoque(dados, unidade_id, produto_id)` | Posição encontrada ou `None`. |
| `salvar_copia(dados, destino)` | Grava um JSON e retorna seu caminho. |

Carregue uma vez e passe `dados` para as consultas seguintes. As consultas retornam
as listas e registros da mesma base em memória; alterá-los não grava o arquivo.
Uma nova chamada de `carregar_dados()` lê novamente a fonte.

## Exemplo de uso em um programa na raiz do curso

```python
from dados.acesso import carregar_dados, buscar_produto, consultar_estoque

dados = carregar_dados()
produto = buscar_produto(dados, 1)
estoque = consultar_estoque(dados, 1, 1)
```

Execute o exemplo complementar pela raiz do curso:

```text
python exemplo_acesso_dados.py
```

Também funciona executar esse arquivo pelo caminho completo a partir de outra pasta.
Para usar o pacote `dados` em novos exemplos dentro de subpastas, execute-os como módulos
pela raiz do curso, por exemplo `python -m dados.seu_exemplo` para `dados/seu_exemplo.py`.
Os exemplos existentes continuam executáveis pelos comandos dos seus guias.

## Gravação

```python
from dados.acesso import salvar_copia

salvar_copia(dados, "saidas/rede_atualizada.json")
```

O destino relativo usa a pasta do terminal. Um arquivo de saída existente será substituído;
o caminho da base fornecida é recusado. Você pode ler depois a cópia com
`carregar_dados("saidas/rede_atualizada.json")`.

O módulo não imprime mensagens nem captura erros para fingir uma leitura bem-sucedida:
o programa que o chama decide como apresentar falhas de arquivo ou formato.
Em POO, o acesso continua devolvendo registros; o adaptador cria os objetos.

## Dicionário da base

A raiz do JSON é um objeto cujas nove chaves identificam listas de registros.
Os campos abaixo são obrigatórios na base desta edição. `int` significa inteiro,
`str` significa texto e `number` é um número JSON. Identificadores são inteiros positivos.
Uma identidade não precisa coincidir com a posição do registro em uma lista.

### unidades

Registros nesta edição: **10**.

| Campo | Tipo | Significado e regra |
|---|---|---|
| `id` | `int` | Identificador único da unidade. |
| `nome` | `str` | Nome de apresentação. |
| `tipo` | `str` | LOJA ou CD. |
| `cidade` | `str` | Cidade da unidade. |
| `uf` | `str` | Sigla da UF. |

### categorias

Registros nesta edição: **5**.

| Campo | Tipo | Significado e regra |
|---|---|---|
| `id` | `int` | Identificador único da categoria. |
| `nome` | `str` | Nome da categoria. |

### produtos

Registros nesta edição: **20**.

| Campo | Tipo | Significado e regra |
|---|---|---|
| `id` | `int` | Identificador único do produto. |
| `nome` | `str` | Nome de apresentação. |
| `categoria_id` | `int` | Referência a categorias.id. |
| `preco` | `number` | Preço unitário não negativo em reais, com até duas casas decimais. |

### clientes

Registros nesta edição: **8**.

| Campo | Tipo | Significado e regra |
|---|---|---|
| `id` | `int` | Identificador único do cliente. |
| `nome` | `str` | Nome do cliente. |
| `cidade` | `str` | Cidade do cliente. |
| `uf` | `str` | Sigla da UF. |

### canais_venda

Registros nesta edição: **5**.

| Campo | Tipo | Significado e regra |
|---|---|---|
| `id` | `int` | Identificador único do canal. |
| `nome` | `str` | Nome do canal de venda. |

### estoques

Registros nesta edição: **18**.

| Campo | Tipo | Significado e regra |
|---|---|---|
| `unidade_id` | `int` | Referência a unidades.id; primeira parte da identidade da posição. |
| `produto_id` | `int` | Referência a produtos.id; segunda parte da identidade da posição. |
| `quantidade` | `int` | Saldo disponível não negativo. |
| `minimo` | `int` | Limite mínimo não negativo. |

### pedidos

Registros nesta edição: **8**.

| Campo | Tipo | Significado e regra |
|---|---|---|
| `id` | `int` | Identificador único do pedido. |
| `cliente_id` | `int` | Referência a clientes.id. |
| `unidade_id` | `int` | Referência a unidades.id. |
| `canal_id` | `int` | Referência a canais_venda.id. |
| `total` | `number` | Total registrado do pedido em reais, não negativo. |
| `status` | `str` | Estado atual; a base contém PENDENTE, SEPARACAO, ENVIADO e CONCLUIDO. |

### solicitacoes_reposicao

Registros nesta edição: **6**.

| Campo | Tipo | Significado e regra |
|---|---|---|
| `id` | `int` | Identificador único da solicitação. |
| `unidade_id` | `int` | Referência a unidades.id. |
| `produto_id` | `int` | Referência a produtos.id. |
| `quantidade` | `int` | Quantidade solicitada, estritamente positiva. |
| `prioridade` | `int` | Nível 1, 2 ou 3; nas atividades de prioridade, 3 é o mais urgente. |
| `status` | `str` | As solicitações fornecidas estão AGUARDANDO. |

### historico_status_pedidos

Registros nesta edição: **7**.

| Campo | Tipo | Significado e regra |
|---|---|---|
| `pedido_id` | `int` | Referência a pedidos.id; parte da identidade do evento. |
| `ordem` | `int` | Inteiro positivo que ordena os eventos de um pedido; não se repete no mesmo pedido. |
| `status` | `str` | Estado registrado nesse evento do histórico. |

### Identidades e relacionamentos

| Registro | Identidade | Referências |
|---|---|---|
| Unidade, categoria, produto, cliente, canal, pedido, solicitação | id | Conforme os campos descritos acima. |
| Posição de estoque | (unidade_id, produto_id) | Uma unidade e um produto existentes. |
| Evento de histórico | (pedido_id, ordem) | Um pedido existente. |

O produto 1 aparece em mais de uma unidade. Consultar somente produto_id não identifica o estoque.
O pedido registra seu total e seu status; esta versão da base não possui uma coleção de itens de pedido.
Itens criados nos exercícios de composição são novos orçamentos simulados.
Os eventos disponíveis cobrem apenas parte dos pedidos. Para reconstruí-los, ordene pela coluna ordem.

### Regras de cálculo e exemplos pequenos

- Posição (1,4): quantidade 4, mínimo 8, falta 4.
- Posição (1,1): quantidade 18, mínimo 10, falta zero.
- Igualdade entre quantidade e mínimo produz falta zero.
- Uma solicitação cadastrada possui sua própria quantidade; ela não é necessariamente igual à falta até o mínimo.
- A fotografia completa possui sete posições críticas; o caso evolutivo seleciona quatro posições, das quais três são críticas.
- Os preços da fonte estão em reais. Os modelos monetários de POO convertem para centavos na adaptação.

### Evolução da base

Ao acrescentar registros, escolha novas identidades, preserve os tipos e confira as referências.
Uma nova posição usa uma combinação unidade/produto ainda não cadastrada.
Ao acrescentar uma coleção, descreva seus campos e relacionamentos neste dicionário.
Atualize também os casos de conferência cuja contagem ou resultado depende dos registros novos.
O módulo de acesso carrega as chaves do documento; regras e relações são conferidas pelas atividades de consistência.
