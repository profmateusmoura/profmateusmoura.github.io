"""Base de dados e funções de acesso da rede de lojas."""
