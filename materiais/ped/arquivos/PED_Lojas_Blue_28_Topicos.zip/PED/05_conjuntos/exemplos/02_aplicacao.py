# Aplicação: UFs sem repetição — cenário didático Lojas Blue
# Objetivo: Combinar o recurso com conceitos já estudados.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Nas duas condições: [1, 3]'
# Sem entrada interativa.

lojas_com_falta = {1, 3, 4, 5, 7}
lojas_com_pedido = {1, 2, 3, 6}
print("Nas duas condições:", sorted(lojas_com_falta & lojas_com_pedido))
print("Só com falta:", sorted(lojas_com_falta - lojas_com_pedido))
# sorted retorna uma lista para tornar a apresentação determinística.
