# UFs sem repetição — cenário didático Lojas Blue
# Objetivo: Introduzir o recurso com um recorte da rede.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Quantidade de UFs: 2'
# Sem entrada interativa.

ufs = ["MG", "MG", "SP", "MG"]
distintas = set(ufs)
# Conjuntos não prometem a mesma ordem da lista original.
print("Quantidade de UFs:", len(distintas))
print("Atende SP:", "SP" in distintas)
print("Contém as UFs planejadas:", {"MG"} <= distintas)
