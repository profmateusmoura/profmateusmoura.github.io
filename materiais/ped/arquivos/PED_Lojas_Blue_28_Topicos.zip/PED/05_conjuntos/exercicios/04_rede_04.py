# Cobertura — Lojas Blue
# Enunciado:
# Com atendidas {1, 2, 3} e planejadas {1, 3}, verifique se todas as planejadas estão atendidas.
#
# Dica:
# Use relação de subconjunto.
#
# Conferência:
# True; incluir planejada 4 deve produzir False.
#
# Apoio: 05_conjuntos/exemplos/01_fundamento.py, 05_conjuntos/exemplos/02_aplicacao.py
