# Prever operações de conjuntos
# Enunciado:
# Com faltas = {1, 3, 5} e pedidos = {1, 2, 3}, preveja interseção e as duas diferenças possíveis.
#
# Dica:
# A diferença depende de qual conjunto aparece primeiro.
#
# Conferência:
# Interseção {1,3}; faltas sem pedidos {5}; pedidos sem faltas {2}.
#
# Apoio: 05_conjuntos/exemplos/01_fundamento.py, 05_conjuntos/exemplos/02_aplicacao.py
