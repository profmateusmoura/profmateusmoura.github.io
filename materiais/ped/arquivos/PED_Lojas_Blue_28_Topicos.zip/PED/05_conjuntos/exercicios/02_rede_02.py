# Interseção de lojas — Lojas Blue
# Enunciado:
# Use conjuntos {1, 3, 5} com falta e {1, 2, 3} com pedidos. Mostre ids presentes nos dois.
#
# Dica:
# Interseção representa ambas as condições.
#
# Conferência:
# Ids 1 e 3, em qualquer ordem.
#
# Apoio: 05_conjuntos/exemplos/01_fundamento.py, 05_conjuntos/exemplos/02_aplicacao.py
