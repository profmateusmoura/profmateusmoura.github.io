# Diferença — Lojas Blue
# Enunciado:
# Usando os conjuntos anteriores, mostre lojas com falta e sem pedido.
#
# Dica:
# A diferença tem direção.
#
# Conferência:
# Somente id 5.
#
# Apoio: 05_conjuntos/exemplos/01_fundamento.py, 05_conjuntos/exemplos/02_aplicacao.py
