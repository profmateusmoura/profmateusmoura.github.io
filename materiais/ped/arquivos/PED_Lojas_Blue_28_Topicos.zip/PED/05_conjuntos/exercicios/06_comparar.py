# Comparar lista e conjunto
# Enunciado:
# Represente UFs MG, MG e SP em lista e conjunto. Compare repetição, ordem e a pergunta de pertencimento. Escolha a estrutura para guardar uma sequência de visitas e para guardar apenas cobertura por UF.
#
# Dica:
# Os dois problemas pedem propriedades diferentes.
#
# Conferência:
# A sequência preserva as duas visitas MG; cobertura possui duas UFs.
#
# Apoio: 05_conjuntos/exemplos/01_fundamento.py, 05_conjuntos/exemplos/02_aplicacao.py
