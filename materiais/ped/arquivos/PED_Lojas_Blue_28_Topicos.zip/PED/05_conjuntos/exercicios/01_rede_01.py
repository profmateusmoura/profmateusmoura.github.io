# UFs distintas — Lojas Blue
# Enunciado:
# Transforme [MG, MG, SP] em conjunto e informe quantidade de UFs.
#
# Dica:
# Não dependa da ordem de apresentação.
#
# Conferência:
# Duas UFs distintas.
#
# Apoio: 05_conjuntos/exemplos/01_fundamento.py, 05_conjuntos/exemplos/02_aplicacao.py
