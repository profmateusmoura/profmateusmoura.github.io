# Comparar contagens, sem depender do relógio
# Execução: python 13_complexidade_basica/exemplos/02_crescimento_de_percursos.py
# Confira na saída: '20 registros: 20 visitas e 400 pares'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

def contar_visitas(quantidade):
    """Retorne visitas de um percurso com quantidade inteira não negativa."""
    visitas = 0
    for i in range(quantidade):
        visitas += 1
    return visitas

def contar_pares(quantidade):
    """Retorne pares de dois percursos completos, incluindo pares iguais."""
    pares = 0
    for i in range(quantidade):
        for j in range(quantidade):
            pares += 1
    return pares

for quantidade in (0, 10, 20):
    print(quantidade, "registros:", contar_visitas(quantidade), "visitas e", contar_pares(quantidade), "pares")
# Dobrar a entrada dobra o primeiro contador e quadruplica o segundo.
# Essa diferença é estrutural e pode ser observada sem medir segundos.
