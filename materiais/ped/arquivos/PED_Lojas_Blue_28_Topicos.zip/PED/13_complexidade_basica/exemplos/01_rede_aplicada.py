# Contar inspeções de um percurso — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Catálogo completo: 20'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def contar_inspecoes(produtos):
    """Retorne quantos registros um percurso completo inspeciona."""
    passos = 0
    for produto in produtos:
        passos += 1
    return passos

print("Recorte de um:", contar_inspecoes(dados["produtos"][:1]))
print("Catálogo completo:", contar_inspecoes(dados["produtos"]))
# O(n) descreve crescimento, não uma duração fixa em segundos.
# Acesso direto à posição tem custo O(1); percorrer tudo tem custo O(n).
