# Contar percurso — Lojas Blue
# Enunciado:
# Conte inspeções de um percurso completo no catálogo e em um recorte de um produto.
#
# Dica:
# Uma volta corresponde a um registro inspecionado.
#
# Conferência:
# Catálogo vinte; recorte uma inspeção.
#
# Apoio: 13_complexidade_basica/exemplos/01_rede_aplicada.py
