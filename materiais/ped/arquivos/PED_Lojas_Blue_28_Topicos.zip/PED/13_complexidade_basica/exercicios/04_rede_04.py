# Custo de índice — Lojas Blue
# Enunciado:
# Compare construir índice e fazer uma consulta com construir uma vez e consultar muitas.
#
# Dica:
# Inclua custo de preparação e memória.
#
# Conferência:
# Explique quando o índice pode compensar; não prometa pior caso constante.
#
# Apoio: 13_complexidade_basica/exemplos/01_rede_aplicada.py
