# Comparar duas contagens
# Enunciado:
# Implemente percurso de todos os produtos e percurso de todos os pares. Conte o trabalho e explique o efeito de aumentar a base.
#
# Dica:
# O objetivo é contar processamentos, não buscar ou ordenar.
#
# Conferência:
# Para vinte produtos, vinte visitas e quatrocentos pares.
#
# Apoio: 13_complexidade_basica/exemplos/02_crescimento_de_percursos.py
