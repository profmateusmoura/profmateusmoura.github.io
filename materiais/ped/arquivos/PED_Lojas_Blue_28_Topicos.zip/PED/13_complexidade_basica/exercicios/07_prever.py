# Prever crescimento em outra escala
# Enunciado:
# Preveja visitas e pares para quantidades três, seis e doze. Compare o efeito de dobrar a entrada.
#
# Dica:
# Use o número de execuções do corpo interno.
#
# Conferência:
# Visitas 3,6,12; pares 9,36,144.
#
# Apoio: 13_complexidade_basica/exemplos/02_crescimento_de_percursos.py
