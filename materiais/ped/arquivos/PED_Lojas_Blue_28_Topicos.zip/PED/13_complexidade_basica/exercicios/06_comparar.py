# Comparar custos completos
# Enunciado:
# Compare fazer uma consulta após construir um índice com construir o índice uma vez e fazer cem consultas. Liste custo de preparação, consultas e memória.
#
# Dica:
# Uma operação rápida pode exigir preparação anterior.
#
# Conferência:
# A comparação inclui os três custos, e não só a duração de uma consulta.
#
# Apoio: 13_complexidade_basica/exemplos/01_rede_aplicada.py
