# Prever crescimento
# Enunciado:
# Um percurso visita n produtos e outro visita todos os pares de produtos. Preveja os passos para n igual a 10 e 20.
#
# Dica:
# Um percurso completo e um produto de percursos têm crescimentos diferentes.
#
# Conferência:
# O primeiro passa de 10 a 20; o segundo, de 100 a 400.
#
# Apoio: 13_complexidade_basica/exemplos/01_rede_aplicada.py
