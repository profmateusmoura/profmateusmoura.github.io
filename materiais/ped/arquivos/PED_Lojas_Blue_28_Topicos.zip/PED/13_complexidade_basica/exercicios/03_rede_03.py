# Laços aninhados — Lojas Blue
# Enunciado:
# Conte pares de produtos em laços que percorrem toda a lista duas vezes.
#
# Dica:
# Relacione a contagem com n ao quadrado.
#
# Conferência:
# Vinte produtos geram quatrocentos pares.
#
# Apoio: 13_complexidade_basica/exemplos/01_rede_aplicada.py
