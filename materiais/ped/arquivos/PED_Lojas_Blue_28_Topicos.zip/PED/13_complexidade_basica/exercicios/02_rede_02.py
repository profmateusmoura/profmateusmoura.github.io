# Escalar entrada — Lojas Blue
# Enunciado:
# Use repetições de uma lista de ids para observar contagem proporcional no percurso completo.
#
# Dica:
# Não confunda contar passos com medir segundos.
#
# Conferência:
# Dobrar tamanho dobra inspeções do percurso.
#
# Apoio: 13_complexidade_basica/exemplos/01_rede_aplicada.py
