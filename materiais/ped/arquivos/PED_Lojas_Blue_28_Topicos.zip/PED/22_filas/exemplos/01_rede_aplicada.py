# Atender reposições em FIFO — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Restantes: 5'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

from collections import deque

fila = deque()
for solicitacao in dados["solicitacoes_reposicao"]:
    if solicitacao["status"] == "AGUARDANDO":
        fila.append(solicitacao)
atendido = fila.popleft()
print("Primeira solicitação:", atendido["id"])
print("Restantes:", len(fila))
# FIFO segue a ordem de chegada no arquivo; não implementa prioridade.
# append e popleft de deque evitam deslocar todos os itens como pop(0) em list.
