# Fila de reposições — Lojas Blue
# Enunciado:
# Enfileire solicitações AGUARDANDO na ordem do arquivo e atenda a primeira.
#
# Dica:
# FIFO não usa prioridade.
#
# Conferência:
# Primeira id 1; restam cinco.
#
# Apoio: 22_filas/exemplos/01_rede_aplicada.py
