# Corrigir atendimento vazio
# Enunciado:
# Uma rotina chama popleft sem verificar a fila vazia. Defina um retorno de ausência e complete uma operação segura.
#
# Dica:
# Ausência prevista pode ser representada por None.
#
# Conferência:
# Uma sétima tentativa após atender as seis solicitações retorna ausência, sem erro.
#
# Apoio: 22_filas/exemplos/01_rede_aplicada.py
