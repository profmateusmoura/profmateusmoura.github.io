# Comparar prioridade — Lojas Blue
# Enunciado:
# Em outra fila, ordene antes por prioridade decrescente e id crescente. Explique a diferença para FIFO.
#
# Dica:
# Regra da simulação: prioridade 3 é a maior.
#
# Conferência:
# Primeira prioridade 3, id 2.
#
# Apoio: 22_filas/exemplos/01_rede_aplicada.py
