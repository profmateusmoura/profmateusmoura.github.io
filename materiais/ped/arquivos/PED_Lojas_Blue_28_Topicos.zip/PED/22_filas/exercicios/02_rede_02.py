# Fila vazia — Lojas Blue
# Enunciado:
# Atenda todos os elementos e tente atender mais uma vez com operação segura.
#
# Dica:
# Defina retorno de ausência.
#
# Conferência:
# Nenhum popleft em fila vazia sem proteção.
#
# Apoio: 22_filas/exemplos/01_rede_aplicada.py
