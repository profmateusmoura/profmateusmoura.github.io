# Nova chegada — Lojas Blue
# Enunciado:
# Depois de enfileirar os seis ids, acrescente simulação id 7.
#
# Dica:
# Nova chegada vai ao fim.
#
# Conferência:
# Id 7 é o último a sair.
#
# Apoio: 22_filas/exemplos/01_rede_aplicada.py
