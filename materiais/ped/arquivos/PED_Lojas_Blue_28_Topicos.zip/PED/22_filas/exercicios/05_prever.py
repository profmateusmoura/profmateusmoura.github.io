# Prever duas políticas de atendimento
# Enunciado:
# Para as solicitações da base, preveja a primeira atendida em FIFO e na ordenação por prioridade decrescente, com empate por id crescente.
#
# Dica:
# Chegada e urgência são critérios distintos.
#
# Conferência:
# FIFO atende id 1; prioridade atende id 2.
#
# Apoio: 22_filas/exemplos/01_rede_aplicada.py
