# Extensão AVL — Lojas Blue
# Enunciado:
# Como desafio avançado, implemente inserção com altura e fator de equilíbrio, escolhendo RR, LL, LR ou RL.
#
# Dica:
# Reutilize os quatro casos anteriores; explique invariantes.
#
# Conferência:
# Após inserir ids 1 a 20, todos os fatores têm módulo até um; ordem é preservada.
#
# Apoio: 26_balanceamento_e_rotacoes/exemplos/01_rede_aplicada.py
