# Rotação LL — Lojas Blue
# Enunciado:
# Implemente rotação à direita no caso 3,2,1.
#
# Dica:
# É simétrica à rotação do exemplo.
#
# Conferência:
# Nova raiz 2, altura dois.
#
# Apoio: 26_balanceamento_e_rotacoes/exemplos/01_rede_aplicada.py
