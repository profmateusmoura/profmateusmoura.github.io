# Prever uma rotação
# Enunciado:
# Desenhe a árvore de ids 1,2,3 antes e depois da rotação à esquerda. Anote raiz, filhos e altura em nós.
#
# Dica:
# Uma rotação deve preservar o percurso em-ordem.
#
# Conferência:
# A raiz passa de 1 para 2 e a altura de três para dois.
#
# Apoio: 26_balanceamento_e_rotacoes/exemplos/01_rede_aplicada.py
