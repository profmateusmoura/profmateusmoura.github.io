# Rotação RR — Lojas Blue
# Enunciado:
# Refaça a rotação à esquerda do caso 1,2,3 e confira chaves e altura.
#
# Dica:
# Preserve a subárvore intermediária.
#
# Conferência:
# Nova raiz 2, altura dois.
#
# Apoio: 26_balanceamento_e_rotacoes/exemplos/01_rede_aplicada.py
