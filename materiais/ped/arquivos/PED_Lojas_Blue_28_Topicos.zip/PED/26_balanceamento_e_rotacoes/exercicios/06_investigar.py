# Corrigir a subárvore intermediária
# Enunciado:
# Em rotação à esquerda de raiz 1 com filho direito 3, que tem filho esquerdo 2, identifique onde o nó 2 deve ficar. Complete a rotação sem perdê-lo.
#
# Dica:
# Guarde a referência intermediária antes de religar os nós.
#
# Conferência:
# O percurso final conserva 1,2,3 uma vez cada.
#
# Apoio: 26_balanceamento_e_rotacoes/exemplos/01_rede_aplicada.py
