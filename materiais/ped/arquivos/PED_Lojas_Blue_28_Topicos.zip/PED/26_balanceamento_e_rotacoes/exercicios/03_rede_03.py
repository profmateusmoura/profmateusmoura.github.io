# Casos LR e RL — Lojas Blue
# Enunciado:
# Combine rotações para sequências 3,1,2 e 1,3,2.
#
# Dica:
# Primeiro gire o filho, depois a raiz.
#
# Conferência:
# Ambas terminam com raiz 2 e ordem 1,2,3.
#
# Apoio: 26_balanceamento_e_rotacoes/exemplos/01_rede_aplicada.py
