# Rotação simples e altura — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Altura depois: 2'
# Sem entrada interativa.

def altura(no):
    """Retorne altura em nós: vazia zero, folha um."""
    if no is None:
        return 0
    return 1 + max(altura(no["esquerda"]), altura(no["direita"]))

def rotacionar_esquerda(raiz):
    """Rotacione uma raiz com filho direito existente; preserve ordem BST."""
    nova = raiz["direita"]
    intermediaria = nova["esquerda"]
    nova["esquerda"] = raiz
    raiz["direita"] = intermediaria
    return nova

# Recorte de ids de produtos; este caso pede rotação RR.
arvore = {"chave": 1, "esquerda": None, "direita":
    {"chave": 2, "esquerda": None, "direita":
    {"chave": 3, "esquerda": None, "direita": None}}}
print("Altura antes:", altura(arvore))
arvore = rotacionar_esquerda(arvore)
print("Nova raiz:", arvore["chave"])
print("Altura depois:", altura(arvore))
# É um estudo de rotação, não uma implementação completa de inserção AVL.
