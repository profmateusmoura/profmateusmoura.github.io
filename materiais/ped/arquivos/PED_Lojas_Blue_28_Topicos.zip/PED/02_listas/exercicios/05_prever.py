# Prever o compartilhamento
# Enunciado:
# Considere saldos = [18, 4], outra = saldos e outra.append(6). Preveja saldos e explique quantas listas existem.
#
# Dica:
# Atribuição não cria automaticamente uma nova lista.
#
# Conferência:
# As duas variáveis mostram [18, 4, 6] e apontam para a mesma lista.
#
# Apoio: 02_listas/exemplos/01_fundamento.py, 02_listas/exemplos/02_aplicacao.py
