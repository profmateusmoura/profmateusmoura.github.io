# Prever a posição deslocada
# Enunciado:
# Faça teste de mesa da remoção de saldos quatro e seis durante o percurso de [4,6,18]. Identifique qual elemento deixa de ser testado.
#
# Dica:
# Após remove, as posições seguintes mudam.
#
# Conferência:
# A versão incorreta deixa seis; a seleção em outra lista conserva só dezoito.
#
# Apoio: 02_listas/exemplos/03_remover_durante_percurso.py
