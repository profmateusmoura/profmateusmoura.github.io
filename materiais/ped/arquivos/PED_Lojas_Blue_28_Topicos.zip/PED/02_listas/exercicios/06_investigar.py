# Corrigir a simulação
# Enunciado:
# Uma simulação deve alterar seu primeiro saldo sem afetar saldos = [18, 4], mas usa simulacao = saldos. Corrija a criação da simulação.
#
# Dica:
# Os elementos são números, então uma cópia da lista externa basta.
#
# Conferência:
# Alterar a primeira posição da simulação não muda o 18 original.
#
# Apoio: 02_listas/exemplos/01_fundamento.py, 02_listas/exemplos/02_aplicacao.py
