# Corrigir a seleção de saldo
# Enunciado:
# Implemente uma função que recebe saldos e devolve os não críticos para mínimo dez, sem alterar a entrada. Confira elementos consecutivos selecionados e removidos.
#
# Dica:
# Escolha entre produzir nova lista ou percorrer uma cópia da origem.
#
# Conferência:
# [4,6,18] devolve [18]; a entrada permanece [4,6,18].
#
# Apoio: 02_listas/exemplos/03_remover_durante_percurso.py
