# Catálogo pequeno — Lojas Blue
# Enunciado:
# Crie lista com Shampoo, Perfume e Sabonete. Mostre cada nome e o total.
#
# Dica:
# Percorra os elementos diretamente.
#
# Conferência:
# Três linhas de nomes e total três.
#
# Apoio: 02_listas/exemplos/01_fundamento.py, 02_listas/exemplos/02_aplicacao.py
