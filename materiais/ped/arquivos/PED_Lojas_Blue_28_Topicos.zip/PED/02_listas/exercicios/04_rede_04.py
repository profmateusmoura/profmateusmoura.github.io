# Filtrar saldos — Lojas Blue
# Enunciado:
# A partir de [18, 4, 25, 6], forme nova lista dos valores abaixo de 10.
#
# Dica:
# Use append ao selecionar.
#
# Conferência:
# Resultado [4, 6]; original preservado.
#
# Apoio: 02_listas/exemplos/01_fundamento.py, 02_listas/exemplos/02_aplicacao.py
