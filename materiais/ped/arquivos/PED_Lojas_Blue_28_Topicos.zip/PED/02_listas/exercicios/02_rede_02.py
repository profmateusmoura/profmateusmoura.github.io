# Inserção e remoção — Lojas Blue
# Enunciado:
# Comece com a lista anterior, acrescente Batom e remova Perfume.
#
# Dica:
# Confirme que o elemento existe antes de remover.
#
# Conferência:
# Restam Shampoo, Sabonete e Batom nessa ordem.
#
# Apoio: 02_listas/exemplos/01_fundamento.py, 02_listas/exemplos/02_aplicacao.py
