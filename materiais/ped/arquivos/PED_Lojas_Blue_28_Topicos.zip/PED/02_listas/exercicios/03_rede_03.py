# Simular saldos — Lojas Blue
# Enunciado:
# Use [18, 4, 25, 6], copie a lista e altere só o primeiro saldo da cópia para 15.
#
# Dica:
# Uma cópia separa as duas listas de inteiros.
#
# Conferência:
# O original começa em 18; a cópia, em 15.
#
# Apoio: 02_listas/exemplos/01_fundamento.py, 02_listas/exemplos/02_aplicacao.py
