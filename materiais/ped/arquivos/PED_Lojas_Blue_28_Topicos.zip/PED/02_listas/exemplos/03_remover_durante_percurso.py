# Por que uma remoção pode pular um elemento
# Execução: python 02_listas/exemplos/03_remover_durante_percurso.py
# Confira na saída: 'Seleção sem deslocar origem: [18]'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

saldos = [4, 6, 18]
incorreta = saldos.copy()
# Contraexemplo intencional: remove desloca a próxima posição para a esquerda,
# enquanto o for continua avançando. O seis pode deixar de ser visitado.
for saldo in incorreta:
    if saldo < 10:
        incorreta.remove(saldo)
print("Remoção no percurso:", incorreta)
correta = []
# Outra lista recebe os elementos desejados; a origem não se desloca.
for saldo in saldos:
    if saldo >= 10:
        correta.append(saldo)
print("Seleção sem deslocar origem:", correta)
print("Origem:", saldos)
