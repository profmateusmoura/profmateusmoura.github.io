# Aplicação: Coleção de nomes — cenário didático Lojas Blue
# Objetivo: Combinar o recurso com conceitos já estudados.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Original: [18, 4, 25, 6]'
# Sem entrada interativa.

saldos = [18, 4, 25, 6]
copia = saldos.copy()  # Cópia suficiente: os elementos são inteiros.
copia[0] = 0
print("Original:", saldos)
print("Simulação:", copia)
# Atribuir outra = saldos criaria um segundo nome para a mesma lista.
