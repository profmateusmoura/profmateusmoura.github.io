# Coleção de nomes — cenário didático Lojas Blue
# Objetivo: Introduzir o recurso com um recorte da rede.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Quantidade: 3'
# Sem entrada interativa.

# Recorte de nomes, sem registros aninhados ou JSON.
nomes = ["Shampoo Nutritivo 350 ml", "Perfume Floral 100 ml"]
nomes.append("Sabonete em Barra")
print("Primeiro:", nomes[0])
for nome in nomes:
    print(nome)
print("Quantidade:", len(nomes))
# remove procura o valor; neste recorte sabemos que o nome existe.
nomes.remove("Sabonete em Barra")
print("Após remoção:", len(nomes))
