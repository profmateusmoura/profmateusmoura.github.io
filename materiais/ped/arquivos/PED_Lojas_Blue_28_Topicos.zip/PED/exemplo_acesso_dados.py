"""Exemplo complementar: consulte a rede usando o módulo de acesso.

Execute depois do tópico 09 de PED. O exemplo direto de json.load continua
no tópico 09; aqui reutilizamos sua leitura para concentrar nas consultas.
"""
from dados.acesso import carregar_dados, listar_produtos, buscar_produto, consultar_estoque


def main():
    """Carregue uma vez e apresente três consultas sobre a mesma fotografia."""
    dados = carregar_dados()
    print("Produtos:", len(listar_produtos(dados)))
    produto = buscar_produto(dados, 1)
    if produto is not None:
        print("Produto 1:", produto["nome"])
    estoque = consultar_estoque(dados, 1, 1)
    if estoque is not None:
        print("Saldo na unidade 1:", estoque["quantidade"])


if __name__ == "__main__":
    main()
