# Prever os tipos após a leitura
# Enunciado:
# Converta um texto JSON com inteiro, texto, booleano e null. Descreva os tipos Python resultantes e reconverta para texto.
#
# Dica:
# A sintaxe JSON possui seus próprios nomes para os valores lógicos e nulo.
#
# Conferência:
# null resulta em None; true resulta em True.
#
# Apoio: 09_json_arquivo_e_memoria/exemplos/03_documento_texto_memoria.py
