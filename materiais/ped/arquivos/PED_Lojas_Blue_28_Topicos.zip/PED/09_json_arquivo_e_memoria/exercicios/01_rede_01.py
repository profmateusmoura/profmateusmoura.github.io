# Inventário do JSON — Lojas Blue
# Enunciado:
# Carregue dados/lojas_blue.json e mostre a quantidade de unidades, produtos e estoques.
#
# Dica:
# Use o caminho relativo ao arquivo do programa.
#
# Conferência:
# 10 unidades, 20 produtos, 18 posições.
#
# Apoio: 09_json_arquivo_e_memoria/exemplos/01_fundamento.py, 09_json_arquivo_e_memoria/exemplos/02_aplicacao.py
