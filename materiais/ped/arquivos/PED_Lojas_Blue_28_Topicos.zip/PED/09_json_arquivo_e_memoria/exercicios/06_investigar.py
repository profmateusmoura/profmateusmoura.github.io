# Completar uma consulta reutilizável
# Enunciado:
# Usando carregar_dados do módulo dados.acesso, implemente produtos_ate_preco(dados, limite), retornando registros com preco menor ou igual ao limite.
#
# Dica:
# Carregue uma vez e passe dados para o cálculo.
#
# Conferência:
# Limite 24.90 inclui o produto 1 e exclui o produto 4; limite zero retorna lista vazia.
#
# Apoio: 09_json_arquivo_e_memoria/exemplos/01_fundamento.py, 09_json_arquivo_e_memoria/exemplos/02_aplicacao.py
