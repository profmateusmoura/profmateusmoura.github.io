# Prever duas validações diferentes
# Enunciado:
# Compare JSON malformado, lista vazia válida e objeto vazio válido. Indique qual falha na leitura e qual pode não atender ao formato de uma aplicação.
#
# Dica:
# Sintaxe e contrato de estrutura são etapas diferentes.
#
# Conferência:
# A lista é JSON válido, mas não é um objeto de raiz.
#
# Apoio: 09_json_arquivo_e_memoria/exemplos/04_sintaxe_e_formato_raiz.py
