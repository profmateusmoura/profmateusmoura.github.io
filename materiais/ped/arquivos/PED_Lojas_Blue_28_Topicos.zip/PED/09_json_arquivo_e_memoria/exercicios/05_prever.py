# Prever memória e persistência
# Enunciado:
# Carregue a base, altere na memória o preço do produto 1 para 22.41 e carregue a fonte novamente. Preveja os preços nas duas bases.
#
# Dica:
# Cada leitura constrói uma nova estrutura na memória.
#
# Conferência:
# A estrutura alterada contém 22.41 e a nova carga contém 24.90.
#
# Apoio: 09_json_arquivo_e_memoria/exemplos/01_fundamento.py, 09_json_arquivo_e_memoria/exemplos/02_aplicacao.py
