# Consulta sem alteração — Lojas Blue
# Enunciado:
# Liste nomes dos produtos com preço até 30, lendo o JSON.
#
# Dica:
# Compare registros; não crie pedidos ou itens inexistentes.
#
# Conferência:
# Produto 1 aparece; produto 4 não aparece.
#
# Apoio: 09_json_arquivo_e_memoria/exemplos/01_fundamento.py, 09_json_arquivo_e_memoria/exemplos/02_aplicacao.py
