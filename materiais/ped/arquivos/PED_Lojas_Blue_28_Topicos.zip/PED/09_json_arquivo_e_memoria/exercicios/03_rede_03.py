# Cópia persistente — Lojas Blue
# Enunciado:
# Grave a simulação em saidas/rede_teste.json e recarregue esse arquivo.
#
# Dica:
# Use json.dump com UTF-8.
#
# Conferência:
# A cópia tem 22.41; a fonte tem 24.90.
#
# Apoio: 09_json_arquivo_e_memoria/exemplos/01_fundamento.py, 09_json_arquivo_e_memoria/exemplos/02_aplicacao.py
