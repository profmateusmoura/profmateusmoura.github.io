# Memória e disco — Lojas Blue
# Enunciado:
# Altere na memória o preço do produto 1 para 22.41; carregue novamente a fonte e compare.
#
# Dica:
# Não grave a fonte.
#
# Conferência:
# Nova carga continua com 24.90.
#
# Apoio: 09_json_arquivo_e_memoria/exemplos/01_fundamento.py, 09_json_arquivo_e_memoria/exemplos/02_aplicacao.py
