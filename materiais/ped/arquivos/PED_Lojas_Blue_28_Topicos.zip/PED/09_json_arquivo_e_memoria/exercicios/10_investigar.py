# Completar uma borda de leitura
# Enunciado:
# Leia um documento e trate erro de sintaxe. Em leitura bem-sucedida, aceite só raiz de dicionário. Mostre mensagens distintas sem converter falha em base vazia.
#
# Dica:
# Verifique o tipo depois de concluir a leitura.
#
# Conferência:
# JSON malformado e lista válida são recusados por razões diferentes.
#
# Apoio: 09_json_arquivo_e_memoria/exemplos/04_sintaxe_e_formato_raiz.py
