# Comparar load e loads
# Enunciado:
# Implemente a leitura do mesmo documento a partir de uma string e de um arquivo. Compare estruturas resultantes e explique o argumento que cada operação recebe.
#
# Dica:
# Uma função recebe texto; a outra recebe um arquivo aberto.
#
# Conferência:
# As estruturas são equivalentes para o mesmo documento.
#
# Apoio: 09_json_arquivo_e_memoria/exemplos/03_documento_texto_memoria.py
