# Texto JSON e estruturas em memória
# Execução: python 09_json_arquivo_e_memoria/exemplos/03_documento_texto_memoria.py
# Confira na saída: 'Mesmos valores: True'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

import json

texto = '{"produto_id": 1, "ativo": true, "observacao": null}'
# loads lê uma string que contém um documento; load lê de um arquivo aberto.
registro = json.loads(texto)
print("Ativo:", registro["ativo"], type(registro["ativo"]).__name__)
print("Observação:", registro["observacao"])
# dumps faz o caminho inverso: produz um texto, sem gravar arquivo.
novo_texto = json.dumps(registro, ensure_ascii=False)
reconstruido = json.loads(novo_texto)
print("Mesmos valores:", reconstruido == registro)
# true/null do JSON correspondem a True/None no Python. São sintaxes distintas
# para representar os valores, não nomes de variáveis que precisam ser definidos.
