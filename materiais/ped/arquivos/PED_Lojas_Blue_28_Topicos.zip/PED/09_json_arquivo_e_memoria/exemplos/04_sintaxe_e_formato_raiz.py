# JSON válido nem sempre tem o formato esperado
# Execução: python 09_json_arquivo_e_memoria/exemplos/04_sintaxe_e_formato_raiz.py
# Confira na saída: 'Raiz lida, mas formato esperado é objeto'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

import json

textos = ['{"produtos": []}', '[]', '{"produtos":']
for texto in textos:
    try:
        raiz = json.loads(texto)
    except json.JSONDecodeError:
        print("Erro de sintaxe JSON")
    else:
        # Primeiro a sintaxe permite ler; depois a aplicação pode perguntar
        # se recebeu o tipo de estrutura que seu contrato espera.
        if isinstance(raiz, dict):
            print("Raiz de objeto aceita")
        else:
            print("Raiz lida, mas formato esperado é objeto")
# As referências entre tabelas serão conferidas no tópico de consistência.
