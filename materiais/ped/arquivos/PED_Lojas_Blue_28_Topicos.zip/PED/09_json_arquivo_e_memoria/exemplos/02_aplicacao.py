# Aplicação: Carregar a fotografia completa — cenário didático Lojas Blue
# Objetivo: Combinar o recurso com conceitos já estudados.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Preço na cópia: 22.41'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

# Alteração somente em memória; a fotografia fornecida é preservada.
dados["produtos"][0]["preco"] = 22.41
destino = Path.cwd() / "saidas" / "rede_simulada.json"
destino.parent.mkdir(exist_ok=True)
with destino.open("w", encoding="utf-8") as saida:
    json.dump(dados, saida, ensure_ascii=False, indent=2)
with destino.open(encoding="utf-8") as entrada:
    simulacao = json.load(entrada)
print(f"Preço na cópia: {simulacao['produtos'][0]['preco']:.2f}")
