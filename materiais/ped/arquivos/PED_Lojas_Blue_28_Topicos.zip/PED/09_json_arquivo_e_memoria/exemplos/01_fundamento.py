# Carregar a fotografia completa — cenário didático Lojas Blue
# Objetivo: Introduzir o recurso com um recorte da rede.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Produtos: 20'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

print("Unidades:", len(dados["unidades"]))
print("Produtos:", len(dados["produtos"]))
print("Primeiro produto:", dados["produtos"][0]["nome"])
# Agora as coleções já são conhecidas: podemos explicar cada nível do acesso.
