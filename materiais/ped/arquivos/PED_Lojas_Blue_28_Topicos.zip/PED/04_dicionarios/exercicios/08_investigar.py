# Corrigir um teste de ausência
# Enunciado:
# Uma rotina trata preco = 0.0 como não cadastrado porque usa if not preco. Corrija para distinguir ausência e zero.
#
# Dica:
# Decida qual valor representa ausência antes de escrever a condição.
#
# Conferência:
# O brinde de preço zero deve ser apresentado como cadastrado.
#
# Apoio: 04_dicionarios/exemplos/03_ausencia_e_valor_zero.py
