# Campo opcional — Lojas Blue
# Enunciado:
# Consulte descricao com texto padrão quando estiver ausente.
#
# Dica:
# Use get sem criar o campo.
#
# Conferência:
# Mensagem não informada; registro continua sem descricao.
#
# Apoio: 04_dicionarios/exemplos/01_fundamento.py, 04_dicionarios/exemplos/02_aplicacao.py
