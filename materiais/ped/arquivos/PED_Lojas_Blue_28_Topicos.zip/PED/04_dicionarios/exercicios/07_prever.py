# Prever existência e valor
# Enunciado:
# Compare os registros com preco zero, preco 24.9 e sem chave preco. Preveja o resultado de in e get em cada um.
#
# Dica:
# Presença do campo e valor lógico do número são perguntas diferentes.
#
# Conferência:
# Zero e 24.9 têm a chave; somente o registro sem campo devolve None neste contrato.
#
# Apoio: 04_dicionarios/exemplos/03_ausencia_e_valor_zero.py
