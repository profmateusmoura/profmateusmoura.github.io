# Produto nomeado — Lojas Blue
# Enunciado:
# Crie dicionário com id 4, nome Perfume Floral 100 ml e preco 129.9. Exiba cada campo.
#
# Dica:
# As chaves são nomes e não posições.
#
# Conferência:
# O nome deve ser recuperado pela chave nome.
#
# Apoio: 04_dicionarios/exemplos/01_fundamento.py, 04_dicionarios/exemplos/02_aplicacao.py
