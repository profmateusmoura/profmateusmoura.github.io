# Estoque por regra — Lojas Blue
# Enunciado:
# Crie registro com quantidade 4 e minimo 8 e informe crítico ou regular.
#
# Dica:
# Compare campos pelo significado.
#
# Conferência:
# Quantidade igual a 8 deve ser regular.
#
# Apoio: 04_dicionarios/exemplos/01_fundamento.py, 04_dicionarios/exemplos/02_aplicacao.py
