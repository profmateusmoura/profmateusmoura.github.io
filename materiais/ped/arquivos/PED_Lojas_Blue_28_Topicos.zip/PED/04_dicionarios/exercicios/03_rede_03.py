# Atualizar simulação — Lojas Blue
# Enunciado:
# Copie o produto e altere o preço da cópia para 116.91.
#
# Dica:
# Os campos são escalares, então copy é suficiente.
#
# Conferência:
# Original 129.90 e simulação 116.91.
#
# Apoio: 04_dicionarios/exemplos/01_fundamento.py, 04_dicionarios/exemplos/02_aplicacao.py
