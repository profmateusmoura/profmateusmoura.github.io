# Prever acesso e padrão
# Enunciado:
# Com produto = {"id": 1, "nome": "Shampoo"}, compare produto.get("descricao", "não informada") com consultar a chave descricao diretamente.
#
# Dica:
# O padrão de get não cria o campo no dicionário.
#
# Conferência:
# get retorna o texto padrão; o acesso obrigatório levanta KeyError.
#
# Apoio: 04_dicionarios/exemplos/01_fundamento.py, 04_dicionarios/exemplos/02_aplicacao.py
