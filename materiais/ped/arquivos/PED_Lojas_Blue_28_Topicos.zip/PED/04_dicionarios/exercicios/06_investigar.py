# Corrigir uma atualização
# Enunciado:
# Um programa tenta alterar o preço usando produto[0] = 22.41 em um registro com chave preco. Corrija a chave e confira o conjunto de campos antes e depois.
#
# Dica:
# Chaves numéricas e textuais são diferentes.
#
# Conferência:
# O campo preco muda e nenhuma chave 0 é acrescentada.
#
# Apoio: 04_dicionarios/exemplos/01_fundamento.py, 04_dicionarios/exemplos/02_aplicacao.py
