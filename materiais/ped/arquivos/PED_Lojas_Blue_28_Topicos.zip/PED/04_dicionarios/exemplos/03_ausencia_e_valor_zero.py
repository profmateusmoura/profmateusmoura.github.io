# Campo ausente é diferente de preço zero
# Execução: python 04_dicionarios/exemplos/03_ausencia_e_valor_zero.py
# Confira na saída: 'Preço cadastrado: 0.00'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

brinde = {"id": 99, "nome": "Amostra", "preco": 0.0}
preco = brinde.get("preco")
# Um número zero é um valor cadastrado. Testar apenas 'if preco' confundiria
# esse valor com ausência. Neste contrato, get devolve None quando falta a chave.
if preco is None:
    print("Preço não cadastrado")
else:
    print(f"Preço cadastrado: {preco:.2f}")
sem_preco = {"id": 100, "nome": "Produto em cadastro"}
print("Ausência:", sem_preco.get("preco") is None)
# in consulta a existência da chave, independentemente do valor armazenado.
print("Brinde possui chave preco:", "preco" in brinde)
