# Aplicação: Registro de produto — cenário didático Lojas Blue
# Objetivo: Combinar o recurso com conceitos já estudados.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Crítico: True'
# Sem entrada interativa.

estoque = {"unidade_id": 1, "produto_id": 4, "quantidade": 4, "minimo": 8}
for campo, valor in estoque.items():
    print(campo, "=", valor)
# O acesso pela chave mantém explícito o significado de cada valor.
print("Crítico:", estoque["quantidade"] < estoque["minimo"])
copia = estoque.copy()  # Outro dicionário com os mesmos valores escalares.
copia["quantidade"] = 8
print("Saldo original:", estoque["quantidade"])
