# Registro de produto — cenário didático Lojas Blue
# Objetivo: Introduzir o recurso com um recorte da rede.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Preço simulado: 22.41'
# Sem entrada interativa.

produto = {"id": 1, "nome": "Shampoo Nutritivo 350 ml", "preco": 24.9}
print(produto["nome"])
# As chaves nomeiam campos; não são posições numéricas na sequência.
produto["preco"] = 22.41  # Simulação local de promoção.
print(f"Preço simulado: {produto['preco']:.2f}")
print("Campo ausente:", produto.get("descricao", "não informada"))
