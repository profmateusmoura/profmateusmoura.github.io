# Extrair prefixo — Lojas Blue
# Enunciado:
# Guarde Perfume Floral 100 ml e mostre só os sete primeiros caracteres.
#
# Dica:
# Fatiamento exclui a posição final.
#
# Conferência:
# O prefixo deve ser Perfume.
#
# Apoio: 01_strings/exemplos/01_fundamento.py, 01_strings/exemplos/02_aplicacao.py
