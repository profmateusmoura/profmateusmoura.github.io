# Localizar palavra — Lojas Blue
# Enunciado:
# No nome Shampoo Nutritivo 350 ml, informe se existe Nutritivo e quantos caracteres há.
#
# Dica:
# Use in e len.
#
# Conferência:
# A palavra deve ser encontrada; espaços contam no tamanho.
#
# Apoio: 01_strings/exemplos/01_fundamento.py, 01_strings/exemplos/02_aplicacao.py
