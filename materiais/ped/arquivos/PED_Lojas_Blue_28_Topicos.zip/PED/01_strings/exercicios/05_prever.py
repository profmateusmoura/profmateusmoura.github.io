# Prever a normalização
# Enunciado:
# Preveja o resultado de aplicar strip e depois lower ao texto " WHATSAPP ". Explique o resultado se a ordem das chamadas for invertida.
#
# Dica:
# A remoção de espaços e a mudança de caixa atuam em aspectos diferentes.
#
# Conferência:
# Neste texto, as duas ordens produzem whatsapp.
#
# Apoio: 01_strings/exemplos/01_fundamento.py, 01_strings/exemplos/02_aplicacao.py
