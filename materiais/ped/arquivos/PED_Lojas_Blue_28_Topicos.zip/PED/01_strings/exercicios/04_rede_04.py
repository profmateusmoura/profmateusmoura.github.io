# Contar letras — Lojas Blue
# Enunciado:
# Leia nome de produto e conte letras a sem diferenciar maiúsculas. Não conte outras letras como a acentuadas.
#
# Dica:
# Padronize antes do percurso.
#
# Conferência:
# Sabonete em Barra possui três letras a.
#
# Apoio: 01_strings/exemplos/01_fundamento.py, 01_strings/exemplos/02_aplicacao.py
