# Corrigir a comparação textual
# Enunciado:
# Uma consulta compara diretamente o texto digitado com "whatsapp" e falha para " WhatsApp ". Corrija a preparação do comando e confira três variações de caixa e espaços.
#
# Dica:
# Normalize a entrada antes da comparação.
#
# Conferência:
# As três formas devem selecionar o mesmo comando.
#
# Apoio: 01_strings/exemplos/01_fundamento.py, 01_strings/exemplos/02_aplicacao.py
