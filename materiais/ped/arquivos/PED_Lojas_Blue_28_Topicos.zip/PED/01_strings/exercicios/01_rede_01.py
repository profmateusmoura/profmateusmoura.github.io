# Padronizar comando — Lojas Blue
# Enunciado:
# Leia um comando, retire espaços nas extremidades e converta para minúsculas.
#
# Dica:
# Retire os espaços das extremidades antes de converter para minúsculas.
#
# Conferência:
# Entrada WHATSAPP com espaços resulta em whatsapp.
#
# Apoio: 01_strings/exemplos/01_fundamento.py, 01_strings/exemplos/02_aplicacao.py
