# Nomes e comandos — cenário didático Lojas Blue
# Objetivo: Introduzir o recurso com um recorte da rede.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Comando: whatsapp'
# Sem entrada interativa.

nome = "  Shampoo Nutritivo 350 ml  "
# strip remove espaços nas extremidades; não altera o texto original.
limpo = nome.strip()
print(limpo)
print("Prefixo:", limpo[:7])
print("Contém Shampoo:", "Shampoo" in limpo)
print("Comando:", " WHATSAPP ".strip().lower())
