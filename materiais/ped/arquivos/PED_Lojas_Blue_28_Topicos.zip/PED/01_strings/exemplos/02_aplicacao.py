# Aplicação: Nomes e comandos — cenário didático Lojas Blue
# Objetivo: Combinar o recurso com conceitos já estudados.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Espaços: 3'
# Sem entrada interativa.

nome = "Perfume Floral 100 ml"
# Strings são sequências; agora podemos percorrer os caracteres.
espacos = 0
for caractere in nome:
    if caractere == " ":
        espacos += 1
print("Espaços:", espacos)
print("Tamanho:", len(nome))
