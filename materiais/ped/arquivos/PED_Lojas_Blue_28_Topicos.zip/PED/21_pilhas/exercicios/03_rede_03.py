# Pilha vazia — Lojas Blue
# Enunciado:
# Defina operações seguras de consultar topo e desempilhar vazio.
#
# Dica:
# Documente retorno de ausência.
#
# Conferência:
# Nenhuma operação deve gerar IndexError.
#
# Apoio: 21_pilhas/exemplos/01_rede_aplicada.py
