# Isolar pedidos — Lojas Blue
# Enunciado:
# Crie uma pilha por pedido usando dicionário.
#
# Dica:
# Não misture eventos de pedidos diferentes.
#
# Conferência:
# Pedido 1006 termina em ENVIADO; 1003 em SEPARACAO.
#
# Apoio: 21_pilhas/exemplos/01_rede_aplicada.py
