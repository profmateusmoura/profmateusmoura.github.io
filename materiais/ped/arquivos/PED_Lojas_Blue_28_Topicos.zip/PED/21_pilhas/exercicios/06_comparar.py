# Comparar ordem e armazenamento
# Enunciado:
# Considere os mesmos eventos embaralhados no arquivo. Explique por que a posição física não basta para reconstruir o histórico e implemente a preparação necessária.
#
# Dica:
# Use a coluna que representa a sequência do pedido.
#
# Conferência:
# O topo final deve permanecer SEPARACAO.
#
# Apoio: 21_pilhas/exemplos/01_rede_aplicada.py
