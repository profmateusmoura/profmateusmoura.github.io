# Desfazer simulado — Lojas Blue
# Enunciado:
# Remova o último status somente se existir um estado anterior.
#
# Dica:
# Não apague o estado inicial por engano.
#
# Conferência:
# Depois de desfazer: PAGAMENTO_APROVADO.
#
# Apoio: 21_pilhas/exemplos/01_rede_aplicada.py
