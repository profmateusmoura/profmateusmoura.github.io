# Histórico do pedido — Lojas Blue
# Enunciado:
# Monte pilha de status do pedido 1003 respeitando ordem crescente do campo ordem.
#
# Dica:
# O topo é o evento mais recente.
#
# Conferência:
# Topo SEPARACAO.
#
# Apoio: 21_pilhas/exemplos/01_rede_aplicada.py
