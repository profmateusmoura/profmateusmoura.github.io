# Prever o topo do histórico
# Enunciado:
# Para o pedido 1003, ordene os eventos pela coluna ordem e preveja o topo antes e depois de um pop.
#
# Dica:
# O evento mais recente entra por último.
#
# Conferência:
# Antes SEPARACAO; depois PAGAMENTO_APROVADO.
#
# Apoio: 21_pilhas/exemplos/01_rede_aplicada.py
