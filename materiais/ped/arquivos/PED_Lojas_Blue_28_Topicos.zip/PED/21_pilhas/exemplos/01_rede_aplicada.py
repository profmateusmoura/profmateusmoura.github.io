# Histórico LIFO de um pedido — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Estado anterior: PAGAMENTO_APROVADO'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def chave_ordem(evento):
    """Retorne a ordem temporal explícita do registro de histórico."""
    return evento["ordem"]

eventos = []
for evento in dados["historico_status_pedidos"]:
    if evento["pedido_id"] == 1003:
        eventos.append(evento)
pilha = []
for evento in sorted(eventos, key=chave_ordem):
    pilha.append(evento["status"])
print("Estado atual:", pilha[-1])
if len(pilha) > 1:
    removido = pilha.pop()
    print("Simulação de desfazer:", removido)
    print("Estado anterior:", pilha[-1])
# O JSON não muda. Este desfazer é somente uma simulação do histórico carregado.
