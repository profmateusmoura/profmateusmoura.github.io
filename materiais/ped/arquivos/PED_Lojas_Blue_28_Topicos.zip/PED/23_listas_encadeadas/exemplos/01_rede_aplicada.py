# Nós ligados por referência — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Percurso: [3, 2, 1]'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def inserir_inicio(cabeca, valor):
    """Retorne um novo nó cujo próximo é a cabeça anterior."""
    return {"valor": valor, "proximo": cabeca}

def percorrer(cabeca):
    """Retorne valores na ordem dos nós, terminando em None."""
    valores = []
    atual = cabeca
    while atual is not None:
        valores.append(atual["valor"])
        atual = atual["proximo"]
    return valores

cabeca = None
for produto in dados["produtos"][:3]:
    cabeca = inserir_inicio(cabeca, produto["id"])
print("Percurso:", percorrer(cabeca))
# Inserir no início inverte a ordem de chegada; não há classe neste TAD.
