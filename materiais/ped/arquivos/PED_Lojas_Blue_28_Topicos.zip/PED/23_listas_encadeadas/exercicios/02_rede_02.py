# Inserção final — Lojas Blue
# Enunciado:
# Implemente inclusão no fim, tratando cabeça vazia.
#
# Dica:
# A última referência proximo é None.
#
# Conferência:
# Inserir 1, 2, 3 produz percurso 1, 2, 3.
#
# Apoio: 23_listas_encadeadas/exemplos/01_rede_aplicada.py
