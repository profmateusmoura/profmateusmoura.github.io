# Remoção — Lojas Blue
# Enunciado:
# Remova o primeiro nó com id alvo, tratando remoção da cabeça e ausência.
#
# Dica:
# Atualize a referência que apontava para o removido.
#
# Conferência:
# Remover cabeça não perde o restante.
#
# Apoio: 23_listas_encadeadas/exemplos/01_rede_aplicada.py
