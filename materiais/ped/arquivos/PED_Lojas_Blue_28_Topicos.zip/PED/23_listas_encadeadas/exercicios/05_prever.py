# Prever a cabeça da lista
# Enunciado:
# Insira ids 1, 2 e 3 no início de uma lista encadeada e desenhe as referências após cada inserção.
#
# Dica:
# O nó novo aponta para a cabeça anterior.
#
# Conferência:
# Cabeça final 3, percurso 3,2,1.
#
# Apoio: 23_listas_encadeadas/exemplos/01_rede_aplicada.py
