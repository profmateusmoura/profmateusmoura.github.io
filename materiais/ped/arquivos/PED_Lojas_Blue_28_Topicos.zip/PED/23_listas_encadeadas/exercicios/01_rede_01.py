# Inserção inicial — Lojas Blue
# Enunciado:
# Insira ids 1, 2 e 3 no início de lista encadeada.
#
# Dica:
# A nova cabeça aponta para a anterior.
#
# Conferência:
# Percurso 3, 2, 1.
#
# Apoio: 23_listas_encadeadas/exemplos/01_rede_aplicada.py
