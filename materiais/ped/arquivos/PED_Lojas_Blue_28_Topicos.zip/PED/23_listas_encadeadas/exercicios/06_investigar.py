# Corrigir remoção da cabeça
# Enunciado:
# Uma remoção altera apenas uma variável local e não devolve a nova cabeça ao chamador. Defina o contrato e corrija a atualização da cabeça.
#
# Dica:
# O chamador precisa guardar a raiz retornada pela operação.
#
# Conferência:
# Remover 3 de 3,2,1 preserva o percurso 2,1.
#
# Apoio: 23_listas_encadeadas/exemplos/01_rede_aplicada.py
