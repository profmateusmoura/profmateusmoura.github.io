# Contagem — Lojas Blue
# Enunciado:
# Conte nós sem converter antes em lista.
#
# Dica:
# Avance até None.
#
# Conferência:
# Vazia zero; três inserções três.
#
# Apoio: 23_listas_encadeadas/exemplos/01_rede_aplicada.py
