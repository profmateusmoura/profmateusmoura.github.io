# Pré-condição de ordem — Lojas Blue
# Enunciado:
# Use cópia com ids embaralhados e explique por que deve ordená-la antes de buscar.
#
# Dica:
# A ordem é relativa à mesma chave comparada.
#
# Conferência:
# Após ordenar, primeiro, último e ausente são corretos.
#
# Apoio: 15_busca_binaria/exemplos/01_rede_aplicada.py
