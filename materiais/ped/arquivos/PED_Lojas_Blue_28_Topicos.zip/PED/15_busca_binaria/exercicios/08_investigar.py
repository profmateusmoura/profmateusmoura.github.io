# Corrigir a recuperação do registro
# Enunciado:
# Uma rotina busca na lista ordenada por id e recupera o resultado na lista original embaralhada. Corrija o fluxo, preservando a relação entre índice e lista.
#
# Dica:
# Retorne o registro ou mantenha a mesma lista até a recuperação.
#
# Conferência:
# O alvo quatro sempre recupera Perfume Floral 100 ml.
#
# Apoio: 15_busca_binaria/exemplos/02_indice_e_lista_ordenada.py
