# Busca binária básica — Lojas Blue
# Enunciado:
# Em ids crescentes, retorne índice do alvo ou -1.
#
# Dica:
# O intervalo restante deve diminuir em toda volta.
#
# Conferência:
# Id 4 no catálogo ordenado ocupa índice 3.
#
# Apoio: 15_busca_binaria/exemplos/01_rede_aplicada.py
