# Prever o uso de um índice
# Enunciado:
# Explique se o índice três encontrado em produtos por id pode ser aplicado sem mudança em produtos por preço. Use os registros para conferir.
#
# Dica:
# Uma posição não carrega a identidade da sequência em que foi calculada.
#
# Conferência:
# Só a lista consultada garante que o índice aponta para id quatro.
#
# Apoio: 15_busca_binaria/exemplos/02_indice_e_lista_ordenada.py
