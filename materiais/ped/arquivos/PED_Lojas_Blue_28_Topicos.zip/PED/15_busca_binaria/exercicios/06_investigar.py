# Corrigir o avanço dos limites
# Enunciado:
# Uma busca faz inicio = meio quando o alvo é maior e pode repetir o mesmo intervalo. Corrija o avanço e teste uma lista com dois elementos e alvo ausente.
#
# Dica:
# O intervalo precisa diminuir estritamente.
#
# Conferência:
# [1,4] com alvo 3 termina em ausência.
#
# Apoio: 15_busca_binaria/exemplos/01_rede_aplicada.py
