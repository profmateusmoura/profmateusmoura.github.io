# Produto por posição — Lojas Blue
# Enunciado:
# Use o índice retornado para recuperar o produto da lista ordenada correspondente.
#
# Dica:
# Não aplique o índice em outra lista com ordem diferente.
#
# Conferência:
# Id 4 recupera o nome do perfume.
#
# Apoio: 15_busca_binaria/exemplos/01_rede_aplicada.py
