# Vazio e unitário — Lojas Blue
# Enunciado:
# Teste a busca com lista vazia e listas de um elemento, com e sem alvo.
#
# Dica:
# O intervalo pode nascer vazio.
#
# Conferência:
# Vazio retorna -1; [4] com 4 retorna 0.
#
# Apoio: 15_busca_binaria/exemplos/01_rede_aplicada.py
