# Prever o intervalo restante
# Enunciado:
# Em ids [1, 4, 8, 10, 20], busque 10 e anote início, fim e meio de cada avaliação da busca binária.
#
# Dica:
# Cada comparação descarta o meio já inspecionado quando não é o alvo.
#
# Conferência:
# O resultado é índice três.
#
# Apoio: 15_busca_binaria/exemplos/01_rede_aplicada.py
