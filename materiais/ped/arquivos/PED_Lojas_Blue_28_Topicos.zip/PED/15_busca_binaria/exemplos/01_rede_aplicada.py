# Busca em ids previamente ordenados — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Índice do id 4: 3'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def buscar_binaria(ids, alvo):
    """Retorne o índice de alvo ou -1; ids deve estar crescente e sem repetição."""
    inicio = 0
    fim = len(ids) - 1
    while inicio <= fim:
        meio = (inicio + fim) // 2
        if ids[meio] == alvo:
            return meio
        if ids[meio] < alvo:
            inicio = meio + 1
        else:
            fim = meio - 1
    return -1

ids = []
for produto in dados["produtos"]:
    ids.append(produto["id"])
ids.sort()  # Preparação explícita: busca binária exige ordem na mesma chave.
print("Índice do id 4:", buscar_binaria(ids, 4))
print("Ausente:", buscar_binaria(ids, 999))
