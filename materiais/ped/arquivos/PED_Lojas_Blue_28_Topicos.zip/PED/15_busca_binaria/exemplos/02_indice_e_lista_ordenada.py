# O índice pertence à lista em que foi encontrado
# Execução: python 15_busca_binaria/exemplos/02_indice_e_lista_ordenada.py
# Confira na saída: 'Produto recuperado: Perfume Floral 100 ml'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

from pathlib import Path
import json

# A fonte é localizada pela posição deste exemplo dentro do curso.
caminho = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with caminho.open(encoding="utf-8") as arquivo:
    dados = json.load(arquivo)

def chave_id(produto):
    """Retorne a identidade usada na ordenação e na busca deste exemplo."""
    return produto["id"]

def buscar_indice(produtos, alvo):
    """Retorne índice do id alvo ou -1; produtos está crescente por id."""
    inicio = 0
    fim = len(produtos) - 1
    while inicio <= fim:
        meio = (inicio + fim) // 2
        if produtos[meio]["id"] == alvo:
            return meio
        if produtos[meio]["id"] < alvo:
            inicio = meio + 1
        else:
            fim = meio - 1
    return -1

por_id = sorted(dados["produtos"], key=chave_id)
indice = buscar_indice(por_id, 4)
if indice != -1:
    print("Índice:", indice)
    print("Produto recuperado:", por_id[indice]["nome"])
# Recuperar usando esse índice em uma lista organizada por outra chave
# poderia devolver outro produto. A sequência consultada faz parte do resultado.
