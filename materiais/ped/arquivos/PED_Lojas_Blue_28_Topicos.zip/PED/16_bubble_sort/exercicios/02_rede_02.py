# Otimização — Lojas Blue
# Enunciado:
# Interrompa após passagem sem troca e conte comparações.
#
# Dica:
# A flag reinicia em cada passagem.
#
# Conferência:
# Lista já ordenada exige uma passagem.
#
# Apoio: 16_bubble_sort/exemplos/01_rede_aplicada.py
