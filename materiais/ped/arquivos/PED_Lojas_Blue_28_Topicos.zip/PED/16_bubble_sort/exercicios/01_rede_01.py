# Bubble por preço — Lojas Blue
# Enunciado:
# Ordene cópia dos produtos por preço e, no empate, id. Implemente trocas adjacentes.
#
# Dica:
# A maior chave vai para o fim a cada passagem.
#
# Conferência:
# Primeiro produto 20, Sabonete em Barra.
#
# Apoio: 16_bubble_sort/exemplos/01_rede_aplicada.py
