# Corrigir a flag de troca
# Enunciado:
# Uma versão otimizada mantém a flag de troca de uma passagem anterior. Corrija sua reinicialização e teste a lista já ordenada.
#
# Dica:
# A flag descreve apenas a passagem atual.
#
# Conferência:
# Em entrada ordenada, o algoritmo termina após uma passagem.
#
# Apoio: 16_bubble_sort/exemplos/01_rede_aplicada.py
