# Empates artificiais — Lojas Blue
# Enunciado:
# Use recorte com preços iguais e ids 3, 1 e 2.
#
# Dica:
# O desempate por id faz parte do contrato.
#
# Conferência:
# Ordem de ids 1, 2, 3.
#
# Apoio: 16_bubble_sort/exemplos/01_rede_aplicada.py
