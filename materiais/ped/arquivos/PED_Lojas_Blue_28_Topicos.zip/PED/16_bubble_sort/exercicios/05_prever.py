# Prever uma passagem Bubble
# Enunciado:
# Com preços [30, 10, 20], descreva as comparações e o estado após uma passagem de Bubble da esquerda para a direita.
#
# Dica:
# Compare sempre elementos adjacentes.
#
# Conferência:
# Ao fim da primeira passagem, o maior preço está na última posição.
#
# Apoio: 16_bubble_sort/exemplos/01_rede_aplicada.py
