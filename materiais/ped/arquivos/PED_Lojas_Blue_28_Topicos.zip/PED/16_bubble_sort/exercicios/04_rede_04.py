# Preservação — Lojas Blue
# Enunciado:
# Teste vazio, unitário e preservação da lista original.
#
# Dica:
# Cópia rasa preserva ordem, não cria novos registros.
#
# Conferência:
# Quantidade e conteúdo não desaparecem.
#
# Apoio: 16_bubble_sort/exemplos/01_rede_aplicada.py
