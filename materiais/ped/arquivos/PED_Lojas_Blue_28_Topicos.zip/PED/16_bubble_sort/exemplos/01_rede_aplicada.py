# Ordenar produtos por trocas adjacentes — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Mais barato: Sabonete em Barra'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def bubble(produtos):
    """Retorne cópia ordenada por (preco, id), preservando a lista recebida."""
    # Outra lista permite trocar a ordem sem reordenar a lista do chamador; os registros
    # continuam compartilhados.
    resultado = produtos.copy()
    # A cada passagem, a maior chave restante alcança o fim do trecho; o limite desse trecho
    # diminui.
    for fim in range(len(resultado) - 1, 0, -1):
        # A flag pertence somente à passagem atual. Se não houver troca, a lista já atende à
        # ordem pedida.
        mudou = False
        for i in range(fim):
            chave_a = (resultado[i]["preco"], resultado[i]["id"])
            chave_b = (resultado[i + 1]["preco"], resultado[i + 1]["id"])
            # A comparação usa preço e, em empate, id. A troca acontece só quando os vizinhos
            # estão fora dessa ordem.
            if chave_a > chave_b:
                resultado[i], resultado[i + 1] = resultado[i + 1], resultado[i]
                mudou = True
        if not mudou:
            break
    return resultado

ordenados = bubble(dados["produtos"])
print("Mais barato:", ordenados[0]["nome"])
# A cópia é rasa: a ordem original fica intacta; os registros ainda são compartilhados.
