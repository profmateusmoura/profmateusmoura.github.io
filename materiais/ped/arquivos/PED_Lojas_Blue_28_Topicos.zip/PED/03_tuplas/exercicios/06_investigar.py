# Completar um retorno
# Enunciado:
# Implemente resumir(saldos), para lista não vazia, retornando a tupla (menor, maior, soma). Desempacote o resultado em três variáveis e apresente.
#
# Dica:
# Documente a ordem das posições do retorno.
#
# Conferência:
# [18, 4, 6] produz 4, 18 e 28.
#
# Apoio: 03_tuplas/exemplos/01_fundamento.py, 03_tuplas/exemplos/02_aplicacao.py
