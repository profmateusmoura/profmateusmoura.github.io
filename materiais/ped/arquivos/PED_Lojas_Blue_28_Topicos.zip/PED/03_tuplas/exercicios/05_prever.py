# Prever o desempacotamento
# Enunciado:
# Preveja os valores de unidade e produto após desempacotar a chave (1, 4). Compare o tipo de (1) com o tipo de (1,).
#
# Dica:
# A vírgula tem papel na construção da tupla.
#
# Conferência:
# Unidade um, produto quatro; somente (1,) é tupla.
#
# Apoio: 03_tuplas/exemplos/01_fundamento.py, 03_tuplas/exemplos/02_aplicacao.py
