# Registro fixo — Lojas Blue
# Enunciado:
# Represente produto por (id, nome, preco) com 1, Shampoo e 24.9. Exiba os campos sem alterar a tupla.
#
# Dica:
# Tupla fixa a estrutura das posições.
#
# Conferência:
# Preço apresentado 24.90.
#
# Apoio: 03_tuplas/exemplos/01_fundamento.py, 03_tuplas/exemplos/02_aplicacao.py
