# Retorno de extremos — Lojas Blue
# Enunciado:
# Crie função que devolva menor e maior de lista não vazia de saldos.
#
# Dica:
# Retorne uma tupla e desempacote no chamador.
#
# Conferência:
# [18, 4, 25, 6] resulta em 4 e 25.
#
# Apoio: 03_tuplas/exemplos/01_fundamento.py, 03_tuplas/exemplos/02_aplicacao.py
