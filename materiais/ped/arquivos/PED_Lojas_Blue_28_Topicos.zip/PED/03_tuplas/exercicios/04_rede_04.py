# Tupla unitária — Lojas Blue
# Enunciado:
# Crie tupla contendo somente o id 1 e mostre seu tipo e tamanho.
#
# Dica:
# Parênteses sem vírgula não bastam.
#
# Conferência:
# Tipo tuple, tamanho um.
#
# Apoio: 03_tuplas/exemplos/01_fundamento.py, 03_tuplas/exemplos/02_aplicacao.py
