# Identidade composta — Lojas Blue
# Enunciado:
# Crie a tupla unidade 1 e produto 4 e desempacote para dois nomes.
#
# Dica:
# A ordem dos campos deve ser documentada.
#
# Conferência:
# Os nomes recebem 1 e 4.
#
# Apoio: 03_tuplas/exemplos/01_fundamento.py, 03_tuplas/exemplos/02_aplicacao.py
