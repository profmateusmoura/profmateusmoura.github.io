# Identidade de uma posição — cenário didático Lojas Blue
# Objetivo: Introduzir o recurso com um recorte da rede.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Produto: 4'
# Sem entrada interativa.

# A posição é identificada por unidade e produto, não só pelo produto.
chave = (1, 4)
unidade_id, produto_id = chave
print("Unidade:", unidade_id)
print("Produto:", produto_id)
# A tupla não permite atribuir outro valor a chave[0].
