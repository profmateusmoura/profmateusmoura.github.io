# Aplicação: Identidade de uma posição — cenário didático Lojas Blue
# Objetivo: Combinar o recurso com conceitos já estudados.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Extremos: 4 25'
# Sem entrada interativa.

def extremos(valores):
    """Retorne (menor, maior) de uma lista não vazia de números."""
    menor = valores[0]
    maior = valores[0]
    for valor in valores:
        if valor < menor:
            menor = valor
        if valor > maior:
            maior = valor
    return menor, maior

menor, maior = extremos([18, 4, 25, 6])
print("Extremos:", menor, maior)
# A vírgula também distingue a tupla unitária de um valor entre parênteses.
unitaria = (1,)
print("Tupla unitária:", unitaria, "tamanho:", len(unitaria))
