# Ordem de estudo — PED

Siga a numeração. O contexto permanece; a representação e as responsabilidades evoluem.
Os tópicos oferecem conceitos, exemplos completos e atividades de objetivos variados; consulte os índices para os complementos.
Não avance usando um recurso de tópico posterior só para abreviar a solução.

## 01_strings

**Texto como sequência.** Índices começam em zero; o fim de um fatiamento é excluído. Métodos de str devolvem outro texto. Estude strip, lower, len, in e percurso antes de normalizar comandos.

Exemplos:

- [Nomes e comandos — cenário didático Lojas Blue](01_strings/exemplos/01_fundamento.py)
- [Aplicação: Nomes e comandos — cenário didático Lojas Blue](01_strings/exemplos/02_aplicacao.py)

Exercícios:

- [Padronizar comando — Lojas Blue](01_strings/exercicios/01_rede_01.py)
- [Localizar palavra — Lojas Blue](01_strings/exercicios/02_rede_02.py)
- [Extrair prefixo — Lojas Blue](01_strings/exercicios/03_rede_03.py)
- [Contar letras — Lojas Blue](01_strings/exercicios/04_rede_04.py)
- [Prever a normalização](01_strings/exercicios/05_prever.py)
- [Corrigir a comparação textual](01_strings/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 02_listas

**Coleção mutável.** Listas guardam sequência de valores. Estude índice, append, remoção, percurso e cópia. Uma atribuição compartilha a lista; copy separa apenas a lista externa.

Exemplos:

- [Coleção de nomes — cenário didático Lojas Blue](02_listas/exemplos/01_fundamento.py)
- [Aplicação: Coleção de nomes — cenário didático Lojas Blue](02_listas/exemplos/02_aplicacao.py)
- [Por que uma remoção pode pular um elemento](02_listas/exemplos/03_remover_durante_percurso.py)

Exercícios:

- [Catálogo pequeno — Lojas Blue](02_listas/exercicios/01_rede_01.py)
- [Inserção e remoção — Lojas Blue](02_listas/exercicios/02_rede_02.py)
- [Simular saldos — Lojas Blue](02_listas/exercicios/03_rede_03.py)
- [Filtrar saldos — Lojas Blue](02_listas/exercicios/04_rede_04.py)
- [Prever o compartilhamento](02_listas/exercicios/05_prever.py)
- [Corrigir a simulação](02_listas/exercicios/06_investigar.py)
- [Prever a posição deslocada](02_listas/exercicios/07_prever.py)
- [Corrigir a seleção de saldo](02_listas/exercicios/08_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 03_tuplas

**Registro posicional fixo.** Tuplas são imutáveis, mas podem referenciar objetos mutáveis. Documente a ordem dos campos. Uma tupla de um elemento exige vírgula; retorno múltiplo e desempacotamento são introduzidos aqui.

Exemplos:

- [Identidade de uma posição — cenário didático Lojas Blue](03_tuplas/exemplos/01_fundamento.py)
- [Aplicação: Identidade de uma posição — cenário didático Lojas Blue](03_tuplas/exemplos/02_aplicacao.py)

Exercícios:

- [Identidade composta — Lojas Blue](03_tuplas/exercicios/01_rede_01.py)
- [Registro fixo — Lojas Blue](03_tuplas/exercicios/02_rede_02.py)
- [Retorno de extremos — Lojas Blue](03_tuplas/exercicios/03_rede_03.py)
- [Tupla unitária — Lojas Blue](03_tuplas/exercicios/04_rede_04.py)
- [Prever o desempacotamento](03_tuplas/exercicios/05_prever.py)
- [Completar um retorno](03_tuplas/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 04_dicionarios

**Campos nomeados.** Dicionários relacionam chaves e valores. Compare acesso obrigatório e get com padrão. items fornece pares chave/valor. Comece por um registro, antes de listas de registros.

Exemplos:

- [Registro de produto — cenário didático Lojas Blue](04_dicionarios/exemplos/01_fundamento.py)
- [Aplicação: Registro de produto — cenário didático Lojas Blue](04_dicionarios/exemplos/02_aplicacao.py)
- [Campo ausente é diferente de preço zero](04_dicionarios/exemplos/03_ausencia_e_valor_zero.py)

Exercícios:

- [Produto nomeado — Lojas Blue](04_dicionarios/exercicios/01_rede_01.py)
- [Campo opcional — Lojas Blue](04_dicionarios/exercicios/02_rede_02.py)
- [Atualizar simulação — Lojas Blue](04_dicionarios/exercicios/03_rede_03.py)
- [Estoque por regra — Lojas Blue](04_dicionarios/exercicios/04_rede_04.py)
- [Prever acesso e padrão](04_dicionarios/exercicios/05_prever.py)
- [Corrigir uma atualização](04_dicionarios/exercicios/06_investigar.py)
- [Prever existência e valor](04_dicionarios/exercicios/07_prever.py)
- [Corrigir um teste de ausência](04_dicionarios/exercicios/08_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 05_conjuntos

**Unicidade e pertencimento.** Conjuntos removem repetições e oferecem interseção, diferença e subconjunto. Não dependa de ordem. sorted pode produzir uma lista para apresentar resultados de forma estável.

Exemplos:

- [UFs sem repetição — cenário didático Lojas Blue](05_conjuntos/exemplos/01_fundamento.py)
- [Aplicação: UFs sem repetição — cenário didático Lojas Blue](05_conjuntos/exemplos/02_aplicacao.py)

Exercícios:

- [UFs distintas — Lojas Blue](05_conjuntos/exercicios/01_rede_01.py)
- [Interseção de lojas — Lojas Blue](05_conjuntos/exercicios/02_rede_02.py)
- [Diferença — Lojas Blue](05_conjuntos/exercicios/03_rede_03.py)
- [Cobertura — Lojas Blue](05_conjuntos/exercicios/04_rede_04.py)
- [Prever operações de conjuntos](05_conjuntos/exercicios/05_prever.py)
- [Comparar lista e conjunto](05_conjuntos/exercicios/06_comparar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 06_estruturas_aninhadas

**Níveis de estrutura.** Uma lista pode conter dicionários e um dicionário pode conter listas. Descreva cada nível de um acesso. Copiar só a estrutura externa não isola os registros internos.

Exemplos:

- [Vários registros de estoque — cenário didático Lojas Blue](06_estruturas_aninhadas/exemplos/01_fundamento.py)
- [Aplicação: Vários registros de estoque — cenário didático Lojas Blue](06_estruturas_aninhadas/exemplos/02_aplicacao.py)

Exercícios:

- [Lista de posições — Lojas Blue](06_estruturas_aninhadas/exercicios/01_rede_01.py)
- [Agrupar por UF — Lojas Blue](06_estruturas_aninhadas/exercicios/02_rede_02.py)
- [Atualização localizada — Lojas Blue](06_estruturas_aninhadas/exercicios/03_rede_03.py)
- [Cópia de registros — Lojas Blue](06_estruturas_aninhadas/exercicios/04_rede_04.py)
- [Prever a cópia externa](06_estruturas_aninhadas/exercicios/05_prever.py)
- [Corrigir o isolamento](06_estruturas_aninhadas/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 07_funcoes_com_colecoes

**Contrato de coleção.** Declare se a função muta a entrada e se compartilha registros no retorno. Funções de seleção e totalização não precisam imprimir. Teste vazio, ausência e entrada unitária.

Exemplos:

- [Filtrar sem alterar o catálogo — cenário didático Lojas Blue](07_funcoes_com_colecoes/exemplos/01_fundamento.py)
- [Aplicação: Filtrar sem alterar o catálogo — cenário didático Lojas Blue](07_funcoes_com_colecoes/exemplos/02_aplicacao.py)
- [Índice acompanhado do valor e percursos paralelos](07_funcoes_com_colecoes/exemplos/03_enumerate_zip.py)
- [A mesma seleção com laço e compreensão](07_funcoes_com_colecoes/exemplos/04_laco_e_compreensao.py)
- [Quando um argumento padrão guarda estado entre chamadas](07_funcoes_com_colecoes/exemplos/05_padrao_mutavel.py)

Exercícios:

- [Função de filtragem — Lojas Blue](07_funcoes_com_colecoes/exercicios/01_rede_01.py)
- [Retornar nomes — Lojas Blue](07_funcoes_com_colecoes/exercicios/02_rede_02.py)
- [Total de pedidos — Lojas Blue](07_funcoes_com_colecoes/exercicios/03_rede_03.py)
- [Resumo por UF — Lojas Blue](07_funcoes_com_colecoes/exercicios/04_rede_04.py)
- [Prever o retorno selecionado](07_funcoes_com_colecoes/exercicios/05_prever.py)
- [Completar uma transformação](07_funcoes_com_colecoes/exercicios/06_investigar.py)
- [Prever o término de zip](07_funcoes_com_colecoes/exercicios/07_prever.py)
- [Completar uma conferência de correspondência](07_funcoes_com_colecoes/exercicios/08_investigar.py)
- [Comparar duas seleções](07_funcoes_com_colecoes/exercicios/09_prever.py)
- [Completar uma transformação](07_funcoes_com_colecoes/exercicios/10_investigar.py)
- [Prever o objeto padrão](07_funcoes_com_colecoes/exercicios/11_prever.py)
- [Corrigir o padrão de uma função](07_funcoes_com_colecoes/exercicios/12_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 08_arquivos_texto

**Representação persistente simples.** Path representa caminho; with fecha o arquivo; w substitui o conteúdo do destino; read lê texto e write escreve. Crie a pasta de saída e use UTF-8. A fonte é diferente do relatório.

Exemplos:

- [Gravar um relatório de texto — cenário didático Lojas Blue](08_arquivos_texto/exemplos/01_fundamento.py)
- [Aplicação: Gravar um relatório de texto — cenário didático Lojas Blue](08_arquivos_texto/exemplos/02_aplicacao.py)
- [Arquivo ausente e leitura bem-sucedida](08_arquivos_texto/exemplos/03_falhas_de_leitura.py)

Exercícios:

- [Gravar nomes — Lojas Blue](08_arquivos_texto/exercicios/01_rede_01.py)
- [Reler relatório — Lojas Blue](08_arquivos_texto/exercicios/02_rede_02.py)
- [Arquivo vazio — Lojas Blue](08_arquivos_texto/exercicios/03_rede_03.py)
- [Preservar fonte — Lojas Blue](08_arquivos_texto/exercicios/04_rede_04.py)
- [Prever os modos de escrita](08_arquivos_texto/exercicios/05_prever.py)
- [Corrigir uma contagem de linhas](08_arquivos_texto/exercicios/06_investigar.py)
- [Prever a borda de leitura](08_arquivos_texto/exercicios/07_prever.py)
- [Completar leitura com informação de falha](08_arquivos_texto/exercicios/08_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 09_json_arquivo_e_memoria

**Documento versus memória.** json.load lê arquivo em listas e dicionários. json.dump grava explicitamente uma cópia. Mutar a memória não persiste automaticamente. O caminho é calculado pela posição do exemplo.

Exemplos:

- [Carregar a fotografia completa — cenário didático Lojas Blue](09_json_arquivo_e_memoria/exemplos/01_fundamento.py)
- [Aplicação: Carregar a fotografia completa — cenário didático Lojas Blue](09_json_arquivo_e_memoria/exemplos/02_aplicacao.py)
- [Texto JSON e estruturas em memória](09_json_arquivo_e_memoria/exemplos/03_documento_texto_memoria.py)
- [JSON válido nem sempre tem o formato esperado](09_json_arquivo_e_memoria/exemplos/04_sintaxe_e_formato_raiz.py)

Exercícios:

- [Inventário do JSON — Lojas Blue](09_json_arquivo_e_memoria/exercicios/01_rede_01.py)
- [Memória e disco — Lojas Blue](09_json_arquivo_e_memoria/exercicios/02_rede_02.py)
- [Cópia persistente — Lojas Blue](09_json_arquivo_e_memoria/exercicios/03_rede_03.py)
- [Consulta sem alteração — Lojas Blue](09_json_arquivo_e_memoria/exercicios/04_rede_04.py)
- [Prever memória e persistência](09_json_arquivo_e_memoria/exercicios/05_prever.py)
- [Completar uma consulta reutilizável](09_json_arquivo_e_memoria/exercicios/06_investigar.py)
- [Prever os tipos após a leitura](09_json_arquivo_e_memoria/exercicios/07_prever.py)
- [Comparar load e loads](09_json_arquivo_e_memoria/exercicios/08_investigar.py)
- [Prever duas validações diferentes](09_json_arquivo_e_memoria/exercicios/09_prever.py)
- [Completar uma borda de leitura](09_json_arquivo_e_memoria/exercicios/10_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 10_relacionamentos_e_consistencia

**Relações por identidade.** unidade_id e produto_id são referências, não índices de lista. Verifique existência e duplicatas. A posição de estoque tem identidade composta, e o produto aparece em várias unidades.

Exemplos:

- [Relacionar produto, unidade e estoque — cenário didático Lojas Blue](10_relacionamentos_e_consistencia/exemplos/01_rede_aplicada.py)

Exercícios:

- [Resolver nomes — Lojas Blue](10_relacionamentos_e_consistencia/exercicios/01_rede_01.py)
- [Validar referências — Lojas Blue](10_relacionamentos_e_consistencia/exercicios/02_rede_02.py)
- [Identidade completa — Lojas Blue](10_relacionamentos_e_consistencia/exercicios/03_rede_03.py)
- [Erro simulado — Lojas Blue](10_relacionamentos_e_consistencia/exercicios/04_rede_04.py)
- [Prever a chave de uma posição](10_relacionamentos_e_consistencia/exercicios/05_prever.py)
- [Corrigir uma referência](10_relacionamentos_e_consistencia/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 11_recursao

**Caso-base e redução.** A recursão precisa de caso-base e problema menor em cada chamada. A pilha de chamadas tem limite. As primeiras funções são pequenas para que o estudante consiga rastrear cada retorno.

Exemplos:

- [Somar um intervalo de saldos por recursão — cenário didático Lojas Blue](11_recursao/exemplos/01_rede_aplicada.py)
- [Duas maneiras de somar os mesmos saldos](11_recursao/exemplos/02_iteracao_e_recursao.py)

Exercícios:

- [Soma recursiva — Lojas Blue](11_recursao/exercicios/01_rede_01.py)
- [Contagem recursiva — Lojas Blue](11_recursao/exercicios/02_rede_02.py)
- [Busca recursiva — Lojas Blue](11_recursao/exercicios/03_rede_03.py)
- [Limite da técnica — Lojas Blue](11_recursao/exercicios/04_rede_04.py)
- [Prever chamadas recursivas](11_recursao/exercicios/05_prever.py)
- [Corrigir a redução do problema](11_recursao/exercicios/06_investigar.py)
- [Rastrear os retornos pendentes](11_recursao/exercicios/07_prever.py)
- [Comparar o controle de término](11_recursao/exercicios/08_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 12_tads_procedurais

**Abstração sem classes.** TAD é definido por operações e contratos; a representação pode mudar. isinstance pergunta se um valor pertence a um tipo e raise ValueError recusa a criação de estado inválido. bool não deve ser tratado como quantidade de estoque. A interface protege operações; não é uma barreira de segurança.

Exemplos:

- [TAD estoque com funções — cenário didático Lojas Blue](12_tads_procedurais/exemplos/01_rede_aplicada.py)

Exercícios:

- [Contrato de retirada — Lojas Blue](12_tads_procedurais/exercicios/01_rede_01.py)
- [Reposição — Lojas Blue](12_tads_procedurais/exercicios/02_rede_02.py)
- [Consulta — Lojas Blue](12_tads_procedurais/exercicios/03_rede_03.py)
- [Comparar representações — Lojas Blue](12_tads_procedurais/exercicios/04_rede_04.py)
- [Prever uma sequência do TAD](12_tads_procedurais/exercicios/05_prever.py)
- [Corrigir o contrato](12_tads_procedurais/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 13_complexidade_basica

**Custo de operações.** Conte inspeções, compare crescimento e inclua preparação e memória. O(1), O(n), O(n²) e O(log n) descrevem escalas, não durações fixas. O exemplo observa um percurso completo, sem antecipar o algoritmo de busca do tópico 14.

Exemplos:

- [Contar inspeções de um percurso — cenário didático Lojas Blue](13_complexidade_basica/exemplos/01_rede_aplicada.py)
- [Comparar contagens, sem depender do relógio](13_complexidade_basica/exemplos/02_crescimento_de_percursos.py)

Exercícios:

- [Contar percurso — Lojas Blue](13_complexidade_basica/exercicios/01_rede_01.py)
- [Escalar entrada — Lojas Blue](13_complexidade_basica/exercicios/02_rede_02.py)
- [Laços aninhados — Lojas Blue](13_complexidade_basica/exercicios/03_rede_03.py)
- [Custo de índice — Lojas Blue](13_complexidade_basica/exercicios/04_rede_04.py)
- [Prever crescimento](13_complexidade_basica/exercicios/05_prever.py)
- [Comparar custos completos](13_complexidade_basica/exercicios/06_comparar.py)
- [Prever crescimento em outra escala](13_complexidade_basica/exercicios/07_prever.py)
- [Comparar duas contagens](13_complexidade_basica/exercicios/08_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 14_busca_linear

**Busca por percurso.** A busca linear não exige ordenação. Decida entre primeiro resultado e todos os resultados. Documente retorno None e compartilhamento do registro.

Exemplos:

- [Buscar por id com percurso explícito — cenário didático Lojas Blue](14_busca_linear/exemplos/01_rede_aplicada.py)
- [Primeiro resultado ou todas as correspondências](14_busca_linear/exemplos/02_primeiro_e_todos.py)

Exercícios:

- [Buscar produto — Lojas Blue](14_busca_linear/exercicios/01_rede_01.py)
- [Primeiro e último — Lojas Blue](14_busca_linear/exercicios/02_rede_02.py)
- [Várias correspondências — Lojas Blue](14_busca_linear/exercicios/03_rede_03.py)
- [Busca composta — Lojas Blue](14_busca_linear/exercicios/04_rede_04.py)
- [Prever a busca linear](14_busca_linear/exercicios/05_prever.py)
- [Corrigir a ausência antecipada](14_busca_linear/exercicios/06_investigar.py)
- [Prever encerramentos diferentes](14_busca_linear/exercicios/07_prever.py)
- [Completar consultas com contratos distintos](14_busca_linear/exercicios/08_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 15_busca_binaria

**Busca por redução de intervalo.** Exige ordenação pela mesma chave. Ajuste limites sem reaproveitar o meio já descartado. O índice retornado pertence à lista em que a busca foi feita.

Exemplos:

- [Busca em ids previamente ordenados — cenário didático Lojas Blue](15_busca_binaria/exemplos/01_rede_aplicada.py)
- [O índice pertence à lista em que foi encontrado](15_busca_binaria/exemplos/02_indice_e_lista_ordenada.py)

Exercícios:

- [Busca binária básica — Lojas Blue](15_busca_binaria/exercicios/01_rede_01.py)
- [Vazio e unitário — Lojas Blue](15_busca_binaria/exercicios/02_rede_02.py)
- [Pré-condição de ordem — Lojas Blue](15_busca_binaria/exercicios/03_rede_03.py)
- [Produto por posição — Lojas Blue](15_busca_binaria/exercicios/04_rede_04.py)
- [Prever o intervalo restante](15_busca_binaria/exercicios/05_prever.py)
- [Corrigir o avanço dos limites](15_busca_binaria/exercicios/06_investigar.py)
- [Prever o uso de um índice](15_busca_binaria/exercicios/07_prever.py)
- [Corrigir a recuperação do registro](15_busca_binaria/exercicios/08_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 16_bubble_sort

**Ordenação por trocas adjacentes.** Bubble compara vizinhos e pode encerrar após passagem sem trocas. A lista de entrada não muda; os registros continuam compartilhados. Preço e id definem uma chave total para os exemplos.

Exemplos:

- [Ordenar produtos por trocas adjacentes — cenário didático Lojas Blue](16_bubble_sort/exemplos/01_rede_aplicada.py)

Exercícios:

- [Bubble por preço — Lojas Blue](16_bubble_sort/exercicios/01_rede_01.py)
- [Otimização — Lojas Blue](16_bubble_sort/exercicios/02_rede_02.py)
- [Empates artificiais — Lojas Blue](16_bubble_sort/exercicios/03_rede_03.py)
- [Preservação — Lojas Blue](16_bubble_sort/exercicios/04_rede_04.py)
- [Prever uma passagem Bubble](16_bubble_sort/exercicios/05_prever.py)
- [Corrigir a flag de troca](16_bubble_sort/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 17_selection_sort

**Ordenação por seleção.** Selection fixa o menor restante em cada início. Sua versão básica realiza n(n-1)/2 comparações. Empates e direção de cada componente da chave devem ser explícitos.

Exemplos:

- [Selecionar o menor restante — cenário didático Lojas Blue](17_selection_sort/exemplos/01_rede_aplicada.py)

Exercícios:

- [Selection por preço — Lojas Blue](17_selection_sort/exercicios/01_rede_01.py)
- [Contar comparações — Lojas Blue](17_selection_sort/exercicios/02_rede_02.py)
- [Ordem inversa — Lojas Blue](17_selection_sort/exercicios/03_rede_03.py)
- [Casos pequenos — Lojas Blue](17_selection_sort/exercicios/04_rede_04.py)
- [Prever a seleção do menor](17_selection_sort/exercicios/05_prever.py)
- [Comparar critérios de desempate](17_selection_sort/exercicios/06_comparar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 18_insertion_sort

**Ordenação por inserção.** Insertion preserva o elemento atual e desloca maiores no prefixo organizado. Verifique limite antes de acessar. Compare deslocamentos em lista ordenada e quase ordenada.

Exemplos:

- [Inserir no prefixo organizado — cenário didático Lojas Blue](18_insertion_sort/exemplos/01_rede_aplicada.py)

Exercícios:

- [Insertion por preço — Lojas Blue](18_insertion_sort/exercicios/01_rede_01.py)
- [Quase organizado — Lojas Blue](18_insertion_sort/exercicios/02_rede_02.py)
- [Fronteira inicial — Lojas Blue](18_insertion_sort/exercicios/03_rede_03.py)
- [Comparar algoritmos — Lojas Blue](18_insertion_sort/exercicios/04_rede_04.py)
- [Prever os deslocamentos](18_insertion_sort/exercicios/05_prever.py)
- [Corrigir a fronteira do índice](18_insertion_sort/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 19_hash_e_indices

**Índice e identidade.** dict usa hashing internamente. A busca média costuma ser constante, mas não há promessa de pior caso constante. Índices precisam ser mantidos quando identidades mudam.

Exemplos:

- [Índice por identidade composta — cenário didático Lojas Blue](19_hash_e_indices/exemplos/01_rede_aplicada.py)

Exercícios:

- [Índice de produtos — Lojas Blue](19_hash_e_indices/exercicios/01_rede_01.py)
- [Índice de estoques — Lojas Blue](19_hash_e_indices/exercicios/02_rede_02.py)
- [Duplicata simulada — Lojas Blue](19_hash_e_indices/exercicios/03_rede_03.py)
- [Mudança de identidade — Lojas Blue](19_hash_e_indices/exercicios/04_rede_04.py)
- [Prever uma sobrescrita no índice](19_hash_e_indices/exercicios/05_prever.py)
- [Corrigir a detecção de duplicata](19_hash_e_indices/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 20_colisoes

**Hash visível.** A função módulo leva ids diferentes ao mesmo bucket. Encadeamento separado guarda os registros colididos na mesma lista. Nunca construa buckets com a mesma lista compartilhada.

Exemplos:

- [Buckets com encadeamento separado — cenário didático Lojas Blue](20_colisoes/exemplos/01_rede_aplicada.py)

Exercícios:

- [Colisão intencional — Lojas Blue](20_colisoes/exercicios/01_rede_01.py)
- [Atualizar id — Lojas Blue](20_colisoes/exercicios/02_rede_02.py)
- [Remover do bucket — Lojas Blue](20_colisoes/exercicios/03_rede_03.py)
- [Fator de carga — Lojas Blue](20_colisoes/exercicios/04_rede_04.py)
- [Prever o bucket](20_colisoes/exercicios/05_prever.py)
- [Corrigir o compartilhamento de buckets](20_colisoes/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 21_pilhas

**LIFO.** O último evento entra no topo e é o primeiro removido. Reconstrua eventos pela coluna ordem quando necessário. Não remova o estado inicial por engano; simular desfazer não grava o JSON.

Exemplos:

- [Histórico LIFO de um pedido — cenário didático Lojas Blue](21_pilhas/exemplos/01_rede_aplicada.py)

Exercícios:

- [Histórico do pedido — Lojas Blue](21_pilhas/exercicios/01_rede_01.py)
- [Desfazer simulado — Lojas Blue](21_pilhas/exercicios/02_rede_02.py)
- [Pilha vazia — Lojas Blue](21_pilhas/exercicios/03_rede_03.py)
- [Isolar pedidos — Lojas Blue](21_pilhas/exercicios/04_rede_04.py)
- [Prever o topo do histórico](21_pilhas/exercicios/05_prever.py)
- [Comparar ordem e armazenamento](21_pilhas/exercicios/06_comparar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 22_filas

**FIFO.** deque oferece append e popleft. Ordem de chegada e prioridade são políticas distintas. A fila do exemplo usa chegada; uma atividade compara com a ordenação prévia por prioridade.

Exemplos:

- [Atender reposições em FIFO — cenário didático Lojas Blue](22_filas/exemplos/01_rede_aplicada.py)

Exercícios:

- [Fila de reposições — Lojas Blue](22_filas/exercicios/01_rede_01.py)
- [Fila vazia — Lojas Blue](22_filas/exercicios/02_rede_02.py)
- [Nova chegada — Lojas Blue](22_filas/exercicios/03_rede_03.py)
- [Comparar prioridade — Lojas Blue](22_filas/exercicios/04_rede_04.py)
- [Prever duas políticas de atendimento](22_filas/exercicios/05_prever.py)
- [Corrigir atendimento vazio](22_filas/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 23_listas_encadeadas

**Encadeamento.** Um nó contém valor e referência ao próximo; None encerra. A cabeça pode ser vazia e pode mudar em inserção ou remoção. A inserção inicial inverte a sequência de chegada.

Exemplos:

- [Nós ligados por referência — cenário didático Lojas Blue](23_listas_encadeadas/exemplos/01_rede_aplicada.py)

Exercícios:

- [Inserção inicial — Lojas Blue](23_listas_encadeadas/exercicios/01_rede_01.py)
- [Inserção final — Lojas Blue](23_listas_encadeadas/exercicios/02_rede_02.py)
- [Remoção — Lojas Blue](23_listas_encadeadas/exercicios/03_rede_03.py)
- [Contagem — Lojas Blue](23_listas_encadeadas/exercicios/04_rede_04.py)
- [Prever a cabeça da lista](23_listas_encadeadas/exercicios/05_prever.py)
- [Corrigir remoção da cabeça](23_listas_encadeadas/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 24_arvores_binarias

**Ramificação.** Árvore binária tem no máximo dois filhos por nó e não implica ordenação. Percursos são recursivos. max escolhe o maior entre as alturas; defina vazia zero e folha um.

Exemplos:

- [Árvore de agrupamento de unidades — cenário didático Lojas Blue](24_arvores_binarias/exemplos/01_rede_aplicada.py)

Exercícios:

- [Contar árvore — Lojas Blue](24_arvores_binarias/exercicios/01_rede_01.py)
- [Altura — Lojas Blue](24_arvores_binarias/exercicios/02_rede_02.py)
- [Percursos — Lojas Blue](24_arvores_binarias/exercicios/03_rede_03.py)
- [Não presumir BST — Lojas Blue](24_arvores_binarias/exercicios/04_rede_04.py)
- [Prever os percursos](24_arvores_binarias/exercicios/05_prever.py)
- [Corrigir o caso vazio](24_arvores_binarias/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 25_bst

**Invariante de busca.** Na BST sem duplicatas, cada chave à esquerda é menor e cada chave à direita é maior. A forma depende da ordem de inserção; uma sequência crescente pode degenerar a árvore.

Exemplos:

- [Catálogo em árvore binária de busca — cenário didático Lojas Blue](25_bst/exemplos/01_rede_aplicada.py)

Exercícios:

- [Inserir e buscar — Lojas Blue](25_bst/exercicios/01_rede_01.py)
- [Duplicatas — Lojas Blue](25_bst/exercicios/02_rede_02.py)
- [Remover — Lojas Blue](25_bst/exercicios/03_rede_03.py)
- [Degeneração — Lojas Blue](25_bst/exercicios/04_rede_04.py)
- [Prever formas diferentes](25_bst/exercicios/05_prever.py)
- [Corrigir o ramo da inserção](25_bst/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 26_balanceamento_e_rotacoes

**Equilíbrio e rotações.** Compare alturas e preserve a ordem BST ao rotacionar. O exemplo implementa a rotação simples RR; as atividades constroem LL, LR e RL. Inserção AVL completa é uma extensão avançada, não pré-requisito para o projeto básico.

Exemplos:

- [Rotação simples e altura — cenário didático Lojas Blue](26_balanceamento_e_rotacoes/exemplos/01_rede_aplicada.py)

Exercícios:

- [Rotação RR — Lojas Blue](26_balanceamento_e_rotacoes/exercicios/01_rede_01.py)
- [Rotação LL — Lojas Blue](26_balanceamento_e_rotacoes/exercicios/02_rede_02.py)
- [Casos LR e RL — Lojas Blue](26_balanceamento_e_rotacoes/exercicios/03_rede_03.py)
- [Extensão AVL — Lojas Blue](26_balanceamento_e_rotacoes/exercicios/04_rede_04.py)
- [Prever uma rotação](26_balanceamento_e_rotacoes/exercicios/05_prever.py)
- [Corrigir a subárvore intermediária](26_balanceamento_e_rotacoes/exercicios/06_investigar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.

## 27_integracao_reposicoes

**Projeto de reposição.** Una leitura, validação de relações, índices, cálculo de faltas e apresentação. O relatório de faltas e a fila das solicitações cadastradas são produtos diferentes. Defina desempates e preserve a base.

Exemplos:

- [Relatório de faltas com relações e ordenação — cenário didático Lojas Blue](27_integracao_reposicoes/exemplos/01_rede_aplicada.py)
- [Reposição: registros em memória e recorte isolado](27_integracao_reposicoes/exemplos/02_caso_reposicao.py)

Exercícios:

- [Relatório integrado — Lojas Blue](27_integracao_reposicoes/exercicios/01_rede_01.py)
- [Fila planejada — Lojas Blue](27_integracao_reposicoes/exercicios/02_rede_02.py)
- [Persistir cópia — Lojas Blue](27_integracao_reposicoes/exercicios/03_rede_03.py)
- [Projeto de consulta — Lojas Blue](27_integracao_reposicoes/exercicios/04_rede_04.py)
- [Prever o recorte integrado](27_integracao_reposicoes/exercicios/05_prever.py)
- [Comparar fonte e simulação](27_integracao_reposicoes/exercicios/06_comparar.py)

Critério para avançar: resolva um caso diferente do exemplo e explique o contrato e a mudança de estado sem copiar o código.


## Módulo de acesso aos dados

Depois do tópico 09 de PED, estude o [exemplo complementar](exemplo_acesso_dados.py)
e a [documentação do módulo dados](dados/README.md). `dados/acesso.py` centraliza leitura,
consultas comuns e gravação de cópias. Os exemplos da sequência continuam disponíveis.

## Problema comum e atividades variadas

Consulte o [caso evolutivo de reposição](PROBLEMA_EVOLUTIVO.md) e o [índice completo de atividades por tipo](ATIVIDADES_POR_TIPO.md). Os exercícios novos aparecem nesse índice com seus arquivos e objetivos.

Use o [percurso essencial](PERCURSO_ESSENCIAL.md) para concluir o projeto antes do ramo de aprofundamento em árvores. O exemplo 02 de integração utiliza o módulo de acesso; execute pelo comando de seu cabeçalho.

## Complementos e comparações

Siga [APROFUNDAMENTO_E_COMPARACOES.md](APROFUNDAMENTO_E_COMPARACOES.md) para integrar os exemplos e as atividades desta rodada ao percurso.

## 28_comparar_buscas_ordenacoes_e_indices

Compare buscas, ordenações e índices usando os mesmos registros e contratos. Inclua preparação, consultas e atualizações na avaliação do trabalho.

Exemplos:

- [Busca linear e binária na mesma entrada](28_comparar_buscas_ordenacoes_e_indices/exemplos/01_buscas.py)
- [Mesma ordem final, trabalho diferente](28_comparar_buscas_ordenacoes_e_indices/exemplos/02_ordenacoes.py)
- [Lista e índice respondem à mesma identidade](28_comparar_buscas_ordenacoes_e_indices/exemplos/03_indices.py)

Exercícios:

- [Prever o melhor caso](28_comparar_buscas_ordenacoes_e_indices/exercicios/01_prever.py)
- [Comparar incluindo preparação](28_comparar_buscas_ordenacoes_e_indices/exercicios/02_comparar.py)
- [Comparar um contrato comum](28_comparar_buscas_ordenacoes_e_indices/exercicios/03_prever.py)
- [Completar a observação de trabalho](28_comparar_buscas_ordenacoes_e_indices/exercicios/04_comparar.py)
- [Prever uma alteração compartilhada](28_comparar_buscas_ordenacoes_e_indices/exercicios/05_prever.py)
- [Comparar consulta e manutenção](28_comparar_buscas_ordenacoes_e_indices/exercicios/06_comparar.py)

Critério para avançar: resolva os casos propostos e explique o resultado e os limites da abordagem.
