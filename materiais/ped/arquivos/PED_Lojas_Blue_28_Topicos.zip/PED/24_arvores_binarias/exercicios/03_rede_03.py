# Percursos — Lojas Blue
# Enunciado:
# Implemente pré-ordem, em-ordem e pós-ordem e compare.
#
# Dica:
# A posição de visitar a raiz muda a sequência.
#
# Conferência:
# Pré-ordem começa por Rede; pós-ordem termina em Rede.
#
# Apoio: 24_arvores_binarias/exemplos/01_rede_aplicada.py
