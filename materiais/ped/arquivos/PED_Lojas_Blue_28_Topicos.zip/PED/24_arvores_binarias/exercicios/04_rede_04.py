# Não presumir BST — Lojas Blue
# Enunciado:
# Desenhe árvore binária com chaves fora da regra BST e explique por que busca binária de árvore não se aplica.
#
# Dica:
# Dois filhos no máximo não determina ordem.
#
# Conferência:
# Um nó menor à direita invalida a regra BST.
#
# Apoio: 24_arvores_binarias/exemplos/01_rede_aplicada.py
