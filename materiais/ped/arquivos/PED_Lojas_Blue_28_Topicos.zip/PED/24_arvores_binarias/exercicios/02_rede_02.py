# Altura — Lojas Blue
# Enunciado:
# Calcule altura em nós com vazia zero e folha um.
#
# Dica:
# Escolha a maior altura dos dois filhos.
#
# Conferência:
# Árvore do exemplo altura dois.
#
# Apoio: 24_arvores_binarias/exemplos/01_rede_aplicada.py
