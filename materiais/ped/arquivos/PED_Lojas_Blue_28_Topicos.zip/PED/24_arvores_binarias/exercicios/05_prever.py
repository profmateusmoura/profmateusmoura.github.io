# Prever os percursos
# Enunciado:
# Na árvore com raiz Rede, filho esquerdo MG e filho direito SP, preveja pré-ordem, em-ordem e pós-ordem.
#
# Dica:
# Mude o momento da visita à raiz.
#
# Conferência:
# Pré-ordem começa em Rede; pós-ordem termina em Rede.
#
# Apoio: 24_arvores_binarias/exemplos/01_rede_aplicada.py
