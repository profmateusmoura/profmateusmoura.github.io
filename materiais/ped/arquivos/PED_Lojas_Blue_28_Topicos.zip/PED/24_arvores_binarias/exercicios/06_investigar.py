# Corrigir o caso vazio
# Enunciado:
# Uma contagem acessa filhos antes de testar se o nó é None. Reorganize o caso-base e teste árvore vazia e folha.
#
# Dica:
# O acesso aos campos só ocorre em nó existente.
#
# Conferência:
# Vazia retorna zero; folha retorna um.
#
# Apoio: 24_arvores_binarias/exemplos/01_rede_aplicada.py
