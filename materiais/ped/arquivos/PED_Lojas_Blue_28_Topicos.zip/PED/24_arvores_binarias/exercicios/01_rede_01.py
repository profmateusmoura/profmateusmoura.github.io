# Contar árvore — Lojas Blue
# Enunciado:
# Conte nós da árvore de agrupamento Rede/MG/SP.
#
# Dica:
# None é caso-base.
#
# Conferência:
# Três nós; vazia zero.
#
# Apoio: 24_arvores_binarias/exemplos/01_rede_aplicada.py
