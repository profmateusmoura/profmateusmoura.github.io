# Árvore de agrupamento de unidades — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Nós: 3'
# Sem entrada interativa.

def contar(no):
    """Conte os nós de uma árvore binária; None representa árvore vazia."""
    if no is None:
        return 0
    return 1 + contar(no["esquerda"]) + contar(no["direita"])

# Uma árvore binária não é necessariamente uma árvore binária de busca.
arvore = {"valor": "Rede", "esquerda":
    {"valor": "MG", "esquerda": None, "direita": None}, "direita":
    {"valor": "SP", "esquerda": None, "direita": None}}
print("Nós:", contar(arvore))
# A organização acima ilustra ramificação, não todos os registros do JSON.
