# Fila planejada — Lojas Blue
# Enunciado:
# Gere fila das solicitações AGUARDANDO ordenadas por prioridade decrescente e id crescente.
#
# Dica:
# Não confunda solicitação cadastrada com sugestão até mínimo.
#
# Conferência:
# Primeira solicitação id 2.
#
# Apoio: 27_integracao_reposicoes/exemplos/01_rede_aplicada.py
