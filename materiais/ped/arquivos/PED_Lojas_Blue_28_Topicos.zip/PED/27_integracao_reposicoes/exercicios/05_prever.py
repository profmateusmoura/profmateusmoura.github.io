# Prever o recorte integrado
# Enunciado:
# No caso evolutivo, preveja quantidade de posições críticas e soma das faltas antes e depois da retirada de nove unidades de (1,1).
#
# Dica:
# A alteração atinge uma única posição.
#
# Conferência:
# Antes 3 e 9; depois 4 e 10.
#
# Apoio: 27_integracao_reposicoes/exemplos/01_rede_aplicada.py, 27_integracao_reposicoes/exemplos/02_caso_reposicao.py
