# Relatório integrado — Lojas Blue
# Enunciado:
# Relacione posições críticas aos nomes de unidade e produto e ordene por falta decrescente, depois unidade e produto.
#
# Dica:
# A falta é mínimo menos saldo, somente quando positiva.
#
# Conferência:
# Sete sugestões; a primeira tem falta seis.
#
# Apoio: 27_integracao_reposicoes/exemplos/01_rede_aplicada.py
