# Comparar fonte e simulação
# Enunciado:
# Complete uma verificação que compare o saldo (1,1) da base carregada com o do recorte após a simulação do caso evolutivo.
#
# Dica:
# O recorte copia os registros, além da lista externa.
#
# Conferência:
# A fonte em memória mantém 18 e o recorte passa a 9.
#
# Apoio: 27_integracao_reposicoes/exemplos/01_rede_aplicada.py, 27_integracao_reposicoes/exemplos/02_caso_reposicao.py
