# Projeto de consulta — Lojas Blue
# Enunciado:
# Integre catálogo, busca linear ou binária, ordenação explícita por preço, índice de estoque e consulta de faltas em menu. Documente decisões e testes.
#
# Dica:
# Separe funções de leitura, cálculo e apresentação.
#
# Conferência:
# Dados originais intactos; ausência e menu inválido tratados.
#
# Apoio: 27_integracao_reposicoes/exemplos/01_rede_aplicada.py
