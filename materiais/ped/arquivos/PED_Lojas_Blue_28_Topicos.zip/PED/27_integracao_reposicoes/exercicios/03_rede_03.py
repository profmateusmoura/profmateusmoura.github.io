# Persistir cópia — Lojas Blue
# Enunciado:
# Salve relatório em saidas/sugestoes.json, recarregue e confira chaves e quantidades.
#
# Dica:
# Não grave a fonte.
#
# Conferência:
# Sete sugestões após recarga.
#
# Apoio: 27_integracao_reposicoes/exemplos/01_rede_aplicada.py
