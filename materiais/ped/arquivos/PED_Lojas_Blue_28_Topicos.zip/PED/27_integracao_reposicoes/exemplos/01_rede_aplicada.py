# Relatório de faltas com relações e ordenação — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Sugestões: 7'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def chave_prioridade(registro):
    """Ordene maior falta primeiro; empate por unidade e produto crescentes."""
    return (-registro["falta"], registro["unidade_id"], registro["produto_id"])

produtos = {}
for produto in dados["produtos"]:
    produtos[produto["id"]] = produto
unidades = {}
for unidade in dados["unidades"]:
    unidades[unidade["id"]] = unidade
relatorio = []
for estoque in dados["estoques"]:
    falta = estoque["minimo"] - estoque["quantidade"]
    if falta > 0:
        relatorio.append({"unidade_id": estoque["unidade_id"],
                          "produto_id": estoque["produto_id"], "falta": falta})
# Aqui sorted é ferramenta de aplicação; nos tópicos 16–18 o algoritmo é explícito.
relatorio = sorted(relatorio, key=chave_prioridade)
for registro in relatorio:
    print(unidades[registro["unidade_id"]]["nome"], "|",
          produtos[registro["produto_id"]]["nome"], "|", registro["falta"])
print("Sugestões:", len(relatorio))
