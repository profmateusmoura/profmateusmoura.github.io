# Reposição: registros em memória e recorte isolado
# Estude os exemplos anteriores deste tópico antes desta aplicação.
# Execução: python -m 27_integracao_reposicoes.exemplos.02_caso_reposicao
# Confira na saída: 'Posições críticas: 4\nTotal a repor: 10'
# Preveja o resultado e altere um dado por vez para conferir seu raciocínio.

from dados.acesso import carregar_dados

def selecionar_recorte(estoques, identidades):
    """Retorne cópias das posições pedidas, preservando a base carregada."""
    recorte = []
    for estoque in estoques:
        chave = (estoque["unidade_id"], estoque["produto_id"])
        if chave in identidades:
            recorte.append(estoque.copy())
    return recorte

def gerar_sugestoes(estoques):
    """Retorne nova lista de unidade, produto e falta estritamente positiva."""
    sugestoes = []
    for estoque in estoques:
        falta = estoque["minimo"] - estoque["quantidade"]
        if falta > 0:
            sugestoes.append({"unidade_id": estoque["unidade_id"],
                              "produto_id": estoque["produto_id"], "falta": falta})
    return sugestoes

def mostrar_resumo(sugestoes):
    """Apresente a quantidade de posições críticas e a soma de faltas."""
    total = 0
    for sugestao in sugestoes:
        total += sugestao["falta"]
    print("Posições críticas:", len(sugestoes))
    print("Total a repor:", total)

def main():
    """Carregue a base uma vez e simule alteração apenas no recorte copiado."""
    dados = carregar_dados()
    identidades = ((1, 1), (1, 4), (1, 10), (3, 2))
    recorte = selecionar_recorte(dados["estoques"], identidades)
    mostrar_resumo(gerar_sugestoes(recorte))
    for estoque in recorte:
        if estoque["unidade_id"] == 1 and estoque["produto_id"] == 1:
            estoque["quantidade"] -= 9
    print("Depois da retirada:")
    mostrar_resumo(gerar_sugestoes(recorte))

if __name__ == "__main__":
    main()
