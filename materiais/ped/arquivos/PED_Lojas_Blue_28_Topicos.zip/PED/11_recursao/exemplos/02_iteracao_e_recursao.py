# Duas maneiras de somar os mesmos saldos
# Execução: python 11_recursao/exemplos/02_iteracao_e_recursao.py
# Confira na saída: 'Iterativa: 28 recursiva: 28'
# Preveja o estado dos dados antes de executar; depois altere um caso de fronteira.

def somar_iterativo(saldos):
    """Some saldos com acumulador; lista vazia retorna zero."""
    total = 0
    for saldo in saldos:
        total += saldo
    return total

def somar_recursivo(saldos, indice=0):
    """Some desde indice válido, usando o fim da lista como caso-base."""
    if indice == len(saldos):
        return 0
    # O retorno desta chamada depende do retorno da próxima. Cada chamada
    # mantém seu índice até poder terminar sua própria soma.
    return saldos[indice] + somar_recursivo(saldos, indice + 1)

for saldos in ([], [4], [4, 6, 18]):
    print("Iterativa:", somar_iterativo(saldos), "recursiva:", somar_recursivo(saldos))
# O laço guarda um acumulador; a recursão também usa estados de chamadas pendentes.
