# Somar um intervalo de saldos por recursão — cenário didático Lojas Blue
# Objetivo: Aplicar o conceito sobre a rede com implementação visível.
# Pré-requisito: tópicos anteriores e exemplos anteriores deste tópico.
# Estude: preveja o resultado, execute e altere um dado por vez.
# Confira na saída: 'Saldo total:'
# Sem entrada interativa.

from pathlib import Path
import json

# O caminho depende da posição deste arquivo, não da pasta do terminal.
# json.load transforma o documento em listas e dicionários na memória.
arquivo = Path(__file__).resolve().parents[2] / "dados" / "lojas_blue.json"
with arquivo.open(encoding="utf-8") as entrada:
    dados = json.load(entrada)
# A base fornecida é de leitura. Alterar dados em memória não grava o JSON.

def somar_saldos(estoques, indice):
    """Some os saldos desde indice, entre zero e len(estoques), inclusive."""
    if indice == len(estoques):
        return 0  # Caso-base: nenhum registro restante.
    # Cada chamada aproxima o índice do caso-base.
    return estoques[indice]["quantidade"] + somar_saldos(estoques, indice + 1)

print("Saldo total:", somar_saldos(dados["estoques"], 0))
# A recursão é didática; entradas muito grandes podem exceder a pilha de chamadas.
