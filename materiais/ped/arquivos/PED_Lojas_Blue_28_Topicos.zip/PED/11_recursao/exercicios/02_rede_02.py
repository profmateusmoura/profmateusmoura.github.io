# Contagem recursiva — Lojas Blue
# Enunciado:
# Conte produtos cujo preço é até 30 usando índice e recursão.
#
# Dica:
# Cada chamada decide a contribuição de um registro.
#
# Conferência:
# Compare com percurso iterativo.
#
# Apoio: 11_recursao/exemplos/01_rede_aplicada.py
