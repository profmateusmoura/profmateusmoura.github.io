# Rastrear os retornos pendentes
# Enunciado:
# Faça teste de mesa da soma recursiva de [4,6,18], registrando o valor que cada chamada espera receber da seguinte.
#
# Dica:
# Comece a concluir os retornos pelo caso-base.
#
# Conferência:
# O retorno final é 28.
#
# Apoio: 11_recursao/exemplos/02_iteracao_e_recursao.py
