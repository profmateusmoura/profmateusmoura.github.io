# Soma recursiva — Lojas Blue
# Enunciado:
# Some saldos por recursão sem alterar a lista.
#
# Dica:
# Tenha caso-base e avanço do índice.
#
# Conferência:
# Lista vazia soma zero.
#
# Apoio: 11_recursao/exemplos/01_rede_aplicada.py
