# Prever chamadas recursivas
# Enunciado:
# Faça teste de mesa de uma soma recursiva com saldos [4, 6] e índice inicial zero. Registre argumentos e retornos, incluindo o caso-base.
#
# Dica:
# Cada chamada espera o retorno da próxima.
#
# Conferência:
# O caso-base retorna zero; a soma final é dez.
#
# Apoio: 11_recursao/exemplos/01_rede_aplicada.py
