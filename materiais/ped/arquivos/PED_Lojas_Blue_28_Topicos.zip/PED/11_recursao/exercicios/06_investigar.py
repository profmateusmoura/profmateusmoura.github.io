# Corrigir a redução do problema
# Enunciado:
# Uma função recursiva recebe indice e chama novamente a si mesma com o mesmo indice. Corrija o avanço e explique por que o caso-base será alcançado.
#
# Dica:
# Verifique a medida que diminui ou se aproxima do fim em cada chamada.
#
# Conferência:
# Com dois saldos e início zero, o caso-base ocorre no índice dois.
#
# Apoio: 11_recursao/exemplos/01_rede_aplicada.py
