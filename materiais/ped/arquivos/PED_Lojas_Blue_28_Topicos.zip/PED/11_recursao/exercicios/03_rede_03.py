# Busca recursiva — Lojas Blue
# Enunciado:
# Busque id de produto em lista; retorne registro ou None.
#
# Dica:
# Chegar ao fim sem achar é o caso-base de ausência.
#
# Conferência:
# Primeiro, último e ausente funcionam.
#
# Apoio: 11_recursao/exemplos/01_rede_aplicada.py
