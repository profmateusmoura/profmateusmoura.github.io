# Comparar o controle de término
# Enunciado:
# Escreva contagem de saldos críticos com laço e com recursão. Use o mesmo contrato e teste vazio.
#
# Dica:
# Na recursão, explicite qual argumento se aproxima do caso-base.
#
# Conferência:
# As versões coincidem e vazio resulta em zero.
#
# Apoio: 11_recursao/exemplos/02_iteracao_e_recursao.py
