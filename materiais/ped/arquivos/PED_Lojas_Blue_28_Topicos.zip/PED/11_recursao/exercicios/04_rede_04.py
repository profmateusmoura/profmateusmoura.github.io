# Limite da técnica — Lojas Blue
# Enunciado:
# Compare a soma recursiva com a iterativa no JSON e explique por que aumentar muito a entrada pode causar RecursionError.
#
# Dica:
# Não aumente o limite de recursão.
#
# Conferência:
# As duas somas da base coincidem.
#
# Apoio: 11_recursao/exemplos/01_rede_aplicada.py
